function ConvivaPrivateModule(){}
(function(){












function yR(x7,l3){
if(typeof(ConvivaPrivateModule)!="undefined"){
ConvivaPrivateModule[l3]=x7;
}else if(typeof(ConvivaPrivateTestingModule)!="undefined"){
ConvivaPrivateTestingModule[l3]=x7;
}else{

ConvivaPrivateLoader[l3]=x7;
}
}
yR(yR,"yR");


function ag(Fn){return Fn;}
yR(ag,"ag");



function sHq(l5){
if(typeof(ConvivaPrivateModule)!="undefined"&&ConvivaPrivateModule.hasOwnProperty(l5)){
return ConvivaPrivateModule[l5];
}else if(typeof(ConvivaPrivateTestingModule)!="undefined"&&ConvivaPrivateTestingModule.hasOwnProperty(l5)){
return ConvivaPrivateTestingModule[l5];
}else if(ConvivaPrivateLoader.hasOwnProperty(l5)){
return ConvivaPrivateLoader[l5];
}else{
return null;
}
}
yR(sHq,"sHq");




function at(frW,lei){
var S5="";
var Ti;
for(Ti in frW){
if(frW.hasOwnProperty(Ti)){
S5+="var "+Ti+"="+ag(lei)+"."+Ti+";"
}
}
return S5;
}
yR(at,"at");


function fj(){
return "STAT_INIT";
}
yR(fj,"fj");


function Bg(x7,l3){
x7.call(fj);
yR(x7,l3);
}
yR(Bg,"Bg");


function OZ(sq,Sj,xF){
if(sq!=fj){
if(sq[Sj]==undefined){
sq[Sj]=xF;
}else{

sq["Ph"+Sj]=xF;
}
}
}
yR(OZ,"OZ");


function LK(sq,Sj,xF){
if(sq!=fj)sq[Sj]=xF;
}
yR(LK,"LK");


function dN(sq,x7,Sj,xF){
if(sq==fj)x7[Sj]=xF;
}
yR(dN,"dN");


function ED(sq,Sj,xF){
if(sq!=fj){
if(typeof(Object.defineProperty)!='undefined'){
Object.defineProperty(sq,Sj,{
configurable:true,
enumerable:true,
get:xF
});
}else{
sq.__defineGetter__(Sj,xF);
}
}
}
yR(ED,"ED");

function Wf(sq,Sj,xF){
if(sq!=fj){
if(typeof(Object.defineProperty)!='undefined'){
Object.defineProperty(sq,Sj,{
configurable:true,
set:xF
});
}else{
sq.__defineSetter__(Sj,xF);
}
}
}
yR(Wf,"Wf");

function Va(sq,x7,Sj,xF){
if(sq==fj)ED(x7,Sj,xF);
}
yR(Va,"Va");

function Z0(sq,x7,Sj,xF){
if(sq==fj)Wf(x7,Sj,xF);
}
yR(Z0,"Z0");

function PW(k9){

if(k9.constructor==Array){
return true;
}else if(typeof(k9.length)=='undefined'){
return false;
}else{
return true;
}
}
yR(PW,"PW");

function BW(l4,Kq){
var tK=PW(l4);
if(PW(l4)){
for(var co=0;co<l4.length;co++){
Kq(l4[co]);
}
}else{
for(var Ti in l4){
if(l4.hasOwnProperty(Ti))Kq(l4[Ti]);
}
}
}
yR(BW,"BW");

function Zi(l4,Kq){
if(PW(l4)){
for(var co=0;co<l4.length;co++){
Kq(co);
}
}else{
for(var Ti in l4){
if(l4.hasOwnProperty(Ti))Kq(Ti);
}
}
}
yR(Zi,"Zi");



function D8(sq,Sj,x7,DM){
if(sq==fj)jstest.CR(Sj,x7,DM);
}
yR(D8,"D8");





function m2(sq,l3,PD,_8,DM){
if(sq==fj){
jstest.lT(l3,PD,DM);
}else{
jstest.xq(l3,PD,_8);
}
}
yR(m2,"m2");


function n4(){
n4.t3R=0x100000000;

n4.z_=function(Sk){
var ZFC=parseInt(Sk);
if(ZFC>n4.Je){
ZFC=ZFC%n4.t3R;
}else if(ZFC<0){
ZFC=(-ZFC)%n4.t3R;
ZFC=n4.t3R-ZFC;
}
return ZFC;
};

n4.QIc=new RegExp("^[0-9]+$");
n4.tn=function(Sk){
oL.qlz(Sk,n4.QIc);
return n4.z_(Sk);
}

n4.Je=n4.t3R-1;
n4.ke=0;
}
Bg(n4,"n4");


function VW(){
VW.z_=function(Sk){

var WMR=n4.z_(Sk);
if(WMR>VW.Je){
WMR=WMR-n4.t3R;
}
return WMR;
};

VW.y7A=new RegExp("^[+-]?[0-9]+$");
VW.tn=function(Sk){
oL.qlz(Sk,VW.y7A);
return VW.z_(Sk);
}

VW.Je=0x7FFFFFFF;
VW.ke=-0x80000000;
}
Bg(VW,"VW");

function L_(){
var up=this;

if(up==fj)L_.qp=4294967296.0;










function _d(){
up.XE=0;
up.Br=0;
};


dN(up,L_,"uk",ui);
function ui(co){
var S5=new L_();
S5.Br=0;
S5.XE=co;
return S5;
};


dN(up,L_,"yu",pd);
function pd(co){
var S5=new L_();
if(co>=0){
S5.Br=0;
S5.XE=n4.z_(co);
}else{
S5.Br=-1;
S5.XE=n4.z_(co);
}
return S5;
};


dN(up,L_,"Ho",Ma);
function Ma(v9){
var rn=v9%L_.qp;

if(rn<0){
rn=Number(n4.Je)+1.0+rn;
}
var S5=new L_();
S5.XE=n4.z_(rn+0.5);
S5.Br=VW.z_((v9-rn)/L_.qp);

return S5;
};



ED(up,"mg",mM);
function mM(){
return Number(up.Br)*L_.qp+Number(up.XE);
};


if(up!=fj){
this.toString=function(){
return up.mg.toString();
}
}

if(up!=fj)_d.apply(this,arguments);

};
Bg(L_,"L_");


function Q2(){

var up=this;

function _d(){

L_.call(up);
up.XE=0;
up.Br=0;
}


dN(up,Q2,"uk",ui);
function ui(co){
var S5=new Q2();
S5.Br=0;
S5.XE=co;
return S5;
};


dN(up,Q2,"Ho",Ma);
function Ma(v9){
var S5=new Q2();
S5.Br=Math.floor(v9/L_.qp);
S5.XE=v9%L_.qp;
return S5;
};


if(up!=fj)_d.apply(arguments);
};
Bg(Q2,"Q2");




function OY(hg,KN,Vv){
this.hg=hg;
this.KN=KN;
this.Vv=Vv;
}




Ff=function(qs,Wk){
this.qs=qs;
this.Wk=Wk;
};
with({Ti:Ff.prototype}){
with({Ti:(Ti.p2=function(qs,yt){
this.qs=qs||0;
this.yt=[];
this._t(yt);}).prototype}){
Ti._t=function(jV){
if(jV){

var aw=0;
var cn=jV.length;
if(jV.hasOwnProperty("KN")){
aw=jV.KN;
cn=jV.Vv;
jV=jV.hg;
}else{
cn=jV.length;
}
var co;
var jl;
for(co=cn,jl=this.yt=new Array(cn);co;jl[cn-co]=(jV.charCodeAt(--co+aw)&0xFF));
this.qs&&jl.reverse();
}
};
Ti.E_=function(GC){
return this.yt.length>=-(-GC>>3);
};
Ti.v1=function(GC){
if(!this.E_(GC))
throw new Error("checkBuffer::missing bytes");
};
Ti.Dz=function(tO,length){

function GJ(l4,jl){

for(;jl--;l4=((l4%=(0x7fffffff+1))&0x40000000)==0x40000000?l4*2:(l4-0x40000000)*2+0x7fffffff+1);
return l4;
}
if(tO<0||length<=0)
return 0;
this.v1(tO+length);
for(var dd,
uS=tO%8,
E1=this.yt.length-(tO>>3)-1,
Mc=this.yt.length+(-(tO+length)>>3),
nx=E1-Mc,
gG=((this.yt[E1]>>uS)&((1<<(nx?8-uS:length))-1))+
(nx&&(dd=(tO+length)%8)?(this.yt[Mc++]&((1<<dd)-1))<<(nx--<<3)-uS:0);

nx;

gG+=GJ(this.yt[Mc++],(nx--<<3)-uS));
return gG;
};
}
Ti.rj=function(rU){
if(this.Wk)
throw new Error(rU);
return 1;
};
Ti.e5=function(jV,Oq,vc){
var jl=new this.p2(this.qs,jV);
jl.v1(Oq+vc+1);
var qR=Math.pow(2,vc-1)-1,Pf=jl.Dz(Oq+vc,1),A8=jl.Dz(Oq,vc),FO=0,
Ve=2,E1=jl.yt.length+(-Oq>>3)-1;
do
for(var ZV=jl.yt[++E1],w9=Oq%8||8,FL=1<<w9;FL>>=1;(ZV&FL)&&(FO+=1/Ve),Ve*=2);
while(Oq-=w9);
return A8==(qR<<1)+1?FO?NaN:Pf?-Infinity:+Infinity:(1+Pf*-2)*(A8||FO?!A8?Math.pow(2,-qR+1)*FO:Math.pow(2,A8-qR)*(1+FO):0);
};
Ti._9=function(jV,IL,ef){
var jl=new this.p2(this.qs,jV);
var Fn=jl.Dz(0,IL),_j=Math.pow(2,IL);
return ef&&Fn>=_j/2?Fn-_j:Fn;
};
Ti.te=function(jV,Oq,vc){
jV=parseFloat(jV);
var qR=Math.pow(2,vc-1)-1,aH=-qR+1,gP=qR,Hc=aH-Oq,
f1=isNaN(v9=parseFloat(jV))||v9==-Infinity||v9==+Infinity?v9:0,
LU=0,Wp=2*qR+1+Oq+3,M6=new Array(Wp),
Pf=(v9=f1!==0?0:v9)<0,v9=Math.abs(v9),QA=Math.floor(v9),za=v9-QA,
co,xR,_L,Bs,lb;
for(co=Wp;co;M6[--co]=0);
for(co=qR+2;QA&&co;M6[--co]=QA%2,QA=Math.floor(QA/2));
for(co=qR+1;za>0&&co;(M6[++co]=((za*=2)>=1)-0)&&--za);
for(co=-1;++co<Wp&&!M6[co];);
if(M6[(xR=Oq-1+(co=(LU=qR+1-co)>=aH&&LU<=gP?co+1:qR+1-(LU=aH-1)))+1]){
if(!(_L=M6[xR]))
for(Bs=xR+2;!_L&&Bs<Wp;_L=M6[Bs++]);
for(Bs=xR+1;_L&&--Bs>=0;(M6[Bs]=!M6[Bs]-0)&&(_L=0));
}
for(co=co-2<0?-1:co-3;++co<Wp&&!M6[co];);
if((LU=qR+1-co)>=aH&&LU<=gP)
++co;
else if(LU<aH){
LU!=qR+1-Wp&&LU<Hc&&this.rj("encodeFloat::float underflow");
co=qR+1-(LU=aH-1);
}
if(QA||f1!==0){

LU=gP+1;
co=qR+2;
if(f1==-Infinity)
Pf=1;
else if(isNaN(f1)){
Pf=1;
M6[co]=1;
}
}
for(v9=Math.abs(LU+qR),Bs=vc+1,lb="";--Bs;lb=(v9%2)+lb,v9=v9>>=1);
for(v9=0,Bs=0,co=(lb=(Pf?"1":"0")+lb+M6.slice(co,co+Oq).join("")).length,eq=[];co;Bs=(Bs+1)%8){
v9+=(1<<Bs)*lb.charAt(--co);
if(Bs==7){
eq[eq.length]=String.fromCharCode(v9);
v9=0;
}
}
eq[eq.length]=v9?String.fromCharCode(v9):"";
return(this.qs?eq.reverse():eq).join("");
};
Ti.h6=function(jV,IL,ef){
jV=parseInt(jV);
var _j=Math.pow(2,IL);
(jV>=_j||jV<-(_j/2))&&this.rj("encodeInt::overflow")&&(jV=0);
jV<0&&(jV+=_j);
var eq=[];
while(jV){
eq[eq.length]=String.fromCharCode(jV%256);
jV=Math.floor(jV/256);
};
for(IL=-(-IL>>3)-eq.length;IL--;eq[eq.length]="\000");
return(this.qs?eq.reverse():eq).join("");
};
Ti.qb=function(jV){return this._9(jV,8,true);};
Ti.Mx=function(jV){return this.h6(jV,8,true);};
Ti.ph=function(jV){return this._9(jV,8,false);};
Ti.vb=function(jV){return this.h6(jV,8,false);};
Ti.s1=function(jV){return this._9(jV,16,true);};
Ti.kZ=function(jV){return this.h6(jV,16,true);};
Ti.eR=function(jV){return this._9(jV,16,false);};
Ti.ko=function(jV){return this.h6(jV,16,false);};
Ti.so=function(jV){return this._9(jV,32,true);};
Ti.yu=function(jV){return this.h6(jV,32,true);};
Ti.PB=function(jV){return this._9(jV,32,false);};
Ti.T5=function(jV){return this.h6(jV,32,false);};
Ti.I_=function(jV){return this.e5(jV,23,8);};
Ti.AU=function(jV){return this.te(jV,23,8);};
Ti.qM=function(jV){return this.e5(jV,52,11);};
Ti.Dv=function(jV){return this.te(jV,52,11);};
};







va=function(_W){
var ii=_W.length;
var rS=[];
var JU,cp;
var Fn,w4,BF;
for(var co=0;co<ii;co++){
JU=_W.charCodeAt(co);
if((JU&0xff80)==0){

rS.push(JU);
}else{
if((JU&0xfc00)==0xD800){
cp=_W.charCodeAt(co+1);
if((cp&0xfc00)==0xDC00){

JU=(((JU&0x03ff)<<10)|(cp&0x3ff))+0x10000;
co++;
}else{

console.log("Error decoding surrogate pair: "+JU+"; "+cp);
}
}
Fn=JU&0xff;
w4=JU&0xff00;
BF=JU&0xff0000;

if(JU<=0x0007ff){
rS.push(0xc0|(w4>>6)|(Fn>>6));
rS.push(0x80|(Fn&63));
}else if(JU<=0x00ffff){
rS.push(0xe0|(w4>>12));
rS.push(0x80|((w4>>6)&63)|(Fn>>6));
rS.push(0x80|(Fn&63));
}else if(JU<=0x10ffff){
rS.push(0xf0|(BF>>18));
rS.push(0x80|((BF>>12)&63)|(w4>>12));
rS.push(0x80|((w4>>6)&63)|(Fn>>6));
rS.push(0x80|(Fn&63));
}else{

console.log("Error encoding to utf8: "+JU+" is greater than U+10ffff");
rS.push("?".charCodeAt(0));
}
}
}
return rS;
};

IF=function(rS){
var Vn=rS.length;
var _W="";
var JU,rM,dL,V1;
for(var co=0;co<Vn;co++){
JU=rS[co];
if((JU&0x80)==0x00){
}else if((JU&0xf8)==0xf0){

rM=rS[co+1];
dL=rS[co+2];
V1=rS[co+3];
if((rM&0xc0)==0x80&&(dL&0xc0)==0x80&&(V1&0xc0)==0x80){
JU=(JU&7)<<18|(rM&63)<<12|(dL&63)<<6|(V1&63);
co+=3;
}else{

console.log("Error decoding from utf8: "+JU+","+rM+","+dL+","+V1);
continue;
}
}else if((JU&0xf0)==0xe0){

rM=rS[co+1];
dL=rS[co+2];
if((rM&0xc0)==0x80&&(dL&0xc0)==0x80){
JU=(JU&15)<<12|(rM&63)<<6|(dL&63);
co+=2;
}else{

console.log("Error decoding from utf8: "+JU+","+rM+","+dL);
continue;
}
}else if((JU&0xe0)==0xc0){

rM=rS[co+1];
if((rM&0xc0)==0x80){
JU=(JU&31)<<6|(rM&63);
co+=1;
}else{

console.log("Error decoding from utf8: "+JU+","+rM);
continue;
}
}else{



console.log("Error decoding from utf8: "+JU+" encountered not in multi-byte sequence");
continue;
}
if(JU<=0xffff){
_W+=String.fromCharCode(JU);
}else if(JU>0xffff&&JU<=0x10ffff){

JU-=0x10000;
_W+=(String.fromCharCode(0xD800|(JU>>10))+String.fromCharCode(0xDC00|(JU&1023)));
}else{
console.log("Error encoding surrogate pair: "+JU+" is greater than U+10ffff");
}
}
return _W;
};









function Vz(){
var up=this;



function _d(){
up.AJ=new Ff(true,false);
up._W="";
up.Ny=0;
};

dN(up,Vz,"UA",Zd);
function Zd(_W){
var S5=new Vz();
S5._W=_W;
return S5;
}


dN(up,Vz,"BU",S2);
function S2(f8){
var WJ=new Vz();
for(var co=0;co<f8.ug;co++){
eQ.NP(WJ,f8.tc(co));
}
return WJ;
}


OZ(up,"v_",ES);
function ES(){
up.KM();
var PA=new jh(up.X1);
for(var Ny=0;Ny<PA.ug;Ny++){
PA.a9(Ny,eQ.Jj(up));
}
return PA;
}


dN(up,Vz,"Y_",gE);
function gE(_W){
return Zd(_W);
}

OZ(up,"UX",h0);
function h0(){
return up._W;
}

OZ(up,"vo",Ua);
function Ua(){
return up._W;
}


OZ(up,"u6",ul);
function ul(){
up.KM();
return up;
}
OZ(up,"Uv",Fa);
function Fa(){
up._W="";
up.Ny=0;
return up;
}


OZ(up,"PJ",nW);
function nW(Wp){
if(Wp<0||up.Ny+Wp>up._W.length){
throw new Error("Access string outside the bounds");
}
var S5=new OY(up._W,up.Ny,Wp);

up.Ny+=Wp;
return S5;
}

OZ(up,"FF",SD);
function SD(nI){
up._W=up._W+nI;
}

OZ(up,"KM",gW);
function gW(){
up.Ny=0;
}


ED(up,"X1",gJ);
function gJ(){
return up._W.length-up.Ny;
};

if(up==fj){

Vz.hp=false;
if(window.GN!=undefined){
var Fn=new GN();
if(Fn.xh!=undefined){
Vz.hp=true;
}
}
Vz.l0=!Vz.hp;
}


dN(up,Vz,"Em",NH);
function NH(_W){
var bb=[];
var Mg=0;
var Vp=0;
var co=0;
while(1){
if(Mg<7){
if(co>=_W.length)break;
var JU=_W.charCodeAt(co)&0xFF;
co++;
Vp|=(JU<<Mg);
Mg+=8;
}
bb.push(String.fromCharCode(Vp&0x7F));
Vp>>=7;
Mg-=7;
}
if(Mg>0){
bb.push(String.fromCharCode(Vp&0x7f));
}
return bb.join("");
}

if(up!=fj)_d.apply(up,arguments);
};
Bg(Vz,"Vz");



function eQ(){
eQ.Mr=0x7062;

eQ.rb="Invalid PacketBrain magic code";
eQ.caq="PacketBrain structure too big";

eQ.oY=function(jl,Sk){
jl.FF(jl.AJ.Mx(Sk));
};

eQ.NP=function(jl,Sk){
jl.FF(jl.AJ.vb(Sk));
};

eQ._m=function(jl,Sk){
jl.FF(jl.AJ.kZ(Sk));
};
eQ.Rw=function(jl,Sk){
jl.FF(jl.AJ.ko(Sk));
};

eQ.HT=function(jl,Sk){
jl.FF(jl.AJ.yu(Sk));
};
eQ.jU=function(jl,Sk){
jl.FF(jl.AJ.T5(Sk));
};

eQ.Gx=function(jl,Sk){
jl.FF(jl.AJ.T5(Sk.Br));
jl.FF(jl.AJ.T5(Sk.XE));
};
eQ.Ch=eQ.Gx;

eQ.MO=function(jl,Sk){
jl.FF(jl.AJ.vb(Sk?1:0));
};
eQ.x1=function(jl,Sk){
jl.FF(jl.AJ.Dv(Sk));
};

eQ.REE=function(jl,Sk){
if(Sk>=0x10000){
eQ.jU(jl,Sk);
}else{
eQ.Rw(jl,Sk);
}
};

eQ.WfF=function(jl,dDD){
if(dDD){
return eQ.ip(jl);
}else{
return eQ.Kp(jl);
}
};

eQ.hvL=function(jl,Sk){
if(Sk>=0x8000){
var DNC=Sk|0x80000000;
eQ.jU(jl,DNC);
}else{
eQ.Rw(jl,Sk);
}
};

eQ.jTz=function(jl,dDD){
var r8_=eQ.Kp(jl);
if(r8_>=0x8000){
var wLn=eQ.Kp(jl);
return(r8_-0x8000)*0x10000+wLn;
}else{
return r8_;
}
};

eQ.x3=function(jl){
return jl.AJ.qb(jl.PJ(1));
};
eQ.Jj=function(jl){
return jl.AJ.ph(jl.PJ(1));
};
eQ.VA=function(jl){
return jl.AJ.s1(jl.PJ(2));
};
eQ.Kp=function(jl){
return jl.AJ.eR(jl.PJ(2));
};
eQ.YV=function(jl){
return jl.AJ.so(jl.PJ(4));
};
eQ.ip=function(jl){
return jl.AJ.PB(jl.PJ(4));
};
eQ.mr=function(jl){
var S5=new L_();
S5.Br=eQ.ip(jl);
S5.XE=eQ.ip(jl);
return S5;
};
eQ.CV=eQ.mr;

eQ.gC=function(jl){
return(0!=eQ.Jj(jl));
};

eQ.Hu=function(jl){
return jl.AJ.qM(jl.PJ(8));
};

eQ.q9=function(jl){
return jl.Ny;
};
eQ.Pa=function(jl,fb){
jl.Ny+=fb;
};

eQ.H_=function(Sk){
if(!Sk)throw new Error("PbAssert");
};



eQ.b1=function(l4,aw,Wp){
if(aw==0&&Wp==-1){

return IF(l4);
}else{
return IF(l4.slice(aw,aw+Wp));
}
};
















function Zg(Oj,nI){

var f8=va(nI);
var Z7=f8.length;
if(Z7>=256*128){

Z7=256*128;
}
var VK;
var K8;
if(Z7>=128){
VK=(Z7>>8)+128;
K8=Z7-((Z7>>8)<<8);
}else{
VK=Z7;
K8=0;
}

Oj.push(VK);
if(Z7>=128){
Oj.push(K8);
}
for(var Ny=0;Ny<Z7;Ny++){
Oj.push(f8[Ny]);
}
};





function xc(l4,xL){
var Iq=xL[0];
var Z7=l4[Iq];
if(Z7>=128){
Z7=(Z7-128)<<8;
Z7=Z7+l4[Iq+1];
Iq+=2;
}else{
Iq+=1;
}

var S5=eQ.b1(l4,Iq,Z7);
xL[0]=Iq+Z7;
return S5;
}



eQ.eb=function(aq){
var S5=new Array();
if(!aq){return jh.Y_(S5);}
var lr=aq.VO;
for(var co=0;co<lr.length;co++){
var G2=lr[co];
Zg(S5,G2);
Zg(S5,aq.tc(G2));
}
return jh.Y_(S5);
};


eQ.wj=function(l4){
if(!l4)return null;
var S5=new EW();
var Tj=null;
var Bh=new Array();
Bh[0]=0;
while(Bh[0]<l4.length){

var _W=xc(l4,Bh);
if(Tj==null){
Tj=_W;
}else{
S5.a9(Tj,_W);
Tj=null;
}
}
return S5;
};



}
Bg(eQ,"eQ");



function VI(){
var up=this;

function _d(){
up.Tw=[];
};

OZ(up,"So",cW);
function cW(){
var S5=up.Tw.length+3;
if(S5>=0x10000){
S5+=2;
}
return S5;
}

OZ(up,"VS",tH);
function tH(jl){
var n5=2;
var ic=up.So();
if(ic>=0x10000)n5=3;
eQ.NP(jl,n5);
eQ.REE(jl,ic);
var YR=up.Tw;
for(var co=0;co<YR.length;co++){
eQ.NP(jl,YR[co]);
}
}


OZ(up,"qN",hH);
function hH(jl){
var XM=eQ.q9(jl);
var n5=eQ.Jj(jl);
var x6=eQ.WfF(jl,((n5&1)==1));
var FCg=2;
if(x6>=0x10000)FCg+=2;

var x8;
if(n5==0){
x8=eQ.Kp(jl);
}else{
x8=x6-(1+FCg);
}
up.Tw.length=x8;
for(var co=0;co<x8;co++){
up.Tw[co]=eQ.Jj(jl);
}

var FK=XM+x6-eQ.q9(jl);
eQ.Pa(jl,FK);
}



OZ(up,"UE",DZ);
function DZ(Mh){
var NS=Mh.Tw.length;
up.Tw.length=NS;
for(var co=0;co<NS;co++){
up.Tw[co]=Mh.Tw[co];
}
}

OZ(up,"T3",Pl);
function Pl(){
return eQ.b1(up.Tw,0,-1);
}

OZ(up,"tg",lL);
function lL(nI){
up.Tw=va(nI);
}

if(up!=fj)_d.apply(up,arguments);
};
Bg(VI,"VI");

function dC(){
var up=this;

function _d(){
up.Tw=[];
}

OZ(up,"So",cW);
function cW(){
var S5=up.Tw.length+3;
if(S5>=0x10000){
S5+=2;
}
return S5;
}

OZ(up,"VS",tH);
function tH(jl){
var n5=1;
var ic=up.So();
if(ic>=0x10000)n5=3;
eQ.NP(jl,n5);
eQ.REE(jl,ic);
var YR=up.Tw;
for(var co=0;co<YR.length;co++){
eQ.NP(jl,YR[co]);
}
}

OZ(up,"qN",hH);
function hH(jl){
var XM=eQ.q9(jl);
var n5=eQ.Jj(jl);
var x6=eQ.WfF(jl,(n5==3));
var FCg=2;
if(x6>=0x10000)FCg+=2;

var x8;
if(n5==0){
x8=eQ.Kp(jl);
}else{
x8=x6-(1+FCg);
}
up.Tw.length=x8;
for(var co=0;co<x8;co++){
up.Tw[co]=eQ.Jj(jl);
}

var FK=XM+x6-eQ.q9(jl);
eQ.Pa(jl,FK);
}




OZ(up,"UE",DZ);
function DZ(Mh){
var NS=Mh.Tw.length;
up.Tw.length=NS;
for(var co=0;co<NS;co++){
up.Tw[co]=Mh.Tw[co];
}
}


OZ(up,"eb",Zm);
function Zm(E7){
up.Tw=eQ.eb(E7).UX();
}
OZ(up,"wj",Tn);
function Tn(){
return eQ.wj(up.Tw);
}

if(up!=fj)_d.apply(up,arguments);

};
Bg(dC,"dC");


function Ip(tL){
var F_=tL.split(",");
eQ.H_(F_.length>=2);
this.Sj=F_[0];
this.pf=this.Sj+"It";


this.fm=new Ar(F_[1]);
this.Dw=false;
this.K1=false;
this.IN=false;
this.lF=undefined;
if(this.Sj=="Kx"){
this.lF=eQ.Mr;
}
for(var co=2;co<F_.length;co++){
var JU=F_[co];

if(JU=="e"){
this.Dw=true;
continue;
}


if(JU.indexOf("d=")==0){
this.lF=JU.substr(2);
if(this.fm.sY=='Boolean'){
this.lF=Boolean(this.lF);
}else if(this.fm.sY=='Double'){
this.lF=parseFloat(this.lF);
}else if(this.fm.sY=='Integer'){
this.lF=parseInt(this.lF);
}else if(this.lF=="null"){
this.lF=null;
}else{
throw new Error("PBUtil: unrecognized default value: "+this.lF);
}
continue;
}


if(JU.indexOf("o=")==0){
var ZI=JU.substr(2).split(":");
eQ.H_(ZI.length==2);
this.K1=true;
this.R8=ZI[0]+"It";
this.GT=ZI[1];
continue;
}

if(JU.indexOf("c=")==0){
this.IN=true;
this.MC=JU.substr(2);
continue;
}
throw new Error("Unrecognized descriptor field "+JU);
}


if(this.lF===undefined){
this.lF=this.fm.lF;
}
if(this.fm.sY=='Integer'&&this.fm.mK==8){

if(this.fm.YZ){
this.lF=Q2.Ho(this.lF);
}else{
this.lF=L_.Ho(this.lF);
}
}


this.GR=function(Pu){
if(this.K1){
if((Pu[this.R8]&(1<<this.GT))==0){
return false;
}
}
if(this.IN){
return Ip.AY(this.MC,Pu);
}
return true;
};

}
yR(Ip,"Ip");



Ip.AY=function(LU,Pu){
if(LU=="true")return true;
if(LU=="false")return false;

if(LU.match(/^\d+$/))return parseInt(LU);


var xF=LU.match(/^([a-zA-Z0-9_]+)(\(\))?$/);
if(xF){
if(xF[2]=="()")
return Pu[xF[1]]();
else
return Pu[xF[1]];

}
throw new Error("PB: Cannot interpret expression: "+LU)
};


Ip.B6=function(x7){

var o2=[];
for(var co=1;co<arguments.length;co++){
o2.push(new Ip(arguments[co]));
}

x7.zw=o2;
};


Ip.ZF=function(x7,Kh){
for(var B4=0;B4<x7.zw.length;B4++){
var Kq=x7.zw[B4];
Kh(Kq);
}
};



Ip.Kt=function(Pu,KXI,x7){
Ip.ZF(x7,function(Kq){

if(Kq.Dw){
Pu["zj"+Kq.Sj]=true;
}
if(Kq.fm.sY=='Array'){

var pK=Kq.Sj+"rw";
Pu[pK]=[];

if(Kq.fm.hS!==undefined&&!Kq.K1){
Pu[pK].length=Ip.AY(Kq.fm.hS,Pu);
}

Pu[Kq.Sj+"XG"]=function(){
return Pu[pK].length;
};
Pu[Kq.Sj+"Gw"]=function(iK){
Pu[pK].length=iK;
if(Kq.K1){
Pu[Kq.R8]|=(1<<Kq.GT);
}
};
Pu[Kq.Sj+"bh"]=function(Ny){
eQ.H_(Ny<Pu[pK].length);
if(Kq.K1){
eQ.H_((Pu[Kq.R8]&(1<<Kq.GT))!=0);
}
return Pu[pK][Ny];
};
Pu[Kq.Sj+"XZ"]=function(Ny,Sk){
eQ.H_(Ny<Pu[pK].length);
if(Kq.K1){
eQ.H_((Pu[Kq.R8]&(1<<Kq.GT))!=0);
}
Pu[pK][Ny]=Sk;
};
Pu[Kq.Sj+"xz"]=function(){
if(Kq.K1){
eQ.H_((Pu[Kq.R8]&(1<<Kq.GT))!=0);
}
return jh.Y_(Pu[pK]);
};
Pu[Kq.Sj+"iy"]=function(QE){
Pu[pK]=QE.UX();
if(Kq.K1){
Pu[Kq.R8]|=(1<<Kq.GT);
}
};
}else{

Pu[Kq.pf]=Kq.lF;

ED(Pu,Kq.Sj,function(){
return Pu[Kq.pf];
});

if(Kq.Sj!="Kx"&&Kq.Sj!="ic"&&Kq.Sj!="on"){
Wf(Pu,Kq.Sj,function(Sk){
if(Kq.K1){
Pu[Kq.R8]|=(1<<Kq.GT);
}
if(Kq.Dw){
Pu["zj"+Kq.Sj]=true;
}
Pu[Kq.pf]=Sk;
});
}
}

if(Kq.K1||Kq.Dw||Kq.IN){
Pu["yW"+Kq.Sj]=function(){
if(Kq.Dw&&!Pu["zj"+Kq.Sj])return false;
return Kq.GR(Pu);
};
}
if(Kq.K1){
Pu["u2"+Kq.Sj]=function(){
Pu[Kq.R8]&=(~(1<<Kq.GT));
if(Kq.fm.sY=='Array'){
Pu[Kq.Sj+"rw"]=[];
}else{
Pu[Kq.pf]=Kq.lF;
}
};
}
});



Pu.So=function(){
var XX=0;
Ip.ZF(x7,function(Kq){
if(Kq.GR(Pu)){
XX+=Kq.fm.So(Pu,Kq.Sj);
}
});
if(XX>=0x10000){
XX+=2;
}
return XX;
};
ED(Pu,"fH",Pu.So);


Pu.qN=function(Ti){
var XM=eQ.q9(Ti);
Ip.ZF(x7,function(Kq){
if(Kq.Dw){
Pu["zj"+Kq.Sj]=(XM+Pu.ic>eQ.q9(Ti));
}
if((Kq.Dw||Kq.K1||Kq.IN)&&!Pu["yW"+Kq.Sj]()){
Pu[Kq.pf]=Kq.lF;
}else if(Kq.Sj=="ic"){
Pu[Kq.pf]=eQ.WfF(Ti,(Pu["on"+"It"]&1==1));
}else{
Kq.fm.qN(Ti,Pu,Kq.Sj);
}
if(Kq.Sj=="Kx"){
if(Pu[Kq.pf]!=eQ.Mr){
throw new Error(eQ.rb);
}
}
});
var FK=XM+Pu.icIt-eQ.q9(Ti);
eQ.Pa(Ti,FK);
};


Pu.VS=function(Ti){
var x6=Pu.So();
var n5=0;
if(x6>=0x10000)n5=1;
Ip.ZF(x7,function(Kq){
if(Kq.Sj=="Kx"){
eQ.Rw(Ti,eQ.Mr);
}else if(Kq.Sj=="on"){
eQ.NP(Ti,n5);
}else if(Kq.Sj=="ic"){
eQ.REE(Ti,x6);
}else if(Kq.GR(Pu)){
Kq.fm.VS(Ti,Pu,Kq.Sj);
}
});
};


Pu.UE=function(Mh){
Ip.ZF(x7,function(Kq){
if(Kq.GR(Pu)){
Kq.fm.UE(Mh,Pu,Kq.Sj);
}
});
};

};


function Ar(Pv){
var K2=Pv.substr(0,1);
this.lF=null;
switch(K2){
case 'u':
case 'i':
this.YZ=(K2=='u');
this.sY='Integer';
this.mK=parseInt(Pv.substr(1,1));
var ik=null;
var GS=null;
switch(Pv){
case 'u1':ik=eQ.Jj;GS=eQ.NP;break;
case 'u2':ik=eQ.Kp;GS=eQ.Rw;break;
case 'u4':ik=eQ.ip;GS=eQ.jU;break;
case 'u8':ik=eQ.CV;GS=eQ.Ch;break;
case 'i1':ik=eQ.x3;GS=eQ.oY;break;
case 'i2':ik=eQ.VA;GS=eQ._m;break;
case 'i4':ik=eQ.YV;GS=eQ.HT;break;
case 'i8':ik=eQ.mr;GS=eQ.Gx;break;
}
this.L4=ik;
this.mj=GS;
this.lF=0;
break;
case 'b':
this.sY='Boolean';
this.mK=1;
this.L4=eQ.gC;
this.mj=eQ.MO;
this.lF=false;
break;
case 'd':
this.sY='Double';
this.mK=8;
this.L4=eQ.Hu;
this.mj=eQ.x1;
this.lF=0.0;
break;
case 's':
this.sY='String';
this._V="VI";
break;
case 'm':
this.sY='Dictionary';
this._V="dC";
break;
case 'c':
this.sY='Custom';
this._V=Pv.substr(2);
break;
case 'a':
this.sY='Array';
var F_=Pv.substr(2).split(":");
this.zd=new Ar(F_[0]);
if(F_.length>1){
this.hS=F_[1];
}else{

this.hS=undefined;
}
break;
default:
throw new Error("Unrecognized type "+Pv);
}

var VL=function(sq,DW,Ny){
if(Ny===undefined){
return sq[DW+"It"];
}else{
return sq[DW][Ny];
}
};

var d0=function(Sk,sq,HE,Ny){
if(Ny===undefined){
sq[HE+"It"]=Sk;
}else{
sq[HE][Ny]=Sk;
}
};
if(K2=='c'||K2=='s'||K2=='m'){
this.LJ=false;
this.nE=function(LQ,HE,Ny){
var dl=VL(LQ,HE,Ny);
if(!dl){
var _6b=sHq(this._V);
dl=new _6b();
d0(dl,LQ,HE,Ny);
}
return dl;
};

this.So=function(LQ,HE,Ny){
var Fn=this.nE(LQ,HE,Ny);
return Fn.So();
};

this.qN=function(Ti,LQ,HE,Ny){
this.nE(LQ,HE,Ny).qN(Ti);
};
this.VS=function(Ti,LQ,HE,Ny){
VL(LQ,HE,Ny).VS(Ti);
};
this.UE=function(jN,LQ,HE,Ny){
this.nE(LQ,HE,Ny).UE(VL(jN,HE,Ny))
};
}
if(K2=='u'||K2=='i'||K2=='d'||K2=='b'){
this.LJ=true;
this.So=function(LQ,HE,Ny){
return this.mK;
};
this.qN=function(Ti,LQ,HE,Ny){
d0(this.L4(Ti),LQ,HE,Ny);
};
this.VS=function(Ti,LQ,HE,Ny){
this.mj(Ti,VL(LQ,HE,Ny));
};
this.UE=function(jN,LQ,HE,Ny){
d0(VL(jN,HE,Ny),LQ,HE,Ny);
};
}

if(K2=='a'){
this.LJ=false;
this.So=function(LQ,HE,Ny){
var pK=HE+"rw";
eQ.H_(Ny===undefined);
var XX=0;
var x8=LQ[pK].length;
if(this.hS===undefined){

if(x8>=0x8000){
XX+=4;
}else{
XX+=2;
}
}
for(var co=0;co<x8;co++){
XX+=this.zd.So(LQ,pK,co);
}
return XX;
};

this.qN=function(Ti,LQ,HE,Ny){
var pK=HE+"rw";
eQ.H_(Ny===undefined);
var x8;
if(this.hS!==undefined){
x8=Ip.AY(this.hS,LQ);
}else{

x8=eQ.jTz(Ti);
}
LQ[HE+"Gw"](x8);
for(var co=0;co<x8;co++){
this.zd.qN(Ti,LQ,pK,co);
}
};

this.VS=function(Ti,LQ,HE,Ny){
var pK=HE+"rw";
eQ.H_(Ny===undefined);
var x8=LQ[pK].length;
if(this.hS===undefined){
eQ.hvL(Ti,x8);
}
for(var co=0;co<x8;co++){
this.zd.VS(Ti,LQ,pK,co);
}
};

this.UE=function(jN,LQ,HE,Ny){
var pK=HE+"rw";
eQ.H_(Ny===undefined);

LQ[HE+"Gw"](jN[pK].length);
var x8=LQ[pK].length;
for(var co=0;co<x8;co++){
this.zd.UE(jN,LQ,pK,co);
}
};
}
}
yR(Ar,"Ar");















function CandidateStream(){
var up=this;








function ju(kQ,Su,w6){
up.kQ=kQ;
up.Su=Su;
up.w6=w6;
}




OZ(up,"wy",NQ);OZ(up,"Cleanup",NQ);
function NQ(){
up.kQ=null;
up.Su=0;
up.w6=null;
}







if(up!=fj)up._cW=undefined;
ED(up,"kQ",d4);ED(up,"id",d4);
function d4(){return up._cW;}
Wf(up,"kQ",J_F);Wf(up,"id",J_F);
function J_F(nQ){up._cW=nQ;}








if(up!=fj)up.mkQ=undefined;
ED(up,"Su",jtC);ED(up,"bitrate",jtC);
function jtC(){return up.mkQ;}
Wf(up,"Su",HQn);Wf(up,"bitrate",HQn);
function HQn(nQ){up.mkQ=nQ;}








if(up!=fj)up.CE_=undefined;
ED(up,"w6",dO);ED(up,"resource",dO);
function dO(){return up.CE_;}
Wf(up,"w6",pl3);Wf(up,"resource",pl3);
function pl3(nQ){up.CE_=nQ;}
















OZ(up,"OeK",PdJ);OZ(up,"CheckValidity",PdJ);
function PdJ(){

if(up.kQ!=null&&!((typeof up.kQ==="string"))){
return "CandidateStream.id is not a string";
}else if(up.Su!=null&&!((typeof up.Su==="number"))){
return "CandidateStream.bitrate is not an int";
}else if(up.w6!=null&&!((typeof up.w6==="string"))){
return "CandidateStream.resource is not a string";
}
return null;
}





dN(up,CandidateStream,"QKZ",UuP);dN(up,CandidateStream,"ConstructClone",UuP);
function UuP(lGX){
if(lGX==null)return null;

return lGX;
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(CandidateStream,"CandidateStream");






















function kzq(){
var up=this;
function ju(nEe){
up.vtd=nEe;
}

if(up!=fj)up.vtd=undefined;

OZ(up,"o0d",qXj);
function qXj(){
var LC=new ConvivaContentInfo(up.REQ(),up.VNO(),up.YhP());

if(up.mv4()){
LC.fi=up.inN();
}
LC.N_=up.adg();
LC.cex=up.qaO();
LC.Su=up.n4x();
LC._fK=up.Iom();
LC.w6=up.RhM();
LC.xQh=up.ArX();
LC.o6d=up.v8h();
LC.yuB=up.XJR();
LC.lTq=up.BRI();
LC.nFQ=up.rTo();
LC.eQZ=up.eMb();
LC.Jqo=up.ThB();
LC.wL2=up.EYb();
LC.alT=up._Y8();
LC.qMR=up.ieU();
LC.hTs=up.c_7();
LC.TMi=up.R9p();
LC.oP9=VW.z_(up.V5s());
return LC;
}

OZ(up,"REQ",m6g);
function m6g(){
if(up.vtd!=null){
return up.vtd.REQ();
}else{
return null;
}
}

OZ(up,"VNO",mdj);
function mdj(){
if(up.vtd!=null){
return up.vtd.VNO();
}else{
return null;
}
}

OZ(up,"YhP",oTV);
function oTV(){
if(up.vtd!=null){
return up.vtd.YhP();
}else{
return null;
}
}




OZ(up,"mv4",IK2);
function IK2(){
if(up.vtd!=null){
return up.vtd.mv4();
}else{
return false;
}
}

OZ(up,"inN",X8A);
function X8A(){
if(up.vtd!=null){
return up.vtd.inN();
}else{
return false;
}
}

OZ(up,"adg",H7I);
function H7I(){
if(up.vtd!=null){
return up.vtd.adg();
}else{
return null;
}
}

OZ(up,"qaO",H0W);
function H0W(){
if(up.vtd!=null){
return up.vtd.qaO();
}else{
return false;
}
}

OZ(up,"n4x",M9P);
function M9P(){
if(up.vtd!=null){
return up.vtd.n4x();
}else{
return ConvivaContentInfo.RKy;
}
}

OZ(up,"Iom",w71);
function w71(){
if(up.vtd!=null){
return up.vtd.Iom();
}else{
return ConvivaContentInfo.jNU;
}
}

OZ(up,"RhM",D_q);
function D_q(){
if(up.vtd!=null){
return up.vtd.RhM();
}else{
return null;
}
}

OZ(up,"c_7",SNm);
function SNm(){
if(up.vtd!=null){
return up.vtd.c_7();
}else{
return null;
}
}

OZ(up,"ArX",mbi);
function mbi(){
if(up.vtd!=null){
return up.vtd.ArX();
}else{
return null;
}
}

OZ(up,"rTo",Q9h);
function Q9h(){
if(up.vtd!=null){
return up.vtd.rTo();
}else{
return null;
}
}

OZ(up,"eMb",Id7);
function Id7(){
if(up.vtd!=null){
return up.vtd.eMb();
}else{
return null;
}
}

OZ(up,"ThB",rg1);
function rg1(){
if(up.vtd!=null){
return up.vtd.ThB();
}else{
return null;
}
}

OZ(up,"EYb",NsI);
function NsI(){
if(up.vtd!=null){
return up.vtd.EYb();
}else{
return null;
}
}

OZ(up,"_Y8",JsD);
function JsD(){
if(up.vtd!=null){
return up.vtd._Y8();
}else{
return null;
}
}

OZ(up,"v8h",HnS);
function HnS(){
if(up.vtd!=null){
return up.vtd.v8h();
}else{
return null;
}
}

OZ(up,"XJR",jok);
function jok(){
if(up.vtd!=null){
return up.vtd.XJR();
}else{
return null;
}
}

OZ(up,"BRI",wqG);
function wqG(){
if(up.vtd!=null){
return up.vtd.BRI();
}else{
return null;
}
}

OZ(up,"ieU",wEU);
function wEU(){
if(up.vtd!=null){
return up.vtd.ieU();
}else{
return null;
}
}

OZ(up,"R9p",wQJ);
function wQJ(){
if(up.vtd!=null){
return up.vtd.R9p();
}else{
return 0;
}
}

OZ(up,"V5s",tZ7);
function tZ7(){
if(up.vtd!=null){
return up.vtd.V5s();
}else{
return 0;
}
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(kzq,"kzq");



















function ConvivaContentInfo(){
var up=this;


























































if(up==fj)ConvivaContentInfo.r9f="AKAMAI";

if(up==fj)ConvivaContentInfo.GGN="AMAZON";

if(up==fj)ConvivaContentInfo.fGO="ATT";

if(up==fj)ConvivaContentInfo.mYS="BITGRAVITY";

if(up==fj)ConvivaContentInfo.BD8="BT";

if(up==fj)ConvivaContentInfo.jkP="CDNETWORKS";

if(up==fj)ConvivaContentInfo.J01="CDNVIDEO";

if(up==fj)ConvivaContentInfo.OU6="CHINACACHE";

if(up==fj)ConvivaContentInfo.RH2="COMCAST";

if(up==fj)ConvivaContentInfo.LZN="EDGECAST";

if(up==fj)ConvivaContentInfo.Qye="HIGHWINDS";

if(up==fj)ConvivaContentInfo.GDQ="INTERNAP";

if(up==fj)ConvivaContentInfo.mB6="IPONLY";

if(up==fj)ConvivaContentInfo.BRL="LEVEL3";

if(up==fj)ConvivaContentInfo.jbi="LIMELIGHT";

if(up==fj)ConvivaContentInfo.LBr="MICROSOFT";

if(up==fj)ConvivaContentInfo.eOQ="NGENIX";

if(up==fj)ConvivaContentInfo.pwl="NICE";

if(up==fj)ConvivaContentInfo.y1x="OCTOSHAPE";

if(up==fj)ConvivaContentInfo.J6r="QBRICK";

if(up==fj)ConvivaContentInfo.rNL="SWARMCAST";

if(up==fj)ConvivaContentInfo.mih="TELEFONICA";

if(up==fj)ConvivaContentInfo.MHE="TELENOR";

if(up==fj)ConvivaContentInfo.CVv="VELOCIX";

if(up==fj)ConvivaContentInfo.vk7="TALKTALK";

if(up==fj)ConvivaContentInfo.MuN="FASTLY";





if(up==fj)ConvivaContentInfo.ZGk="INHOUSE";




if(up==fj)ConvivaContentInfo.jNU="OTHER";


if(up==fj)ConvivaContentInfo._jw="Brightcove";

if(up==fj)ConvivaContentInfo.RAm="Kaltura";

if(up==fj)ConvivaContentInfo.Pwz="Ooyala";

if(up==fj)ConvivaContentInfo.x4Q="thePlatform";


if(up==fj)ConvivaContentInfo.Ot6="Brightcove";

if(up==fj)ConvivaContentInfo.ycR="Kaltura";

if(up==fj)ConvivaContentInfo.jPN="Ooyala";

if(up==fj)ConvivaContentInfo.fMQ="OSMF";

if(up==fj)ConvivaContentInfo.alw="thePlatform";


if(up==fj)ConvivaContentInfo.fSH="Console";

if(up==fj)ConvivaContentInfo.wdm="Mobile";

if(up==fj)ConvivaContentInfo.mMX="PC";

if(up==fj)ConvivaContentInfo.G1s="Settop";




if(up==fj)ConvivaContentInfo._6t="no_resource";


if(up==fj)ConvivaContentInfo.Ld2="ConvivaKalturaPlugin";


if(up==fj)ConvivaContentInfo.uf3="nominalBitrateOverride";









if(up!=fj)up.a4c=false;










ED(up,"K_y",oZN);ED(up,"useStrictChecking",oZN);
function oZN(){return up.a4c;}
Wf(up,"K_y",YiA);Wf(up,"useStrictChecking",YiA);
function YiA(nQ){up.a4c=nQ;}

if(up!=fj)up.i6m=null;




ED(up,"CXF",IBV);ED(up,"assetName",IBV);
function IBV(){return up.i6m;}
Wf(up,"CXF",SMB);Wf(up,"assetName",SMB);
function SMB(nQ){up.i6m=nQ;}

if(up!=fj)up.rT7=undefined;





ED(up,"hA",ml);ED(up,"tags",ml);
function ml(){return oL.uM(up.rT7);}
Wf(up,"hA",gn);Wf(up,"tags",gn);
function gn(nQ){up.rT7=oL.PX(nQ);}

if(up!=fj)up.ta=undefined;




ED(up,"Sc",FZ);ED(up,"candidateResources",FZ);
function FZ(){return oL.R5(up.ta);}
Wf(up,"Sc",vQ);Wf(up,"candidateResources",vQ);
function vQ(nQ){
up.ta=oL.js(nQ);
}

if(up!=fj)up.oLs=false;


ED(up,"fi",fWP);ED(up,"resourceSelection",fWP);
function fWP(){return up.oLs;}
Wf(up,"fi",E8J);Wf(up,"resourceSelection",E8J);
function E8J(nQ){up.oLs=nQ;}

if(up!=fj)up.wwE=undefined;






















ED(up,"N_",C7);ED(up,"monitoringOptions",C7);
function C7(){return oL.uM(up.wwE);}
Wf(up,"N_",Bv);Wf(up,"monitoringOptions",Bv);
function Bv(nQ){up.wwE=oL.PX(nQ);}

if(up!=fj)up.LUA=null;













ED(up,"_fK",VUf);ED(up,"cdnName",VUf);
function VUf(){return up.LUA;}
Wf(up,"_fK",j6i);Wf(up,"cdnName",j6i);
function j6i(nQ){up.LUA=nQ;}





if(up!=fj)up.BYE=null;

if(up!=fj)up.wUp=null;

















ED(up,"hTs",M0F);ED(up,"resourceStateOverride",M0F);
function M0F(){return up.wUp;}
Wf(up,"hTs",fEY);Wf(up,"resourceStateOverride",fEY);
function fEY(nQ){up.wUp=nQ;}

if(up!=fj)up.D3q=null;











ED(up,"nFQ",XWl);ED(up,"ovppName",XWl);
function XWl(){return up.D3q;}
Wf(up,"nFQ",acQ);Wf(up,"ovppName",acQ);
function acQ(nQ){up.D3q=nQ;}

if(up!=fj)up.Db8=null;













ED(up,"eQZ",mH1);ED(up,"frameworkName",mH1);
function mH1(){return up.Db8;}
Wf(up,"eQZ",cx_);Wf(up,"frameworkName",cx_);
function cx_(nQ){up.Db8=nQ;}

if(up!=fj)up.TSp=null;








ED(up,"Jqo",YNQ);ED(up,"frameworkVersion",YNQ);
function YNQ(){return up.TSp;}
Wf(up,"Jqo",hHp);Wf(up,"frameworkVersion",hHp);
function hHp(nQ){up.TSp=nQ;}

if(up!=fj)up.IFU=null;











ED(up,"wL2",BVV);ED(up,"pluginName",BVV);
function BVV(){return up.IFU;}
Wf(up,"wL2",m7Y);Wf(up,"pluginName",m7Y);
function m7Y(nQ){up.IFU=nQ;}

if(up!=fj)up.XTh=null;










ED(up,"alT",KHz);ED(up,"pluginVersion",KHz);
function KHz(){return up.XTh;}
Wf(up,"alT",wTu);Wf(up,"pluginVersion",wTu);
function wTu(nQ){up.XTh=nQ;}

if(up!=fj)up.m6e=null;






ED(up,"o6d",ix_);ED(up,"viewerId",ix_);
function ix_(){return up.m6e;}
Wf(up,"o6d",Cgn);Wf(up,"viewerId",Cgn);
function Cgn(nQ){up.m6e=nQ;}

if(up!=fj)up.Ndb=null;










ED(up,"yuB",i0y);ED(up,"deviceId",i0y);
function i0y(){return up.Ndb;}
Wf(up,"yuB",Vmw);Wf(up,"deviceId",Vmw);
function Vmw(nQ){up.Ndb=nQ;}

if(up!=fj)up.J24=null;











ED(up,"lTq",OHw);ED(up,"deviceType",OHw);
function OHw(){return up.J24;}
Wf(up,"lTq",bmQ);Wf(up,"deviceType",bmQ);
function bmQ(nQ){
if(nQ!=null){
if(up.U8U.OC(nQ)){
up.J24=nQ;
}else{
ct.M3x("deviceType is not one of the recognized device types enumerated in ConvivaContentInfo.",
"Actual value: "+up.lTq+" . Set it to the default value PC.");
up.J24=ConvivaContentInfo.mMX;
}
}
}





if(up!=fj)up.U8U=null;

if(up!=fj)up.tUj=null;







ED(up,"qMR",WNr);ED(up,"playerName",WNr);
function WNr(){return up.tUj;}
Wf(up,"qMR",tz2);Wf(up,"playerName",tz2);
function tz2(nQ){up.tUj=nQ;}

if(up!=fj)up.t8r=null;







ED(up,"xQh",vS5);ED(up,"streamUrl",vS5);
function vS5(){return up.t8r;}
Wf(up,"xQh",Oib);Wf(up,"streamUrl",Oib);
function Oib(nQ){up.t8r=nQ;}

if(up==fj)ConvivaContentInfo.RKy=0;
if(up!=fj)up.fGP=ConvivaContentInfo.RKy;





ED(up,"Su",jtC);ED(up,"bitrate",jtC);
function jtC(){return up.fGP;}
Wf(up,"Su",HQn);Wf(up,"bitrate",HQn);
function HQn(nQ){up.fGP=nQ;}

if(up!=fj)up.r_o=false;





ED(up,"cex",Dz4);ED(up,"isLive",Dz4);
function Dz4(){return up.r_o;}
Wf(up,"cex",j4I);Wf(up,"isLive",j4I);
function j4I(nQ){
if(nQ==="true"){nQ=true;}
if(nQ==="false"){nQ=false;}
if(nQ!==true&&nQ!==false){
ct.Error("Invalid value for ConvivaContentInfo.isLive, expected boolean. Defaulting to false.");
nQ=false;
}
up.r_o=nQ;
}

if(up!=fj)up.go=null;











ED(up,"w6",dO);ED(up,"resource",dO);
function dO(){return up.go;}
Wf(up,"w6",pl3);Wf(up,"resource",pl3);
function pl3(nQ){up.go=nQ;}

if(up!=fj)up.FCX=0;






ED(up,"TMi",nql);ED(up,"groupId",nql);
function nql(){return up.FCX;}
Wf(up,"TMi",kaQ);Wf(up,"groupId",kaQ);
function kaQ(nQ){up.FCX=nQ;}

if(up!=fj)up.qAd=0;




ED(up,"oP9",g_3);ED(up,"groupType",g_3);
function g_3(){return up.qAd;}
Wf(up,"oP9",emE);Wf(up,"groupType",emE);
function emE(nQ){up.qAd=nQ;}






if(up==fj)ConvivaContentInfo.L1=128;

if(up==fj)ConvivaContentInfo.prP="Null title";









function ju(akg,Cr,Or){
up.SR4();
up.K_y=false;
up.CXF=akg;
up.hA=Or;
if(up.rT7==null){
up.rT7=new EW();
}


up.Sc=Cr;
up.fi=false;
if(up.ta==null){
up.ta=new Yw();
}
up.wwE=new EW();
up.fGP=0;
up.r_o=false;
up.FCX=0;
up.qAd=0;
}








dN(up,ConvivaContentInfo,"XxO",EDi);dN(up,ConvivaContentInfo,"createInfoForLightSession",EDi);
function EDi(CXF){
var LC=new ConvivaContentInfo(CXF,null,null);
return LC;
}


OZ(up,"ox",gv);OZ(up,"cleanup",gv);
function gv(){
up.FCX=0;
up.qAd=0;
}




OZ(up,"AV",_H);OZ(up,"sanitizeData",_H);
function _H(){
up.CXF=ConvivaContentInfo._C(up.CXF,ConvivaContentInfo.prP,true,"assetName");
up.nFQ=ConvivaContentInfo._C(up.nFQ,null,false,"ovppName");
up.eQZ=ConvivaContentInfo._C(up.eQZ,null,false,"frameworkName");
up.Jqo=ConvivaContentInfo._C(up.Jqo,null,false,"frameworkVersion");
up.wL2=ConvivaContentInfo._C(up.wL2,null,false,"pluginName");
up.alT=ConvivaContentInfo._C(up.alT,null,false,"pluginVersion");
up.o6d=ConvivaContentInfo._C(up.o6d,null,false,"viewerId");
up.yuB=ConvivaContentInfo._C(up.yuB,null,false,"deviceId");
up.lTq=ConvivaContentInfo._C(up.lTq,null,false,"deviceType");
up.qMR=ConvivaContentInfo._C(up.qMR,null,false,"playerName");

if(up.rT7==null){
up.rT7=new EW();
}

var WG=new Yw();
var bC=up.rT7.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var BK=bC[Jo];

WG.Yb(BK);
}
var HH=WG.YC;
for(var wt=0;wt<HH.length;wt++){
var VF=HH[wt];




var Gn=ConvivaContentInfo._C(VF,"null",false,"tag name");
var Jm=ConvivaContentInfo._C(up.rT7.tc(VF),"null",false,"value for tag '"+oL.fg(VF)+"'");
if(Gn!=VF){
up.rT7.gS(VF);
up.rT7.a9(Gn,Jm);
}
if(Jm!=up.rT7.tc(Gn)){
up.rT7.a9(Gn,Jm);
}
}




}


dN(up,ConvivaContentInfo,"_C",q6);dN(up,ConvivaContentInfo,"sanitizeString",q6);
function q6(nI,Rd,vH,Sj){
if(nI==null&&Rd==null){
return null;
}

if(nI==null){
O9.Ep("ConvivaContentInfo: "+Sj+" is null",false);
nI=Rd;
}
var h7=oL.fg(nI);
h7=oL.xO(h7);


if(vH&&h7==O9.Mul){

}else if(h7.length>=3&&oL.n0(h7,0,3)=="c3."){
O9.Ep("ConvivaContentInfo: "+Sj+" is reserved IGNORE:"+h7,false);
h7="_"+h7;
}

if(h7.length>ConvivaContentInfo.L1){
O9.Ep("ConvivaContentInfo: "+Sj+" is too long IGNORE:"+h7,false);
h7=oL.n0(h7,0,ConvivaContentInfo.L1);
}
return h7;
}

LK(up,"SR4",lPt);
function lPt(){
up.BYE=new Yw();
up.BYE.Yb(ConvivaContentInfo.r9f);
up.BYE.Yb(ConvivaContentInfo.GGN);
up.BYE.Yb(ConvivaContentInfo.fGO);
up.BYE.Yb(ConvivaContentInfo.mYS);
up.BYE.Yb(ConvivaContentInfo.BD8);
up.BYE.Yb(ConvivaContentInfo.jkP);
up.BYE.Yb(ConvivaContentInfo.OU6);
up.BYE.Yb(ConvivaContentInfo.LZN);
up.BYE.Yb(ConvivaContentInfo.Qye);
up.BYE.Yb(ConvivaContentInfo.GDQ);
up.BYE.Yb(ConvivaContentInfo.BRL);
up.BYE.Yb(ConvivaContentInfo.jbi);
up.BYE.Yb(ConvivaContentInfo.y1x);
up.BYE.Yb(ConvivaContentInfo.rNL);
up.BYE.Yb(ConvivaContentInfo.CVv);
up.BYE.Yb(ConvivaContentInfo.mih);
up.BYE.Yb(ConvivaContentInfo.LBr);
up.BYE.Yb(ConvivaContentInfo.J01);
up.BYE.Yb(ConvivaContentInfo.J6r);
up.BYE.Yb(ConvivaContentInfo.eOQ);
up.BYE.Yb(ConvivaContentInfo.mB6);
up.BYE.Yb(ConvivaContentInfo.ZGk);
up.BYE.Yb(ConvivaContentInfo.RH2);
up.BYE.Yb(ConvivaContentInfo.pwl);
up.BYE.Yb(ConvivaContentInfo.MHE);
up.BYE.Yb(ConvivaContentInfo.vk7);
up.BYE.Yb(ConvivaContentInfo.MuN);
up.BYE.Yb(ConvivaContentInfo.jNU);
up.U8U=new Yw();
up.U8U.Yb(ConvivaContentInfo.fSH);
up.U8U.Yb(ConvivaContentInfo.wdm);
up.U8U.Yb(ConvivaContentInfo.mMX);
up.U8U.Yb(ConvivaContentInfo.G1s);
}



LK(up,"c_",iD);
function iD(){
var cN="{";
cN+="\n  useStrictChecking="+oL.fg(up.a4c);
cN+="\n  assetName=\""+up.i6m+"\"";
cN+="\n  bitrate="+oL.fg(up.fGP);
cN+="\n  isLive="+oL.fg(up.r_o);
cN+="\n  monitoringOptions="+Gnw.jMw(up.wwE);
cN+="\n  resourceSelection="+oL.fg(up.oLs);
cN+="\n  candidateResources="+Gnw.hJD(up.ta);
cN+="\n  cdnName="+(up._fK!=null?"\""+up._fK+"\"":"null");
cN+="\n  resource="+(up.w6!=null?"\""+up.w6+"\"":"null");
cN+="\n  resourceStateOverride="+(up.hTs!=null?"\""+up.hTs+"\"":"null");
cN+="\n  ovppName="+(up.nFQ!=null?"\""+up.nFQ+"\"":"null");
cN+="\n  frameworkName="+(up.eQZ!=null?"\""+up.eQZ+"\"":"null");
cN+="\n  frameworkVersion="+(up.Jqo!=null?"\""+up.Jqo+"\"":"null");
cN+="\n  pluginName="+(up.wL2!=null?"\""+up.wL2+"\"":"null");
cN+="\n  pluginVersion="+(up.alT!=null?"\""+up.alT+"\"":"null");
cN+="\n  streamUrl="+(up.xQh!=null?"\""+up.xQh+"\"":"null");
cN+="\n  viewerId="+(up.o6d!=null?"\""+up.o6d+"\"":"null");
cN+="\n  deviceId="+(up.yuB!=null?"\""+up.yuB+"\"":"null");
cN+="\n  deviceType="+(up.lTq!=null?"\""+up.lTq+"\"":"null");
cN+="\n  playerName="+(up.qMR!=null?"\""+up.qMR+"\"":"null");
cN+="\n  groupId="+oL.fg(up.FCX);
cN+="\n  groupType="+oL.fg(up.qAd);
cN+="\n  tags="+Gnw.jMw(up.rT7);
return cN;
}




dN(up,ConvivaContentInfo,"o1",b0);dN(up,ConvivaContentInfo,"clone",b0);
function b0(jN){




jN.AV(false);
return jN;
}

OZ(up,"obv",Ep9);OZ(up,"printContentInfo",Ep9);
function Ep9(Bl){
ct.qF("ConvivaContentInfo["+Bl+"]","user input="+up.c_());
}



















OZ(up,"XUT",rxV);OZ(up,"checkValidity",rxV);
function rxV(kZl,IiH,V7){
if(!up.K_y){
kZl=IiH;
}
if(up.CXF==null){
kZl("assetName is null.",null);
}
if(up.CXF==ConvivaContentInfo.prP){
kZl("assetName is null.",null);
}
if(up.lTq!=null&&!up.U8U.OC(up.lTq)){
kZl("deviceType is not one of the recognized device types enumerated in ConvivaContentInfo.",
"Actual value: "+up.lTq+" .");
}
if(V7){
if(up.hTs!=null){
IiH("resourceStateOverride is in use.  CDN-based metrics may be inaccurate.",null);

}else{
if(up._fK==null){
kZl("cdnName is null.",null);
}
if(up._fK!=null&&!up.BYE.OC(up._fK)){
kZl("cdnName is not one of the recognized CDN names enumerated in ConvivaContentInfo.",
"Actual value: "+up._fK+" .");
}
if(up._fK==ConvivaContentInfo.jNU){
IiH("cdnName is CDN_NAME_OTHER.  If possible, please specify a real CDN.",null);
}
}
if(up.xQh==null){
kZl("streamUrl is null.",null);
}




if(up.Su<0){
kZl("bitrate is negative.","Actual value: "+up.Su+" .");
}
}
}

dN(up,ConvivaContentInfo,"CDN_NAME_AKAMAI",ConvivaContentInfo.r9f);
dN(up,ConvivaContentInfo,"CDN_NAME_AMAZON",ConvivaContentInfo.GGN);
dN(up,ConvivaContentInfo,"CDN_NAME_ATT",ConvivaContentInfo.fGO);
dN(up,ConvivaContentInfo,"CDN_NAME_BITGRAVITY",ConvivaContentInfo.mYS);
dN(up,ConvivaContentInfo,"CDN_NAME_BT",ConvivaContentInfo.BD8);
dN(up,ConvivaContentInfo,"CDN_NAME_CDNETWORKS",ConvivaContentInfo.jkP);
dN(up,ConvivaContentInfo,"CDN_NAME_CDNVIDEO",ConvivaContentInfo.J01);
dN(up,ConvivaContentInfo,"CDN_NAME_CHINACACHE",ConvivaContentInfo.OU6);
dN(up,ConvivaContentInfo,"CDN_NAME_COMCAST",ConvivaContentInfo.RH2);
dN(up,ConvivaContentInfo,"CDN_NAME_EDGECAST",ConvivaContentInfo.LZN);
dN(up,ConvivaContentInfo,"CDN_NAME_FASTLY",ConvivaContentInfo.MuN);
dN(up,ConvivaContentInfo,"CDN_NAME_HIGHWINDS",ConvivaContentInfo.Qye);
dN(up,ConvivaContentInfo,"CDN_NAME_INHOUSE",ConvivaContentInfo.ZGk);
dN(up,ConvivaContentInfo,"CDN_NAME_INTERNAP",ConvivaContentInfo.GDQ);
dN(up,ConvivaContentInfo,"CDN_NAME_IPONLY",ConvivaContentInfo.mB6);
dN(up,ConvivaContentInfo,"CDN_NAME_LEVEL3",ConvivaContentInfo.BRL);
dN(up,ConvivaContentInfo,"CDN_NAME_LIMELIGHT",ConvivaContentInfo.jbi);
dN(up,ConvivaContentInfo,"CDN_NAME_MICROSOFT",ConvivaContentInfo.LBr);
dN(up,ConvivaContentInfo,"CDN_NAME_NGENIX",ConvivaContentInfo.eOQ);
dN(up,ConvivaContentInfo,"CDN_NAME_NICE",ConvivaContentInfo.pwl);
dN(up,ConvivaContentInfo,"CDN_NAME_OCTOSHAPE",ConvivaContentInfo.y1x);
dN(up,ConvivaContentInfo,"CDN_NAME_OTHER",ConvivaContentInfo.jNU);
dN(up,ConvivaContentInfo,"CDN_NAME_QBRICK",ConvivaContentInfo.J6r);
dN(up,ConvivaContentInfo,"CDN_NAME_SWARMCAST",ConvivaContentInfo.rNL);
dN(up,ConvivaContentInfo,"CDN_NAME_TALKTALK",ConvivaContentInfo.vk7);
dN(up,ConvivaContentInfo,"CDN_NAME_TELEFONICA",ConvivaContentInfo.mih);
dN(up,ConvivaContentInfo,"CDN_NAME_TELENOR",ConvivaContentInfo.MHE);
dN(up,ConvivaContentInfo,"CDN_NAME_VELOCIX",ConvivaContentInfo.CVv);
dN(up,ConvivaContentInfo,"DEFAULT_ASSET_NAME",ConvivaContentInfo.prP);
dN(up,ConvivaContentInfo,"DEFAULT_BITRATE_VAL",ConvivaContentInfo.RKy);
dN(up,ConvivaContentInfo,"DEVICE_TYPE_CONSOLE",ConvivaContentInfo.fSH);
dN(up,ConvivaContentInfo,"DEVICE_TYPE_MOBILE",ConvivaContentInfo.wdm);
dN(up,ConvivaContentInfo,"DEVICE_TYPE_PC",ConvivaContentInfo.mMX);
dN(up,ConvivaContentInfo,"DEVICE_TYPE_SET_TOP_BOX",ConvivaContentInfo.G1s);
dN(up,ConvivaContentInfo,"FRAMEWORK_NAME_BRIGHTCOVE",ConvivaContentInfo.Ot6);
dN(up,ConvivaContentInfo,"FRAMEWORK_NAME_KALTURA",ConvivaContentInfo.ycR);
dN(up,ConvivaContentInfo,"FRAMEWORK_NAME_OOYALA",ConvivaContentInfo.jPN);
dN(up,ConvivaContentInfo,"FRAMEWORK_NAME_OSMF",ConvivaContentInfo.fMQ);
dN(up,ConvivaContentInfo,"FRAMEWORK_NAME_THE_PLATFORM",ConvivaContentInfo.alw);
dN(up,ConvivaContentInfo,"MAX_PARAMETER_LENGTH",ConvivaContentInfo.L1);
dN(up,ConvivaContentInfo,"MO_KEY_NOMINAL_BITRATE_OVERRIDE",ConvivaContentInfo.uf3);
dN(up,ConvivaContentInfo,"NO_RESOURCE",ConvivaContentInfo._6t);
dN(up,ConvivaContentInfo,"OVPP_NAME_BRIGHTCOVE",ConvivaContentInfo._jw);
dN(up,ConvivaContentInfo,"OVPP_NAME_KALTURA",ConvivaContentInfo.RAm);
dN(up,ConvivaContentInfo,"OVPP_NAME_OOYALA",ConvivaContentInfo.Pwz);
dN(up,ConvivaContentInfo,"OVPP_NAME_THE_PLATFORM",ConvivaContentInfo.x4Q);
dN(up,ConvivaContentInfo,"PLUGIN_NAME_KALTURA",ConvivaContentInfo.Ld2);
if(up!=fj)ju.apply(up,arguments);
}
Bg(ConvivaContentInfo,"ConvivaContentInfo");











function ConvivaNotification(){
var up=this;

if(up==fj)ConvivaNotification.g9=0;




if(up==fj)ConvivaNotification.rg=1;




if(up==fj)ConvivaNotification.cf=2;





if(up==fj)ConvivaNotification.bQ=10;




if(up==fj)ConvivaNotification.vU=11;




if(up==fj)ConvivaNotification.HBx=20;




if(up==fj)ConvivaNotification.Po=30;




if(up!=fj)up.kF=undefined;

function ju(iv,message,jz){
up.kF=new EW();
up.kF.a9("code",iv);
up.kF.a9("message",message);
up.kF.a9("objectId",jz);
}





ED(up,"iv",bc);ED(up,"code",bc);
function bc(){
return VW.z_(up.kF.tc("code"));
}





ED(up,"message",xs);ED(up,"message",xs);
function xs(){
return up.kF.tc("message");
}






ED(up,"jz",wa);ED(up,"objectId",wa);
function wa(){
return up.kF.tc("objectId");
}



OZ(up,"toString",vZ);OZ(up,"toString",vZ);
function vZ(){
var S5="ConvivaNotification ";
var l8m=oL.fg(up.iv);
if(l8m!=null){
S5=S5+"("+l8m+"): ";
}
if(up.message!=null){
S5=S5+up.message;
}
if(up.jz!=null){
S5=S5+" (for objectId "+up.jz+")";
}
return S5;
}

dN(up,ConvivaNotification,"ERROR_ARGUMENT",ConvivaNotification.rg);
dN(up,ConvivaNotification,"ERROR_INIT_TIMESOUT",ConvivaNotification.HBx);
dN(up,ConvivaNotification,"ERROR_LIVEPASS_NOT_READY",ConvivaNotification.cf);
dN(up,ConvivaNotification,"ERROR_LOAD_CONFIGURATION",ConvivaNotification.bQ);
dN(up,ConvivaNotification,"ERROR_LOAD_MODULE",ConvivaNotification.vU);
dN(up,ConvivaNotification,"ERROR_METRICS_QUOTA_EXCEEDED",ConvivaNotification.Po);
dN(up,ConvivaNotification,"SUCCESS_LIVEPASS_READY",ConvivaNotification.g9);
if(up!=fj)ju.apply(up,arguments);
}
Bg(ConvivaNotification,"ConvivaNotification");












































































function ConvivaStreamerProxy(){
var up=this;

if(up!=fj)up.Mqe=new Yw();


if(up!=fj)up.UQZ=new StreamInfo(-1,ConvivaContentInfo.jNU,ConvivaContentInfo._6t,-1,-1,-1);
if(up!=fj)up.OjE=ConvivaStreamerProxy.dHj;


if(up!=fj)up.fDr=null;


if(up!=fj)up.sOE=null;

if(up!=fj)up.FvG=new Yw();



if(up!=fj)up.BaK=-1;


if(up!=fj)up.H7g=-1;


if(up!=fj)up.Hfe=null;

if(up!=fj)up.fx3=null;

if(up!=fj)up.BW7=undefined;






if(up==fj)ConvivaStreamerProxy.yeD="PlayingStateChange";






if(up==fj)ConvivaStreamerProxy.xUm="StreamInfoChange";





if(up==fj)ConvivaStreamerProxy.pOB="AvailableStreamInfoChange";






if(up==fj)ConvivaStreamerProxy.U6H="ProxyInitialized";





if(up==fj)ConvivaStreamerProxy.GMW="MetadataChange";






if(up==fj)ConvivaStreamerProxy.kTl="LoadingStatusChange";





if(up==fj)ConvivaStreamerProxy.MV_="DownloadStateChange";






if(up==fj)ConvivaStreamerProxy.zJ2="DisplaySizeChange";





if(up==fj)ConvivaStreamerProxy.vHz="ErrorChange";





if(up==fj)ConvivaStreamerProxy.x1x="Log";




if(up==fj)ConvivaStreamerProxy.HwE="STOPPED";


if(up==fj)ConvivaStreamerProxy.tAQ="PLAYING";



if(up==fj)ConvivaStreamerProxy.vkg="BUFFERING";


if(up==fj)ConvivaStreamerProxy.yzw="PAUSED";




if(up==fj)ConvivaStreamerProxy.fFX="NOT_MONITORED";


if(up==fj)ConvivaStreamerProxy.FVe="ERROR";


if(up==fj)ConvivaStreamerProxy.dHj="UNKNOWN";





if(up==fj)ConvivaStreamerProxy.pmJ=1;





if(up==fj)ConvivaStreamerProxy.jrQ=0;







if(up==fj)ConvivaStreamerProxy.biP="duration";

if(up==fj)ConvivaStreamerProxy.zoT="framerate";











if(up==fj)ConvivaStreamerProxy.Khw=1;
if(up==fj)ConvivaStreamerProxy.BvQ=-1;
if(up==fj)ConvivaStreamerProxy.ObP=0;





if(up==fj)ConvivaStreamerProxy.JV=1;
if(up==fj)ConvivaStreamerProxy.rgw=2;
if(up==fj)ConvivaStreamerProxy.IrL=4;


if(up==fj)ConvivaStreamerProxy._Ci=8;
if(up==fj)ConvivaStreamerProxy.b7N=16;


if(up==fj)ConvivaStreamerProxy.asA=32;
if(up==fj)ConvivaStreamerProxy.RXQ=64;
if(up==fj)ConvivaStreamerProxy.pbC=128;

function ju(){





}




OZ(up,"wy",NQ);OZ(up,"Cleanup",NQ);
function NQ(){
if(up.Mqe!=null){
up.Mqe.m3();
}
}






OZ(up,"Ukq",BmZ);OZ(up,"GetCapabilities",BmZ);
function BmZ(){
return 0;
}










OZ(up,"dD",CC);OZ(up,"GetPlayheadTimeMs",CC);
function CC(){
return-1;
}








OZ(up,"k7K",zFu);OZ(up,"GetIsPHTAccurate",zFu);
function zFu(){
return true;
}










OZ(up,"ML",zp);OZ(up,"GetBufferLengthMs",zp);
function zp(){
return-1;
}










OZ(up,"_yq",o3L);OZ(up,"GetVideoBufferLengthMs",o3L);
function o3L(){
return-1;
}










OZ(up,"DrL",UEk);OZ(up,"GetAudioBufferLengthMs",UEk);
function UEk(){
return-1;
}

















OZ(up,"nHx",hNf);OZ(up,"GetStartingBufferLengthMs",hNf);
function hNf(){
return-1;
}








OZ(up,"YU7",LGW);OZ(up,"SetStartingBufferLengthMs",LGW);
function LGW(OM){

}











OZ(up,"Wrt",JVG);OZ(up,"GetRenderedFrameRate",JVG);
function JVG(){
return-1.0;
}








OZ(up,"glF",dwI);OZ(up,"GetSourceFrameRate",dwI);
function dwI(){
return-1.0;
}








OZ(up,"a1",jn);OZ(up,"GetDroppedFrames",jn);
function jn(){
return-1;
}






OZ(up,"JIr",RWb);OZ(up,"GetCpuPercent",RWb);
function RWb(){
return-1.0;
}






OZ(up,"ilA",b46);OZ(up,"GetMemoryAvailable",b46);
function b46(){
return-1.0;
}










OZ(up,"TzN",Cav);OZ(up,"GetCapacityKbps",Cav);
function Cav(w6){
return-1;
}











OZ(up,"bvd",kLC);OZ(up,"GetServerAddress",kLC);
function kLC(){
return null;
}











OZ(up,"qaO",H0W);OZ(up,"GetIsLive",H0W);
function H0W(){
return ConvivaStreamerProxy.ObP;
}











OZ(up,"SNS",CDf);OZ(up,"GetStreamerVersion",CDf);
function CDf(){
return-1;
}















OZ(up,"hv7",taf);OZ(up,"FetchCandidateStreams",taf);
function taf(w6){

}

















OZ(up,"WvT",MUD);OZ(up,"Play",MUD);
function MUD(SVV){
}










OZ(up,"o1i",AnQ);OZ(up,"GetApiVersion",AnQ);
function AnQ(){
return ConvivaStreamerProxy.aM_;
}
if(up==fj)ConvivaStreamerProxy.aM_=1;




























OZ(up,"FGc",UP);OZ(up,"SetMonitoringNotifier",UP);
function UP(VW8){

if(VW8==null)return;

var MlC=up.Mqe;

var nWi=new Yw();
nWi.Yb(VW8);
up.Mqe=nWi;


if(up.Mqe!=null){



if(up.BW7){
VW8(ConvivaStreamerProxy.U6H,null);
}

up.nDN(StreamInfo.qme,ConvivaStreamerProxy.pmJ);
up.nDN(StreamInfo.ct3,ConvivaStreamerProxy.pmJ);



var xCd=up.UQZ;
up.UQZ=new StreamInfo(-1,ConvivaContentInfo.jNU,ConvivaContentInfo._6t,-1,-1,-1);
up.cQi(xCd);


var Uy=up.OjE;
up.OjE=ConvivaStreamerProxy.dHj;
up.eco(Uy);


var Y2S=up.fDr;
up.fDr=null;
up.Pmd(Y2S);


var bC=up.FvG.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var lhg=bC[Jo];

up.rpy(lhg);
}

var OrJ=up.Hfe;
up.Hfe=null;
up.UCH(OrJ);

var kiQ=(up.fx3);
up.fx3=null;
up.oed(kiQ);

var OOD=up.BaK;
var Rkn=up.BaK;
up.BaK=-1;
up.H7g=-1;
up.fJw(OOD,Rkn);
}

MlC.Yb(VW8);
up.Mqe=MlC;
}











OZ(up,"FkN",puP);OZ(up,"GetLoadingStatus",puP);
function puP(){
return up.fx3;
}










OZ(up,"MnZ",luX);OZ(up,"GetPlayingState",luX);
function luX(){
return up.OjE;
}










OZ(up,"Wid",dMh);OZ(up,"GetBitrateKbps",dMh);
function dMh(){
return up.UQZ.M9;
}







OZ(up,"Iom",w71);OZ(up,"GetCdnName",w71);
function w71(){
return up.UQZ._fK;
}










OZ(up,"RhM",D_q);OZ(up,"GetResource",D_q);
function D_q(){
return up.UQZ.w6;
}













OZ(up,"M8p",Afd);OZ(up,"GetStream",Afd);
function Afd(){
return up.UQZ;
}






OZ(up,"t_t",oJI);OZ(up,"GetStreams",oJI);
function oJI(){
return null;
}









OZ(up,"dcl",TsV);OZ(up,"GetLastError",TsV);
function TsV(){
return up.sOE;
}







OZ(up,"tUW",ACM);OZ(up,"GetLastMetadata",ACM);
function ACM(){
return up.fDr;
}









OZ(up,"br4",STP);OZ(up,"GetDisplayWidth",STP);
function STP(){
return up.BaK;
}





OZ(up,"cMt",hhq);OZ(up,"GetDisplayHeight",hhq);
function hhq(){
return up.H7g;
}



















OZ(up,"HS_",IJz);OZ(up,"GetStreamerType",IJz);
function IJz(){
return null;
}











OZ(up,"nOK",kNr);OZ(up,"GetLoadedBytes",kNr);
function kNr(){
return-1;
}


OZ(up,"nDN",HmL);OZ(up,"SetDownloadStateChange",HmL);
function HmL(fm,eY){
var PoT=new Yw();
PoT.Yb(fm);
PoT.Yb(eY);
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.MV_,PoT);
}
}









OZ(up,"cQi",kXO);OZ(up,"SetStream",kXO);
function kXO(Wiw){

if(Wiw.M9<=-2)Wiw.M9=up.UQZ.M9;
if(Wiw._fK==null)Wiw._fK=up.UQZ._fK;
if(Wiw.w6==null)Wiw.w6=up.UQZ.w6;
if(!up.UQZ.j5q(Wiw)){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.xUm,Wiw);
}
}
up.UQZ=Wiw;
}












OZ(up,"rpy",qEn);OZ(up,"SetError",qEn);
function qEn(lNq){

up.sOE=lNq;

if(up.Mqe!=null&&up.Mqe.Bt>0){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.vHz,lNq);
}
}else{
up.FvG.Yb(lNq);
}
}

















OZ(up,"Pmd",ZSP);OZ(up,"SetMetadata",ZSP);
function ZSP(UFr){

up.fDr=UFr;

if(UFr!=null){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.GMW,UFr);
}
}

}








OZ(up,"WWf",u6d);OZ(up,"Log",u6d);
function u6d(message){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.x1x,message);
}

}







OZ(up,"_fW",_bK);OZ(up,"LogError",_bK);
function _bK(message){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.x1x,"ERROR:"+message);
}
}

















OZ(up,"wFZ",Ss1);OZ(up,"GetTotalLoadedBytes",Ss1);
function Ss1(){
return null;
}










OZ(up,"oed",yFG);OZ(up,"SetLoadingStatus",yFG);
function yFG(Nch){
up.fx3=Nch;
if(Nch!=null){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.kTl,Nch);
}
}
}








OZ(up,"eco",apd);OZ(up,"SetPlayingState",apd);
function apd(Uy){

if(Uy!=up.OjE){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.yeD,Uy);
}
}
up.OjE=Uy;
}








OZ(up,"sgt",ECq);OZ(up,"SetBitrateKbps",ECq);
function ECq(TC8){
var Wiw=new StreamInfo(TC8,null,null,-1,-1,-1);
up.cQi(Wiw);
}








OZ(up,"txs",o3O);OZ(up,"SetCdnName",o3O);
function o3O(TRS){
var Wiw=new StreamInfo(-2,TRS,null,-1,-1,-1);
up.cQi(Wiw);
}









OZ(up,"xQX",Iwf);OZ(up,"SetResource",Iwf);
function Iwf(eoy){
var Wiw=new StreamInfo(-2,null,eoy,-1,-1,-1);
up.cQi(Wiw);
}






OZ(up,"fJw",U28);OZ(up,"SetDisplaySize",U28);
function U28(_4W,dZo){

if(_4W!=-1&&dZo!=-1){

up.BaK=_4W;
up.H7g=dZo;

var Gm8=new Yw();
Gm8.Yb(_4W);
Gm8.Yb(dZo);
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.zJ2,Gm8);
}
}
}








OZ(up,"UCH",pBL);OZ(up,"SetAvailableStreams",pBL);
function pBL(Xdp){
up.Hfe=Xdp;
if(Xdp!=null){
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.pOB,Xdp);
}
}
}





OZ(up,"ydC",uhs);OZ(up,"SetProxyInitialized",uhs);
function uhs(){
if(!up.BW7){
up.BW7=true;
var bC=up.Mqe.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var VW8=bC[Jo];

up.j9V(VW8,ConvivaStreamerProxy.U6H,null);
}
}
}

LK(up,"j9V",IgC);
function IgC(VW8,TQ,SVh){
try{
VW8(TQ,SVh);
}catch(fe){
VW8(ConvivaStreamerProxy.x1x,"ConvivaStreamerProxy : uncaught exception "+fe);
}
}

dN(up,ConvivaStreamerProxy,"API_VERSION",ConvivaStreamerProxy.aM_);
dN(up,ConvivaStreamerProxy,"BOOLEAN_FALSE",ConvivaStreamerProxy.BvQ);
dN(up,ConvivaStreamerProxy,"BOOLEAN_TRUE",ConvivaStreamerProxy.Khw);
dN(up,ConvivaStreamerProxy,"BOOLEAN_UNAVAILABLE",ConvivaStreamerProxy.ObP);
dN(up,ConvivaStreamerProxy,"BUFFERING",ConvivaStreamerProxy.vkg);
dN(up,ConvivaStreamerProxy,"CAPABILITY_BITRATE_METRICS",ConvivaStreamerProxy.IrL);
dN(up,ConvivaStreamerProxy,"CAPABILITY_BITRATE_SWITCHING",ConvivaStreamerProxy._Ci);
dN(up,ConvivaStreamerProxy,"CAPABILITY_CDN_SWITCHING",ConvivaStreamerProxy.b7N);
dN(up,ConvivaStreamerProxy,"CAPABILITY_QUALITY_METRICS",ConvivaStreamerProxy.rgw);
dN(up,ConvivaStreamerProxy,"CAPABILITY_SOURCE_CHUNKED",ConvivaStreamerProxy.RXQ);
dN(up,ConvivaStreamerProxy,"CAPABILITY_SOURCE_HTTP",ConvivaStreamerProxy.asA);
dN(up,ConvivaStreamerProxy,"CAPABILITY_SOURCE_STREAMING",ConvivaStreamerProxy.pbC);
dN(up,ConvivaStreamerProxy,"CAPABILITY_VIDEO",ConvivaStreamerProxy.JV);
dN(up,ConvivaStreamerProxy,"DOWNLOADSTATE_ACTIVE",ConvivaStreamerProxy.pmJ);
dN(up,ConvivaStreamerProxy,"DOWNLOADSTATE_INACTIVE",ConvivaStreamerProxy.jrQ);
dN(up,ConvivaStreamerProxy,"ERROR",ConvivaStreamerProxy.FVe);
dN(up,ConvivaStreamerProxy,"METADATA_DURATION",ConvivaStreamerProxy.biP);
dN(up,ConvivaStreamerProxy,"METADATA_ENCODED_FRAMERATE",ConvivaStreamerProxy.zoT);
dN(up,ConvivaStreamerProxy,"NOT_MONITORED",ConvivaStreamerProxy.fFX);
dN(up,ConvivaStreamerProxy,"PAUSED",ConvivaStreamerProxy.yzw);
dN(up,ConvivaStreamerProxy,"PLAYING",ConvivaStreamerProxy.tAQ);
dN(up,ConvivaStreamerProxy,"REASON_AVAILABLESTREAMINFOCHANGE",ConvivaStreamerProxy.pOB);
dN(up,ConvivaStreamerProxy,"REASON_DISPLAYSIZECHANGE",ConvivaStreamerProxy.zJ2);
dN(up,ConvivaStreamerProxy,"REASON_DOWNLOADSTATECHANGE",ConvivaStreamerProxy.MV_);
dN(up,ConvivaStreamerProxy,"REASON_ERRORCHANGE",ConvivaStreamerProxy.vHz);
dN(up,ConvivaStreamerProxy,"REASON_LOADINGSTATUSCHANGE",ConvivaStreamerProxy.kTl);
dN(up,ConvivaStreamerProxy,"REASON_LOG",ConvivaStreamerProxy.x1x);
dN(up,ConvivaStreamerProxy,"REASON_METADATACHANGE",ConvivaStreamerProxy.GMW);
dN(up,ConvivaStreamerProxy,"REASON_PLAYINGSTATECHANGE",ConvivaStreamerProxy.yeD);
dN(up,ConvivaStreamerProxy,"REASON_PROXYINITIALIZED",ConvivaStreamerProxy.U6H);
dN(up,ConvivaStreamerProxy,"REASON_STREAMINFOCHANGE",ConvivaStreamerProxy.xUm);
dN(up,ConvivaStreamerProxy,"STOPPED",ConvivaStreamerProxy.HwE);
dN(up,ConvivaStreamerProxy,"UNKNOWN",ConvivaStreamerProxy.dHj);
if(up!=fj)ju.apply(up,arguments);
}
Bg(ConvivaStreamerProxy,"ConvivaStreamerProxy");







function IcH(){
var up=this;

if(up==fj)IcH.X1E=null;

if(up==fj)IcH.DDV=null;




if(up==fj)IcH.me9="UNINITIALIZED";
if(up==fj)IcH.Lnh=0;

if(up==fj)IcH.tAQ="PLAYING";
if(up==fj)IcH.CS=3;
if(up==fj)IcH.HwE="STOPPED";
if(up==fj)IcH.cz=1;
if(up==fj)IcH.yzw="PAUSED";
if(up==fj)IcH.Qh=12;
if(up==fj)IcH.vkg="BUFFERING";
if(up==fj)IcH.DV=6;
if(up==fj)IcH.fFX="NOT_MONITORED";
if(up==fj)IcH.nw=98;
if(up==fj)IcH.dHj="UNKNOWN";
if(up==fj)IcH.ft=100;

dN(up,IcH,"Ns",D3);
function D3(){
IcH.X1E=new EW();
IcH.DDV=new EW();
IcH.X1E.a9(IcH.me9,IcH.Lnh);IcH.DDV.a9(IcH.Lnh,IcH.me9);
IcH.X1E.a9(IcH.tAQ,IcH.CS);IcH.DDV.a9(IcH.CS,IcH.tAQ);
IcH.X1E.a9(IcH.HwE,IcH.cz);IcH.DDV.a9(IcH.cz,IcH.HwE);
IcH.X1E.a9(IcH.yzw,IcH.Qh);IcH.DDV.a9(IcH.Qh,IcH.yzw);
IcH.X1E.a9(IcH.vkg,IcH.DV);IcH.DDV.a9(IcH.DV,IcH.vkg);
IcH.X1E.a9(IcH.fFX,IcH.nw);IcH.DDV.a9(IcH.nw,IcH.fFX);
IcH.X1E.a9(IcH.dHj,IcH.ft);IcH.DDV.a9(IcH.ft,IcH.dHj);
}

dN(up,IcH,"NXs",YVG);
function YVG(iQc){
if(IcH.X1E==null){
IcH.Ns();
}
if(IcH.X1E.Wt(iQc)){
return IcH.X1E.tc(iQc);
}else{
return IcH.ft;
}
}

dN(up,IcH,"i2y",Rws);
function Rws(ahR){
if(IcH.DDV==null){
IcH.Ns();
}
if(IcH.DDV.Wt(ahR)){
return IcH.DDV.tc(ahR);
}else{
return IcH.dHj;
}
}

dN(up,IcH,"ox",gv);
function gv(){
IcH.X1E=null;
}














}
Bg(IcH,"IcH");







function D4u(){
var up=this;
function ju(AR,eMe,f5,PE){
up.gtM=AR;
up.m5j=eMe;
up.IyF=f5;
up.n3c=PE;
}



if(up!=fj)up.gtM=undefined;
OZ(up,"O2s",e0B);
function e0B(){return up.gtM;}




if(up!=fj)up.m5j=undefined;
OZ(up,"Bwl",M2J);
function M2J(){return up.m5j;}




if(up!=fj)up.IyF=undefined;







OZ(up,"rlg",MSA);
function MSA(){
return oL.R5(up.IyF);
}

if(up!=fj)up.n3c=undefined;
OZ(up,"pEj",tF4);
function tF4(){return up.n3c;}
if(up!=fj)ju.apply(up,arguments);
}
Bg(D4u,"D4u");


















function StreamInfo(){
var up=this;







if(up==fj)StreamInfo.dHj=-1;


if(up==fj)StreamInfo.ct3=0;


if(up==fj)StreamInfo.qme=1;


if(up==fj)StreamInfo.ZIc=2;


if(up==fj)StreamInfo.yhl=3;





if(up!=fj)up.fm=StreamInfo.dHj;






if(up!=fj)up.mR7=-1;





if(up!=fj)up.vuw=-1;





if(up!=fj)up.M9=-1;



if(up!=fj)up.w6=null;



if(up!=fj)up._fK=null;








function ju(Jq,LUA,go,fm,Grb,GFW){
up.M9=Jq;
up._fK=LUA;
up.w6=go;
up.fm=fm;
up.mR7=GFW;
up.vuw=Grb;
}


OZ(up,"Wid",dMh);OZ(up,"GetBitrateKbps",dMh);
function dMh(){
return up.M9;
}


OZ(up,"Iom",w71);OZ(up,"GetCdnName",w71);
function w71(){
return up._fK;
}


OZ(up,"RhM",D_q);OZ(up,"GetResource",D_q);
function D_q(){
return up.w6;
}

OZ(up,"j5q",YQT);OZ(up,"equals",YQT);
function YQT(jy){
if(jy==null)return false;

return up._fK==jy._fK&&up.w6==jy.w6&&up.M9==jy.M9&&up.fm==jy.fm
&&up.mR7==jy.mR7&&up.vuw==jy.vuw;
}






dN(up,StreamInfo,"QKZ",UuP);dN(up,StreamInfo,"ConstructClone",UuP);
function UuP(lGX){
if(lGX==null)return null;

return lGX;
}

OZ(up,"vo",Ua);OZ(up,"ToStr",Ua);
function Ua(){
var Fe2=null;

switch(up.fm){
case StreamInfo.dHj:
Fe2="UNKNOWN";
break;
case StreamInfo.qme:
Fe2="VIDEO";
break;
case StreamInfo.ct3:
Fe2="AUDIO";
break;
case StreamInfo.ZIc:
Fe2="TEXT";
break;
case StreamInfo.yhl:
Fe2="RESOURCE";
break;
default:
throw new Error("Unknown stream type "+up.fm);
}

return "type="+Fe2+
", bitrateKbps="+up.M9+
", resource="+(up.w6!=null?up.w6:"null")+
", cdnName="+(up._fK!=null?up._fK:"null")+
", sourceHeightPixels="+up.mR7+
", sourceWidthPixels="+up.vuw;
}
dN(up,StreamInfo,"AUDIO",StreamInfo.ct3);
dN(up,StreamInfo,"RESOURCE",StreamInfo.yhl);
dN(up,StreamInfo,"TEXT",StreamInfo.ZIc);
dN(up,StreamInfo,"UNKNOWN",StreamInfo.dHj);
dN(up,StreamInfo,"VIDEO",StreamInfo.qme);
if(up!=fj)ju.apply(up,arguments);
}
Bg(StreamInfo,"StreamInfo");
























function StreamSwitch(){
var up=this;

if(up==fj)StreamSwitch.YF9=0;






if(up==fj)StreamSwitch.nsi="PENDING";



if(up==fj)StreamSwitch.QuW="IN_PROGRESS";




if(up==fj)StreamSwitch.TgA="SUCCEEDED";



if(up==fj)StreamSwitch.D4J="FAILED";




if(up==fj)StreamSwitch.UhJ="INTERRUPTED";








dN(up,StreamSwitch,"LII",p_4);dN(up,StreamSwitch,"MakeSwitch",p_4);
function p_4(bWS,wo1,f1){
return new StreamSwitch(StreamSwitch.BEz(false),bWS,wo1,-1,null,f1);
}














dN(up,StreamSwitch,"QpG",AhB);dN(up,StreamSwitch,"MakeSwitchToStream",AhB);
function AhB(wo1,f1){
return new StreamSwitch(StreamSwitch.BEz(false),null,wo1,-1,null,f1);
}




OZ(up,"wy",NQ);OZ(up,"Cleanup",NQ);
function NQ(){
}









if(up!=fj)up._cW=undefined;
ED(up,"kQ",d4);ED(up,"id",d4);
function d4(){return up._cW;}
Wf(up,"kQ",J_F);Wf(up,"id",J_F);
function J_F(nQ){up._cW=nQ;}









if(up!=fj)up.ILK=undefined;
ED(up,"n8",uAU);ED(up,"timeoutMs",uAU);
function uAU(){return up.ILK;}
Wf(up,"n8",g7B);Wf(up,"timeoutMs",g7B);
function g7B(nQ){up.ILK=nQ;}








if(up!=fj)up.w25=undefined;
ED(up,"Pkb",yrY);ED(up,"sourceStream",yrY);
function yrY(){return up.w25;}
Wf(up,"Pkb",z_O);Wf(up,"sourceStream",z_O);
function z_O(nQ){up.w25=nQ;}















if(up!=fj)up.cH3=undefined;
ED(up,"lfw",psL);ED(up,"targetStream",psL);
function psL(){return up.cH3;}
Wf(up,"lfw",MDi);Wf(up,"targetStream",MDi);
function MDi(nQ){up.cH3=nQ;}













if(up!=fj)up.IO1=undefined;
ED(up,"TMB",K4M);ED(up,"mode",K4M);
function K4M(){return up.IO1;}
Wf(up,"TMB",_jy);Wf(up,"mode",_jy);
function _jy(nQ){up.IO1=nQ;}









if(up!=fj)up.Ie6=undefined;
ED(up,"f1",GQk);ED(up,"status",GQk);
function GQk(){return up.Ie6;}
Wf(up,"f1",SMG);Wf(up,"status",SMG);
function SMG(nQ){up.Ie6=nQ;}







function ju(kQ,Pkb,lfw,n8,TMB,f1){
up.kQ=kQ;
up.Pkb=Pkb;
up.lfw=lfw;
up.n8=n8;
up.TMB=TMB;
up.f1=f1;
}










OZ(up,"OeK",PdJ);OZ(up,"CheckValidity",PdJ);
function PdJ(){
if(up.kQ==null){
return "StreamSwitch.id is null (and must be non-null)";
}

if(up.kQ!=null&&!((typeof up.kQ==="string"))){
return "StreamSwitch.id is not a string";
}else if(up.n8!=null&&!((typeof up.n8==="number"))){
return "StreamSwitch.timeoutMs is not an int";
}else if(up.TMB!=null&&!((typeof up.TMB==="string"))){
return "StreamSwitch.mode is not a string";
}else if(up.f1!=null&&!((typeof up.f1==="string"))){
return "StreamSwitch.status is not a string";
}else if(up.Pkb!=null&&!(up.Pkb instanceof CandidateStream)){
return "StreamSwitch.sourceStream is not a CandidateStream";
}else if(up.lfw!=null&&!(up.lfw instanceof CandidateStream)){
return "StreamSwitch.targetStream is not a CandidateStream";
}
var Oah=(up.Pkb!=null?up.Pkb.OeK():null);
if(Oah!=null){
return Oah;
}
var sUL=(up.lfw!=null?up.lfw.OeK():null);
if(sUL!=null){
return sUL;
}
return null;
}





dN(up,StreamSwitch,"QKZ",UuP);dN(up,StreamSwitch,"ConstructClone",UuP);
function UuP(lGX){

return lGX;
}



dN(up,StreamSwitch,"rL",ry);dN(up,StreamSwitch,"StaticInit",ry);
function ry(){
StreamSwitch.YF9=0;
}


dN(up,StreamSwitch,"bx",vl);dN(up,StreamSwitch,"StaticCleanup",vl);
function vl(){
StreamSwitch.YF9=0;
}

dN(up,StreamSwitch,"BEz",PYD);dN(up,StreamSwitch,"GetNextId",PYD);
function PYD(u2I){
var kQ=StreamSwitch.YF9;
StreamSwitch.YF9+=1;
if(u2I){
return "c3."+oL.fg(kQ);
}else{
return oL.fg(kQ);
}
}
dN(up,StreamSwitch,"FAILED",StreamSwitch.D4J);
dN(up,StreamSwitch,"INTERRUPTED",StreamSwitch.UhJ);
dN(up,StreamSwitch,"IN_PROGRESS",StreamSwitch.QuW);
dN(up,StreamSwitch,"PENDING",StreamSwitch.nsi);
dN(up,StreamSwitch,"SUCCEEDED",StreamSwitch.TgA);
if(up!=fj)ju.apply(up,arguments);
}
Bg(StreamSwitch,"StreamSwitch");
















function StreamerError(){
var up=this;




if(up==fj)StreamerError.UQc=0;

if(up==fj)StreamerError.Abc=1;

if(up==fj)StreamerError.e9E=2;

if(up==fj)StreamerError.kOK=3;






if(up==fj)StreamerError.y4_=0;



if(up==fj)StreamerError.VuW=1;


if(up!=fj)up.k3=undefined;


if(up!=fj)up.XfB=undefined;


if(up!=fj)up.slO=undefined;


if(up!=fj)up.dHu=undefined;


if(up!=fj)up.cmo=undefined;







dN(up,StreamerError,"kHO",Imp);dN(up,StreamerError,"makeUnscopedError",Imp);
function Imp(k3,XfB){
return new StreamerError(k3,null,-1,XfB,StreamerError.UQc);
}








dN(up,StreamerError,"YKZ",ZRP);dN(up,StreamerError,"makeStreamError",ZRP);
function ZRP(KU,XfB,slO){
return new StreamerError(KU,slO,-1,XfB,StreamerError.e9E);
}








dN(up,StreamerError,"VR0",Q6_);dN(up,StreamerError,"makeResourceError",Q6_);
function Q6_(KU,XfB,slO){
return new StreamerError(KU,slO,-1,XfB,StreamerError.kOK);
}










dN(up,StreamerError,"qM6",ftG);dN(up,StreamerError,"makeStreamSegmentError",ftG);
function ftG(KU,XfB,slO,Ny){
return new StreamerError(KU,slO,Ny,XfB,StreamerError.Abc);
}

function ju(F4Y,UQZ,BwZ,MaJ,gBT){
up.k3=F4Y;

up.slO=UQZ;
up.dHu=BwZ;
up.XfB=MaJ;
up.cmo=gBT;
}






dN(up,StreamerError,"QKZ",UuP);dN(up,StreamerError,"ConstructClone",UuP);
function UuP(lGX){
if(lGX==null)return null;

return lGX;
}

OZ(up,"vo",Ua);OZ(up,"ToStr",Ua);
function Ua(){
return "errorCode="+(up.k3!=null?up.k3:"null")+
", index="+up.dHu+
", severity="+up.XfB+
", scope="+up.cmo+
", stream=("+up.slO.vo()+")";
}








if(up!=fj)ju.apply(up,arguments);
}
Bg(StreamerError,"StreamerError");





function jh(){
var up=this;

if(up!=fj)up.E0=undefined;
function ju(bk){
if(bk==undefined)bk=0;
up.E0=new Array(bk);
}

dN(up,jh,"oIy",yzx);
function yzx(){
var S5=new jh();
var cn=[];


for(var co=0;co<arguments.length;co++){
cn.push(arguments[co]);
}
S5.E0=cn;
return S5;
}

dN(up,jh,"Y_",gE);
function gE(l4){
if(l4==null)return null;
var S5=new jh();
S5.E0=l4;
return S5;
}

OZ(up,"UX",h0);
function h0(){
return up.E0;
}


ED(up,"ug",OH);
function OH(){
return up.E0.length;
}


OZ(up,"tc",JJ);
function JJ(Ny){
if(Ny>=up.E0.length){
throw new Error("Index out of bounds: "+Ny+" (length "+up.E0.length+")");
}else if(Ny<0){
throw new Error("Index out of bounds: "+Ny);
}
return up.E0[Ny];
}

OZ(up,"a9",Ut);
function Ut(Ny,Sk){
if(Ny>=up.E0.length){
throw new Error("Index out of bounds: "+Ny+" (length "+up.E0.length+")");
}else if(Ny<0){
throw new Error("Index out of bounds: "+Ny);
}
up.E0[Ny]=Sk;
}

ED(up,"YC",jO);
function jO(){
return up.E0;
}

if(up!=fj)ju.apply(this,arguments);

}
Bg(jh,"jh");







function qu(){
var up=this;
if(up==fj){



qu.ua6=parseInt(Math.floor(Math.random()*10000),16);
qu.jK=null;

qu.JCl="convivaLoadingElement_"+qu.ua6;

qu.D_=0;
qu.gK={};
}


dN(up,qu,"bx",vl);
function vl(){
if(qu.jK){
qu.jK.innerHTML="";
}
BW(qu.gK,function(cn){cn.wy();});
qu.gK={};
}

OZ(up,"wy",NQ);
function NQ(){
up.qA=null;
delete qu.gK[up.D_];
if(up.Ss){
Lt.Te(up.Ss);
up.Ss=null;
}
}




function _d(H1,qA,n8){
up.H1=H1;
up.qA=qA;

if(n8!=undefined&&n8>0){
up.Ss=Lt.b_(Yd,n8);
}else{
up.Ss=null;
}
up.D_=qu.D_++;
qu.gK[up.D_]=up;


qu.jK=document.getElementById(qu.JCl);
if(!qu.jK){
qu.jK=qu.bA();
}
up.DY=false;

{
up.zm=document.createElement("div");
qu.jK.appendChild(up.zm);

var lA=document.createElement("script");
lA.src=up.H1;
lA.type="text/javascript";
lA.onload=(function(){
O9.Yv(function(){GM(up.D_);},
"ClassLoader.onload");
});
lA.onerror=(function(rU){
up.Error=new Error("Error loading module");
if(up.qA)up.qA(up.Error,up);
up.wy();
return false;
});
up.zm.appendChild(lA);













}

};


function GM(D_){
var g7=qu.gK[D_];
if(g7==null||g7==undefined)return;
g7.DY=true;
if(g7.qA)g7.qA(null,g7);
g7.wy();
}

function Yd(){

var fh=qu.gK[up.D_];
if(!fh){
return;
}
up.Error=new Error("ClassLoader timeout");
if(up.qA)up.qA(up.Error,up);
up.wy();
}



OZ(up,"Eg",J8);
function J8(l5){
return sHq(l5);
}



dN(up,qu,"bA",Uu);
function Uu(){







var ev=document.createElement("div");
document.body.appendChild(ev);


ev.style.position='absolute';
ev.style.margin="0pt 0pt 0pt 0pt";
ev.style.left="0px";
ev.style.top="0px";
ev.style.visibility="hidden";
ev.style.width="0px";
ev.style.height="0px";

ev.className="convivaLoadElement";

ev.id=qu.JCl;

return ev;
}

if(up!=fj)_d.apply(up,arguments);
}
Bg(qu,"qu");


















function Gnw(){
var up=this;



dN(up,Gnw,"jMw",HJf);
function HJf(LQ){
if(LQ==null){
return "null";
}
var aq=oL.PX(LQ);
var cN="{";
var bC=aq.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

cN+=Tj+":\""+aq.tc(Tj)+"\" ";
}
cN+="}";
return cN;
}




dN(up,Gnw,"hJD",zGT);
function zGT(cn){
if(cn==null){
return "null";
}
var cN="[";
for(var Ny=0;Ny<cn.Bt;Ny++){
cN+=cn.tc(Ny);
if(Ny<cn.Bt-1){
cN+=", ";
}
}
cN+="]";
return cN;
}
}
Bg(Gnw,"Gnw");








function UF(){
var up=this;


if(up!=fj)up._W=null;



dN(up,UF,"Y_",gE);
function gE(nI){
var S5=new UF();
S5._W=nI;
return S5;
}

OZ(up,"UX",h0);
function h0(){
return up._W;
}


dN(up,UF,"BU",S2);
function S2(f8){
if(f8==null)return null;
var E0=null;
if(f8.hasOwnProperty("UX"))
E0=f8.UX();
else
E0=f8;
var _W="";
for(var co=0;co<E0.length;co++){
_W+=String.fromCharCode(E0[co]);
}
var S5=new UF();
S5._W=_W;
return S5;
}



dN(up,UF,"UA",Zd);
function Zd(_W){
return S2(va(_W));
}



dN(up,UF,"qi",eG);
function eG(_W){
var S5=new UF();
var rU="";
for(var co=0;co<_W.length;co++){
rU+=" "+_W.charCodeAt(co);
}
S5._W=_W;
return S5;
}


OZ(up,"v_",ES);
function ES(){
var S5=new Array();
var nI=up._W;
for(var co=0;co<nI.length;co++){
S5.push(nI.charCodeAt(co)&0xFF);
}
return jh.Y_(S5);
}


OZ(up,"vo",Ua);
function Ua(){
return up._W;
}




OZ(up,"fW",zq);
function zq(){
return oL.FP(up._W);
};


}
Bg(UF,"UF");






function nD(){
var up=this;
if(up==fj){


nD.nL=function(sq,_F,Tv){
if(sq.addEventListener){
sq.addEventListener(_F,Tv,false);
}else{
sq.attachEvent('on'+_F,Tv);
}
};

nD.Pi5=function(sq,_F,Tv){
if(sq.removeEventListener){
sq.removeEventListener(_F,Tv,false);
}else{
sq.detachEvent('on'+_F,Tv);
}
};


nD.nL(window,"message",B7);
nD.ZHR={};



nD.ua6=parseInt(Math.floor(Math.random()*10000),16);
nD.jK=null;

nD.JCl="convivaCommunicationElement_"+nD.ua6;

nD.Eo=0;
nD.SY={};


nD.li8=null;

}

if(up!=fj)up.m1A=null;



if(up!=fj)up.ja_=true;


dN(up,nD,"bx",vl);
function vl(){
if(nD.jK){
nD.jK.innerHTML="";
nD.ZHR={};
}
BW(nD.SY,function(cn){cn.wy();});
nD.SY={};
}

OZ(up,"wy",NQ);
function NQ(){
up.qA=null;
delete nD.SY[up.Eo];
if(up.Ss){
Lt.Te(up.Ss);
up.Ss=null;
}
if(up.m1A!=null){
up.m1A.wy();
up.m1A=null;
}
}

ED(up,"mV",bH);
function bH(){
if(up.jV==null)return null;
if(up.o_==null){

try{
up.o_=NM(up.jV);
}catch(fe){
up.o_=null;
}
}
return up.o_;
};





function _d(H1,qA,jm,ym){
up.oJW=Lt.VB();
up.H1=H1;
up.qA=qA;
if(!ym){
ym=new EW();
}else if(!ym.hasOwnProperty("ToObject")){

ym=oL.PX(ym);
}
up.ym=ym;
up.tM="GET";
up.ar="text/plain";

up.jm=jm;

up.jJd=null;
up.X5=null;
up.T8T=0;

up.Mr3=null;


if(nD.li8!=null){

up.m1A=nD.li8(up);
if(up.m1A!=null){
return;
}
}

up.Mi_(H1,qA,jm,ym);
}

OZ(up,"Mi_",Wv3);
function Wv3(H1,qA,jm,ym){

var xF=H1.match(/^(https?:\/\/[^\/]*)(\/.*)$/);
if(!xF){
O9.FW("DataLoader: cannot parse url: "+H1);
return;
}
up.kK=xF[1];
if(up.kK.indexOf("localhost")<0){
var ci=5;
}
var ID=xF[2];

up.tM="GET";
var jV="";
up.ar="text/plain";
if(jm){
jV=jm.vo();
up.ar="application/octet-stream; charset=x-user-defined";
up.tM="POST";
}

if(ym.Wt('contentType')){
up.ar=ym.tc('contentType');
}
up.setTimeout(ym);
up.Eo=nD.ua6+"_"+(nD.Eo++);
nD.SY[up.Eo]=up;

if(/octet-stream/.test(up.ar)&&!Vz.hp&&jV.substr(0,2)=="pb"){
jV=Vz.Em(jV);
}
if(/octet-stream/.test(up.ar)&&_vt){
jV=xHs(jV);
}

up.rU="id="+up.Eo+
",method="+up.tM+
",url="+ID+
",contentType="+up.ar+
","+jV;


DX();
}

OZ(up,"setTimeout",WQD);
function WQD(ym){
if(ym.Wt('timeoutMs')){
up.Ss=Lt.b_(Yd,parseInt(ym.tc('timeoutMs')));
}else{
up.Ss=null;
}
}

function Yd(){

var fh=nD.SY[up.Eo];
if(!fh){
return;
}
up.jJd=new Error("DataLoader timeout");
fh.T8T=Lt.VB()-fh.oJW;
if(up.qA)up.qA(up.jJd,up);
up.wy();
}



function wV8(){

nD.jK=document.getElementById(nD.JCl);
if(!nD.jK){
nD.jK=nD.bA();
nD.ZHR={};
}
};


function DX(){
var Gy=up.kK;


var Go1=nD.ZHR[Gy];
var rK=Go1?document.getElementById(Go1):null;
if(rK&&rK.eB){


Be(rK);
}else if(rK&&!rK.eB){


setTimeout(function(){DX();},500);
}else{


wV8();
rK=document.createElement("iframe");
rK.height=30;
rK.src=Gy+"/ConvivaCommunicationProxy.html";
rK.eB=false;
rK.onload=function(){

rK.eB=true;
Be(rK);
};
rK.id=nD.F3k(Gy);
nD.jK.appendChild(rK);

nD.ZHR[Gy]=rK.id;

}

};



dN(up,nD,"F3k",nc5);
function nc5(Gy){
return "_convivaRemoteFrame_"+Gy.replace(/\//g,"").replace(/\:/g,"")+"_"+nD.ua6;
};


function Be(NJ){
if(NJ&&NJ.contentWindow){
NJ.contentWindow.postMessage(up.rU,up.ja_?"*":up.kK);
}else{
ct.qF("DataLoader","could not send message through communication frame, expect DataLoader timeout");
}
};

var _vt=(typeof(window.ActiveXObject)!='undefined');
var X5I=new RegExp(String.fromCharCode(1)+".","g");
var b7K=String.fromCharCode(1)+String.fromCharCode(1);
var Cn5=String.fromCharCode(1)+String.fromCharCode(2);
function PjU(rU){


rU=rU.replace(X5I,
function(match){return(match==b7K?String.fromCharCode(0)
:String.fromCharCode(1));});
return rU;
}
var TjV=new RegExp("["+String.fromCharCode(0)+String.fromCharCode(1)+"]","g");
function xHs(nI){
return nI.replace(TjV,
function(match){return(match==String.fromCharCode(0)?b7K:Cn5);});
}


function B7(fe){
var data=fe.data.toString();




var xF=data.match(/^id=([^,]+),([^,]+),/);
if(!xF){
return;
}
var e1r=xF[0].length;
var Mu9=null;
if(e1r==data.length){
Mu9="";
}else{
Mu9=data.substring(e1r);
}

var fh=nD.SY[xF[1]];
if(!fh){
if(0&&window.console){
window.console.log("  "+nD.ua6+" ignoring message");
}
return;
}

if(!fh.ja_&&fe.origin!=fh.kK){
return;
}
if(_vt&&/octet-stream/.test(fh.ar)){
Mu9=PjU(Mu9);
}
if(0&&window.console){
var kz=(new Date().getTime()/1000).toFixed(3);
var iM="["+kz+"] "+nD.ua6+": Got incoming: (len="+Mu9.length+"): ";
if(0){
iM+=Mu9;
}else{
for(var co=0;co<Mu9.length;co++){
iM+=Mu9.charCodeAt(co).toString(16)+",";
}
}
window.console.log(iM);
}

if(xF[2]=="ok"){
fh.jJd=null;;
}else{
fh.jJd=new Error(Mu9);
}
fh.X5=UF.qi(Mu9);
fh.T8T=Lt.VB()-fh.oJW;
if(fh.qA)fh.qA(fh.jJd,fh);
fh.wy();
};



dN(up,nD,"bA",Uu);
function Uu(){







var ev=document.createElement("div");
document.body.appendChild(ev);


ev.style.position='absolute';
ev.style.margin="0pt 0pt 0pt 0pt";
ev.style.left="0px";
ev.style.top="0px";
ev.style.visibility="hidden";
ev.style.width="0px";
ev.style.height="0px";




ev.className="convivaCommunicationElement";

ev.id=nD.JCl;

return ev;
}

if(up!=fj)_d.apply(up,arguments);
}
Bg(nD,"nD");





function EW(){
var up=this;

if(up!=fj)up.sq=undefined;
function ju(bk){
up.sq={};
}

dN(up,EW,"Y_",gE);
function gE(LQ){
if(LQ==null)return null;
if(LQ instanceof EW){
return LQ;
}
if(LQ.hasOwnProperty("A6")){
LQ=LQ.A6();
}
var S5=new EW();

Zi(LQ,function(G2){
S5.sq[G2]=LQ[G2];
});
return S5;
}

OZ(up,"A6",IP);
function IP(){
return up.sq;
}


dN(up,EW,"oIy",yzx);
function yzx(){
var S5=new EW();
for(var co=0;co+1<arguments.length;co+=2){
S5.sq[arguments[co]]=arguments[co+1];
}
return S5;
};


OZ(up,"Rr",HI);
function HI(sq){
Zi(up.sq,function(G2){
sq[G2]=up.sq[G2];
});
}

OZ(up,"tc",JJ);
function JJ(Tj){
return up.sq[Tj];
}

OZ(up,"a9",Ut);
function Ut(Tj,Sk){
up.sq[Tj]=Sk;
}


OZ(up,"m3",kG);
function kG(){
Zi(up.sq,function(Ti){
delete up.sq[Ti];
});
}


OZ(up,"Wt",jf);
function jf(Tj){
return(up.sq[Tj]!==undefined);
}

OZ(up,"OC",pi);
function pi(Tj){
return Wt(Tj);
}


ED(up,"VO",gu);
function gu(){
var S5=new Array();
Zi(up.sq,function(Ti){
S5.push(Ti);
});
return S5;
}


ED(up,"YC",jO);
function jO(){
var S5=new Array();
Zi(up.sq,function(Ti){
S5.push(up.sq[Ti]);
});
return S5;
}


ED(up,"GA",z8);
function z8(){
var S5=new Array();
Zi(up.sq,function(Ti){
S5.push(new sk(Ti,up.sq[Ti]));
});
return S5;
}


ED(up,"Bt",il);
function il(){
var S5=0;
Zi(up.sq,function(Ti){
S5++;
});
return S5;
}



OZ(up,"Yb",Ut);


OZ(up,"gS",ZQ);
function ZQ(Tj){
if(up.Wt(Tj)){
delete up.sq[Tj];
return true;
}else
return false;
}

if(up!=fj)ju.apply(this,arguments);

}
Bg(EW,"EW");









function M8(){
var up=this;
if(up!=fj)up.Lo=undefined;

function ju(){
up.Lo=new Yw();
}




OZ(up,"wy",NQ);
function NQ(){
up.Lo=new Yw();
}

OZ(up,"q_",t0);
function t0(z0){
up.Lo.Yb(z0);
}

OZ(up,"X8",ds);
function ds(z0){
up.Lo.gS(z0);
}

OZ(up,"_o",ce);
function ce(){
var bC=up.Lo.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var oW=bC[Jo];

oW();
}
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(M8,"M8");




function Inferrer(){
var up=this;

if(up==fj)Inferrer.MOVING_STATE="MOVING";
if(up==fj)Inferrer.NOT_MOVING_STATE="NOT_MOVING";

if(up==fj)Inferrer._Yn=4;
if(up==fj)Inferrer.EyE=4;

if(up==fj)Inferrer.Wkw=1;
if(up==fj)Inferrer.Mwe=0.25;

if(up==fj)Inferrer.XDG=0;

if(up!=fj)up.QO=undefined;
if(up!=fj)up.gR=0;
if(up!=fj)up.xK=0;

if(up!=fj)up.T8Y=Inferrer._Yn;
if(up!=fj)up.ZRS=Inferrer.EyE;

if(up!=fj)up.Lnr=Inferrer.Wkw;
if(up!=fj)up.qr7=Inferrer.Mwe;
if(up!=fj)up.W9b=Inferrer.XDG;

if(up!=fj)up.lAz=null;

function ju(ym){
up.lAz=oL.PX(ym);
up.k2K();
up.bV();
}

OZ(up,"Update",TXC);
function TXC(V_){
var kz=Lt.VB();
if(up.xK>0&&kz>up.xK){
up.QO.gX(0,(oL.fFw(V_-up.gR))/(kz-up.xK));
}
up.xK=kz;
up.gR=oL.fFw(V_);
if(up.QO.Bt>Math.max(up.T8Y,up.ZRS)){
up.QO.DU(up.QO.Bt-1);
}
return up.tSo();
}

LK(up,"tSo",_iv);
function _iv(){
var KL4=null;
var SZx=up.QO.Bt;
if(SZx>=Math.min(up.T8Y,up.ZRS)){
var qZE=0.0;
var bC=up.QO.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var ok=bC[Jo];

qZE+=ok;
}
qZE/=SZx;

if(SZx>=up.T8Y
&&Math.abs(qZE-up.Lnr)<up.qr7){
KL4=Inferrer.MOVING_STATE;
}
if(SZx>=up.ZRS
&&qZE==up.W9b){
KL4=Inferrer.NOT_MOVING_STATE;
}
}





return KL4;
}

LK(up,"bV",AH);
function AH(){
up.QO=new Yw();
up.gR=-1;
up.xK=0;
}

LK(up,"k2K",mHr);
function mHr(){
if(up.lAz){
if(up.lAz.Wt("movingMinimumSamples")){
up.T8Y=up.lAz.tc("movingMinimumSamples");
}
if(up.lAz.Wt("notMovingMinimumSamples")){
up.ZRS=up.lAz.tc("notMovingMinimumSamples");
}
if(up.lAz.Wt("movingExpectedSpeed")){
up.Lnr=up.lAz.tc("movingExpectedSpeed");
}
if(up.lAz.Wt("notMovingExpectedSpeed")){
up.W9b=up.lAz.tc("notMovingExpectedSpeed");
}
if(up.lAz.Wt("movingSpeedTolerance")){
up.qr7=up.lAz.tc("movingSpeedTolerance");
}
}
}







if(up!=fj)ju.apply(up,arguments);
}
Bg(Inferrer,"Inferrer");




function sk(){
var up=this;

if(up!=fj)up.Tj=undefined;
if(up!=fj)up.vN=undefined;
function ju(Tj,vN){
up.Tj=Tj;
up.vN=vN;
}


ED(up,"Zw",kt);
function kt(){
return up.Tj;
}

ED(up,"GU",LL);
function LL(){
return up.vN;
}
if(up!=fj)ju.apply(this,arguments);

}
Bg(sk,"sk");





function oL(){
oL.w_=function(HW,ab){
return HW.indexOf(ab);
};

oL.JA=function(HW,ab){
return(0==HW.indexOf(ab));
};

oL.Pe=function(HW,ab){
return(0<=HW.indexOf(ab));
};

oL.tF=function(nI,IO){
if(IO<0||IO>=nI.length){
throw new Error("ArgumentOutOfRange");
}
return nI[IO];
};

oL.n0=function(_W,Bx,Mf){
if(Bx<0||Bx>=_W.length||(Mf!=undefined&&(Mf<0||Bx+Mf>_W.length))){
throw new Error("ArgumentOutOfRange");
}
if(Mf==undefined){
return _W.substr(Bx);
}else{
return _W.substr(Bx,Mf);
}
};

oL.Nq=function(HW,qf){
var S5=HW.split(qf);
return jh.Y_(S5);
};

oL.mT=function(nI){
return nI.split("");
};

oL.hI=function(ZR,Mp){
if(ZR==null){
if(Mp==null)return 0;
return-1;
}
if(Mp==null)return 1;

if(ZR<Mp)return-1;
if(ZR==Mp)return 0;
return 1;
};

oL.xO=function(nI){
return nI.replace(/^\s*/,"").replace(/\s*$/,"");
};

oL.ZLT=function(ZR,Q3s,I40){
if(Q3s==null||Q3s==""||I40==null){
throw new Error("InvalidArgument");
}

var ecJ=ZR.indexOf(Q3s);
if(ecJ>=0){
var AS=Q3s.length;

return ZR.substr(0,ecJ)+I40+oL.ZLT(ZR.substr(ecJ+AS),Q3s,I40);
}else{
return ZR;
}
};

oL._Tg=function(ZR,Q3s){
if(Q3s==null||Q3s==""){
throw new Error("InvalidArgument");
}
return ZR.lastIndexOf(Q3s);
}

oL.js=function(l4){
return Yw.Y_(l4);
};


oL.zF=function(zr){
return jh.Y_(zr);
};




oL.LS=function(l4){
if(l4==null)return null;
return l4.UX();
};

oL.js=function(zr){
return Yw.Y_(zr);
};


oL.R5=function(cn){
if(cn==null)return null;
return cn.UX();
};


oL.PX=function(zr){
var mP=EW.Y_(zr);

return mP;
};


oL.uM=function(aq){
if(aq==null)return null;
if(aq.hasOwnProperty("A6")){
return aq.A6();
}else{
return aq;
}
};

oL.Jp=function(aq,sq){
if(aq==null)return;
aq.Rr(sq);
};





oL._TN=function(nI){
return nI;
}


oL.FP=function(_W){
try{
if(window.DOMParser){
var p3=(new DOMParser()).parseFromString(_W,"text/xml");
return p3.documentElement;
}else{

var p3=new i8("Microsoft.XMLDOM");
p3.async="false";
p3.loadXML(_W);
return p3.documentElement;
}
}catch(fe){
return null;
}
};

oL.EP=function(Vl){
try{
if(window.XMLSerializer){
return(new XMLSerializer()).serializeToString(Vl);
}else{
return Vl.xml;
}
}catch(fe){
return null;
}
};

oL.fg=function(LQ){

if(typeof(LQ.fg)=="function"){
return LQ.fg();
}else{
return LQ.toString();
}
}

oL.WOY=function(nI){
return nI.toLowerCase();
}

oL.t2u=function(nI){
return parseInt(nI);
}

oL.fFw=function(Sk){
if(Sk instanceof L_){
return Sk.mg;
}else if(Sk instanceof Q2){
return Sk.mg;
}else{
return Number(Sk);
}
}


oL.N1V=new RegExp("^([+-]?[0-9]*\\.?[0-9]+)((e|E)[+-]?[0-9]+)?$");
oL.iGL=function(Sk){


oL.qlz(Sk,oL.N1V,"double");
return parseFloat(Sk);
}

oL.qlz=function(nI,IgG,jE){
if(!IgG.test(nI)){
throw new Error("Invalid string for "+jE+": "+nI);
}
}
}
Bg(oL,"oL");





function Yw(){
var up=this;

if(up!=fj)up.E0=undefined;
function ju(){

if(arguments.length>1){
SH.z2("Error: Instantiate ListCS with too many arguments");
}else if(arguments.length==0){
jh.call(up,0);
}else if(arguments[0]instanceof Number){
jh.call(up,arguments[0]);
}else if(arguments[0]instanceof Array){
jh.call(up,arguments[0].length);
up.E0=arguments[0];
}else if(arguments[0]instanceof jh){
jh.call(up,arguments[0].length);
up.E0=arguments[0].E0;
}else{
SH.z2("Error: Instantiate ListCS with inappropriate arguments");
}
}

dN(up,Yw,"oIy",yzx);
function yzx(l4){
var S5=new Yw();
for(var co=0;co<arguments.length;co++){
S5.E0.push(arguments[co]);
}
return S5;
}

dN(up,Yw,"Y_",gE);
function gE(l4){
if(l4==null){
return l4;
}
if(l4 instanceof Yw){
return l4;
}
var S5=new Yw();
S5.E0=l4;
return S5;
}

OZ(up,"UX",h0);
function h0(){
return up.E0;
}

ED(up,"Bt",il);
function il(){
return up.E0.length;
}

ED(up,"YC",jO);
function jO(){
return up.E0;
}

OZ(up,"Yb",hV);
function hV(fe){
up.E0.push(fe);
}

OZ(up,"m3",kG);
function kG(fe){
up.E0.length=0;
}

OZ(up,"Hh",pU);
function pU(fe){
var Bx=arguments[1];
if(Bx==null){
Bx=0;
}else if(Bx<0||Bx>=up.E0.length){
throw new Error("Starting index out of bound");
}

for(var co=Bx;co<up.E0.length;co++){
if(up.E0[co]==fe)return co;
}
return-1;
}

OZ(up,"OC",pi);
function pi(fe){
return up.Hh(fe)>=0;
}

OZ(up,"gX",KO);
function KO(Ny,fe){
up.E0.splice(Ny,0,fe);
}

OZ(up,"gS",ZQ);
function ZQ(fe){
var Ny=up.Hh(fe);
if(Ny<0)return false;
up.DU(Ny);
return true;
}

OZ(up,"JI",yp);
function yp(IO,Mf){
up.E0.splice(IO,Mf);
}

OZ(up,"DU",eA);
function eA(IO){
up.E0.splice(IO,1);
}

OZ(up,"g2",Al);
function Al(aw,Wp){
var S5=new Yw();
S5.E0=up.E0.slice(aw,aw+Wp);
return S5;
}

OZ(up,"HC",JE);
function JE(){
up.E0.sort.apply(up.E0,arguments);
}

OZ(up,"jR",tt);
function tt(){
return jh.Y_(up.E0.slice());
}

if(up!=fj)ju.apply(this,arguments);

}
Bg(Yw,"Yw");


































function CO(){
var up=this;
if(up!=fj)up.Xv=undefined;
if(up==fj)CO.fa=300;
if(up!=fj)up.lY=CO.fa*1000;

ED(up,"kw",En);
function En(){return up.lY;}


if(up==fj)CO.ku=20000;
if(up!=fj)up.ZE=CO.ku;

ED(up,"Yo",DR);
function DR(){return up.ZE;}

if(up==fj)CO.g0t=-1;
if(up!=fj)up.dp=CO.g0t;

ED(up,"W1",bJ);
function bJ(){
if(up.dp<=0){
return up.ZE;
}
return up.dp;
}

if(up==fj)CO.WC=2000;
if(up!=fj)up.wV=CO.WC;

ED(up,"bD",aU);
function aU(){return up.wV;}

if(up!=fj)up.__=CO.WC;

ED(up,"aa",W4);
function W4(){return up.__;}

if(up==fj)CO.wmb=-1;
if(up!=fj)up.PQ=CO.wmb;

ED(up,"Mi",SL);
function SL(){
if(up.PQ<=0){
return up.ZE;
}
return up.PQ;
}

if(up==fj)CO.LP=800;
if(up!=fj)up.Jy=CO.LP;

ED(up,"O2",TZ);
function TZ(){return up.Jy;}

if(up==fj)CO.ql=40000;
if(up!=fj)up.c2=CO.ql;

ED(up,"C3",we);
function we(){return up.c2;}

if(up==fj)CO.e3="0";
if(up!=fj)up.Tl=CO.e3;

ED(up,"PH",oX);
function oX(){return up.Tl;}

if(up==fj)CO.uF=600;
if(up==fj)CO._B=CO.uF*1000;

Va(up,CO,"dy",HY);
function HY(){return CO._B;}

if(up==fj)CO.N0=300;
if(up==fj)CO.Wh=CO.N0*1000;

Va(up,CO,"E6",yx);
function yx(){return CO.Wh;}



if(up==fj)CO.zS=30;
if(up==fj)CO.OU=CO.zS*1000;

Va(up,CO,"fN",LR);
function LR(){return CO.OU;}

if(up==fj)CO.vg=30;
if(up==fj)CO.HQ=CO.vg*1000;

Va(up,CO,"xn",yh);
function yh(){return CO.HQ;}





if(up==fj)CO.Kox="";
if(up==fj)CO.zHg=CO.Kox;

Va(up,CO,"kd9",k1U);
function k1U(){return CO.zHg;}









if(up==fj)CO.K84=110;
if(up==fj)CO.Qpn=CO.K84/100.0;

Va(up,CO,"xCh",njI);
function njI(){return CO.Qpn;}





if(up==fj)CO.eKR=true;

Va(up,CO,"n4C",Rd1);
function Rd1(){return CO.eKR;}




if(up==fj)CO.GAq=true;

Va(up,CO,"Cwv",NZM);
function NZM(){return CO.GAq;}




if(up==fj)CO.cgp=10;
if(up==fj)CO.ukx=CO.cgp;

Va(up,CO,"vOF",rhL);
function rhL(){return CO.ukx;}



if(up==fj)CO.Fn5=-1;
if(up==fj)CO.nup=CO.Fn5;

Va(up,CO,"ayU",hN_);
function hN_(){return CO.nup;}



if(up==fj)CO.Ou_=-1;
if(up==fj)CO.WVf=CO.Ou_;

Va(up,CO,"N0l",VVN);
function VVN(){return CO.WVf;}



if(up==fj)CO.S4t=60;
if(up==fj)CO.B33=CO.S4t;

Va(up,CO,"wq2",_zv);
function _zv(){return CO.B33;}

if(up==fj)CO.J2=1200;
if(up==fj)CO.ln=CO.J2*1000;

Va(up,CO,"Qw",Py);
function Py(){return CO.ln;}



if(up==fj)CO.Ix=true;

Va(up,CO,"U5",v2);
function v2(){return CO.Ix;}


if(up==fj)CO.Ze=true;

Va(up,CO,"ex",gY);
function gY(){return CO.Ze;}




if(up==fj)CO.MjM="true";
if(up==fj)CO.NUU=(CO.MjM=="true");

Va(up,CO,"Qn3",CDn);
function CDn(){return CO.NUU;}


if(up==fj)CO.jUw=false;

Va(up,CO,"rbL",UhK);
function UhK(){return CO.jUw;}


if(up==fj)CO.fZ=false;

Va(up,CO,"pY",ey);
function ey(){return CO.fZ;}

if(up==fj)CO.a3=false;

Va(up,CO,"wh",yb);
function yb(){return CO.a3;}




if(up==fj)CO.MPH=true;

Va(up,CO,"Ugx",OIE);
function OIE(){return CO.MPH;}




if(up!=fj)up.PMc=true;

ED(up,"uKm",iuu);
function iuu(){return up.PMc;}





if(up==fj)CO.Nee=8*1000;
if(up==fj)CO.sNi=CO.Nee;

Va(up,CO,"CGD",CzB);
function CzB(){return CO.sNi;}




if(up==fj)CO.L9P=5*60;
if(up==fj)CO.Srw=CO.L9P;

Va(up,CO,"v9u",WTW);
function WTW(){return CO.Srw;}




if(up==fj)CO.wg9=7*1000;
if(up==fj)CO._CK=CO.wg9;

Va(up,CO,"Wj1",VB0);
function VB0(){return CO._CK;}





if(up==fj)CO.VpK=500;
if(up==fj)CO.MOU=CO.VpK;

Va(up,CO,"Bwj",iyO);
function iyO(){return CO.MOU;}




if(up==fj)CO.dVe=10;
if(up==fj)CO.OVq=CO.dVe;

Va(up,CO,"cWG",Gun);
function Gun(){return CO.OVq;}





if(up==fj)CO.Uid=4*1000;
if(up==fj)CO.LxP=CO.Uid;

Va(up,CO,"tOm",Pt5);
function Pt5(){return CO.LxP;}





if(up==fj)CO.rN9=15*1000;
if(up==fj)CO.JLC=CO.rN9;

Va(up,CO,"FnO",tiJ);
function tiJ(){return CO.JLC;}





if(up==fj)CO.Q1C=15*1000;
if(up==fj)CO.haG=CO.Q1C;

Va(up,CO,"ZWb",din);
function din(){return CO.haG;}



if(up==fj)CO.emZ=4*1000;
if(up==fj)CO.Vfx=CO.emZ;

Va(up,CO,"T90",UFW);
function UFW(){return CO.Vfx;}



if(up==fj)CO.iXJ=2;
if(up==fj)CO.q5j=CO.iXJ;

Va(up,CO,"SJR",Twp);
function Twp(){return CO.q5j;}



if(up==fj)CO.q_u=120*1000;
if(up==fj)CO.OHC=CO.q_u;

Va(up,CO,"HVc",K5v);
function K5v(){return CO.OHC;}



if(up==fj)CO.UAc=600*1000;
if(up==fj)CO.pJ4=CO.UAc;

Va(up,CO,"Vv0",Wdl);
function Wdl(){return CO.pJ4;}



if(up==fj)CO.ZLI=2;
if(up==fj)CO.hJk=CO.ZLI;

Va(up,CO,"BBC",ikc);
function ikc(){return CO.hJk;}



if(up==fj)CO.MSg=15*1000;
if(up==fj)CO.uzA=CO.MSg;

Va(up,CO,"qCz",LPq);
function LPq(){return CO.uzA;}






if(up==fj)CO.h4A=0;
if(up==fj)CO.kxN=CO.h4A/100.0;

Va(up,CO,"tGr",qly);
function qly(){return CO.kxN;}

if(up==fj)CO.Mu=600;
if(up==fj)CO.mz=CO.Mu*1000;

Va(up,CO,"n_",kM);
function kM(){return CO.mz;}

if(up==fj)CO.rH=15;
if(up==fj)CO.OQ=CO.rH;

Va(up,CO,"p7",WO);
function WO(){return CO.OQ;}

if(up==fj)CO.Oi=30*1000;
if(up==fj)CO.D2=CO.Oi;

Va(up,CO,"VU",hh);
function hh(){return CO.D2;}

if(up==fj)CO.qz0=7*1000;
if(up==fj)CO.xb=CO.qz0;

Va(up,CO,"vS",Yk);
function Yk(){return CO.xb;}

if(up==fj)CO.NYf=11*1000;
if(up==fj)CO.ur=CO.NYf;

Va(up,CO,"vJ",EE);
function EE(){return CO.ur;}


if(up==fj)CO.eD8=3*1000;
if(up==fj)CO.CPP=CO.eD8;

Va(up,CO,"ib5",jEo);
function jEo(){return CO.CPP;}


if(up==fj)CO.F5Q=10*1000;
if(up==fj)CO.MOY=CO.F5Q;

Va(up,CO,"tE1",xR4);
function xR4(){return CO.MOY;}


if(up==fj)CO.Z1d=1*1000;
if(up==fj)CO.YrT=CO.Z1d;

Va(up,CO,"kev",D7H);
function D7H(){return CO.YrT;}

if(up==fj)CO.qS=10;
if(up==fj)CO.nP=CO.qS*1000;

Va(up,CO,"yK",zC);
function zC(){return CO.nP;}

if(up==fj)CO.ao=5;
if(up==fj)CO.MW=CO.ao;

Va(up,CO,"j8",_P);
function _P(){return CO.MW;}

if(up==fj)CO.CH=30;
if(up==fj)CO.P5=CO.CH*1000;

Va(up,CO,"Lc",tD);
function tD(){return CO.P5;}

if(up==fj)CO.rA=25;
if(up==fj)CO.uI=CO.rA;

Va(up,CO,"LY",U8);
function U8(){return CO.uI;}

if(up==fj)CO.o7=7;
if(up==fj)CO.tz=CO.o7;

Va(up,CO,"vC",Lu);
function Lu(){return CO.tz;}

if(up==fj)CO.dj=false;

Va(up,CO,"D5",jH);
function jH(){return CO.dj;}

if(up==fj)CO.gk=20000;
if(up!=fj)up.dB=CO.gk;

ED(up,"hJ",Ct);
function Ct(){return up.dB;}

if(up!=fj)up.nT6=true;

ED(up,"mSk",Ure);
function Ure(){return up.nT6;}

if(up==fj)CO.PGP=200;
if(up!=fj)up.D2N=CO.PGP;

ED(up,"ZVW",kD1);
function kD1(){return up.D2N;}

if(up!=fj)up.ZOv=false;

ED(up,"xz0",b0i);
function b0i(){return up.ZOv;}



if(up==fj)CO.M76=90*1000;
if(up==fj)CO.r0D=CO.M76;

Va(up,CO,"eon",ubb);
function ubb(){return CO.r0D;}




if(up==fj)CO.UUz=6;
if(up==fj)CO._PF=CO.UUz;

Va(up,CO,"PmJ",kLE);
function kLE(){return CO._PF;}





if(up==fj)CO.BPn=3;
if(up==fj)CO.Eii=CO.BPn;

Va(up,CO,"uE8",B8N);
function B8N(){return CO.Eii;}











if(up==fj)CO.IhZ="llnwd\\.net";
if(up==fj)CO.AKr=CO.IhZ;

Va(up,CO,"k48",qQ_);
function qQ_(){return CO.AKr;}




if(up==fj)CO.pul=true;
if(up==fj)CO.bgo=CO.pul;

Va(up,CO,"hIA",zDl);
function zDl(){return CO.bgo;}





if(up==fj)CO.xXe=true;
if(up==fj)CO.JLS=CO.xXe;

Va(up,CO,"G1r",z83);
function z83(){return CO.JLS;}












if(up==fj)CO.you=true;
if(up==fj)CO.wuk=CO.you;

Va(up,CO,"N7P",z2O);
function z2O(){return CO.wuk;}








if(up==fj)CO.Nbp=false;
if(up==fj)CO.CVM=CO.Nbp;

Va(up,CO,"lHo",IL_);
function IL_(){return CO.CVM;}







if(up==fj)CO.GfX=50;
if(up==fj)CO.Gc2=CO.GfX;

Va(up,CO,"xIL",ObS);
function ObS(){return CO.Gc2;}





if(up==fj)CO.DNM=true;
if(up==fj)CO.ti_=CO.DNM;

Va(up,CO,"fJ8",hcj);
function hcj(){return CO.ti_;}





if(up==fj)CO.LbH=true;
if(up==fj)CO.GOJ=CO.LbH;

Va(up,CO,"RwB",PhU);
function PhU(){return CO.GOJ;}






if(up==fj)CO.avT=3;
if(up==fj)CO.QPE=CO.avT;

Va(up,CO,"JdX",haS);
function haS(){return CO.QPE;}




if(up==fj)CO.gOO=100;
if(up==fj)CO.mAR=CO.gOO;

Va(up,CO,"IB2",nC4);
function nC4(){return CO.mAR;}





if(up==fj)CO.xTh=1;
if(up==fj)CO.Gwm=CO.xTh;

Va(up,CO,"Ojc",EIk);
function EIk(){return CO.Gwm;}





if(up==fj)CO.pvY=true;
if(up==fj)CO.Zgo=CO.pvY;

Va(up,CO,"scs",dAh);
function dAh(){return CO.Zgo;}




if(up==fj)CO.GO1=5000;
if(up==fj)CO.L4E=CO.GO1;

Va(up,CO,"tTS",eGj);
function eGj(){return CO.L4E;}




if(up==fj)CO.cEQ=false;
if(up==fj)CO.rET=CO.cEQ;

Va(up,CO,"RY2",ugd);
function ugd(){return CO.rET;}




if(up==fj)CO.XMl=4000;
if(up==fj)CO.X8Z=CO.XMl;

Va(up,CO,"UA7",B_8);
function B_8(){return CO.X8Z;}




if(up==fj)CO.mNd=6000;
if(up==fj)CO.VaV=CO.mNd;

Va(up,CO,"J95",VQw);
function VQw(){return CO.VaV;}






if(up==fj)CO.fiE=false;
if(up==fj)CO.vI5=CO.fiE;

Va(up,CO,"xOJ",vOg);
function vOg(){return CO.vI5;}





if(up==fj)CO.BQT=120;
if(up==fj)CO.Vmh=CO.BQT/100.0;

Va(up,CO,"Tbb",aHg);
function aHg(){return CO.Vmh;}





if(up==fj)CO.kYV=100;
if(up==fj)CO.d3v=CO.kYV;

Va(up,CO,"wuv",J7g);
function J7g(){return CO.d3v;}





if(up==fj)CO.gt3=100;
if(up==fj)CO.oAN=CO.gt3;

Va(up,CO,"xKE",mFv);
function mFv(){return CO.oAN;}





if(up==fj)CO.URj=60*1000;
if(up==fj)CO.uLH=CO.URj;

Va(up,CO,"P_m",ATK);
function ATK(){return CO.uLH;}





if(up==fj)CO.ke0=120;
if(up==fj)CO.kTO=CO.ke0*1000;

Va(up,CO,"DVd",cOo);
function cOo(){return CO.kTO;}





if(up==fj)CO.Jh6=2;
if(up==fj)CO.qvB=CO.Jh6;

Va(up,CO,"lWO",zt0);
function zt0(){return CO.qvB;}





if(up==fj)CO.P1j=1000;
if(up==fj)CO.IjK=CO.P1j;

Va(up,CO,"NYy",hxn);
function hxn(){return CO.IjK;}





if(up==fj)CO.nkp=5;
if(up==fj)CO.jf9=CO.nkp;

Va(up,CO,"t0Z",ZVF);
function ZVF(){return CO.jf9;}





if(up==fj)CO.KRY=30;
if(up==fj)CO.zAe=CO.KRY;

Va(up,CO,"max",bAT);
function bAT(){return CO.zAe;}


if(up==fj)CO.Ve0=0;
if(up==fj)CO.S9x=CO.Ve0;

Va(up,CO,"z4C",IoJ);
function IoJ(){return CO.S9x;}



if(up==fj)CO.apT=1;
if(up==fj)CO.gpk=CO.apT;

Va(up,CO,"Yqi",ELi);
function ELi(){return CO.gpk;}



if(up==fj)CO.MMn="";
if(up==fj)CO.LhM=CO.MMn;

Va(up,CO,"XHx",kSs);
function kSs(){return CO.LhM;}



if(up==fj)CO.fi6=7000;
if(up==fj)CO.y7X=CO.fi6;

Va(up,CO,"pbv",MtV);
function MtV(){return CO.y7X;}


if(up==fj)CO.ort=false;
if(up==fj)CO.CVl=CO.ort;

Va(up,CO,"Bpl",pdx);
function pdx(){return CO.CVl;}



if(up==fj)CO.TR3=false;
if(up==fj)CO.lJy=CO.TR3;

Va(up,CO,"ZKN",eGZ);
function eGZ(){return CO.lJy;}


if(up==fj)CO.nIp=false;
if(up==fj)CO.cSA=CO.nIp;

Va(up,CO,"ZuQ",Un4);
function Un4(){return CO.cSA;}



if(up==fj)CO.tTm=false;
if(up==fj)CO._rL=CO.tTm;

Va(up,CO,"CM5",utm);
function utm(){return CO._rL;}




if(up==fj)CO.isR=500;
if(up==fj)CO.Sbo=CO.isR;

Va(up,CO,"HkQ",Afc);
function Afc(){return CO.Sbo;}



if(up!=fj)up.lQv=undefined;

if(up!=fj)up.G4D=undefined;


if(up!=fj)up.f9=undefined;
if(up!=fj)up.Tko=undefined;

if(up!=fj)up.h5=undefined;
if(up!=fj)up.WQ=undefined;
if(up!=fj)up.I8=undefined;

if(up==fj)CO.BX="livePassConfig.xml";
if(up==fj)CO.wA=CO.BX;



if(up!=fj)up.bB=undefined;

ED(up,"iw",k0);
function k0(){return up.bB;}

if(up!=fj)up.KS=undefined;

ED(up,"Fm",zM);
function zM(){return up.KS;}


if(up==fj)CO.U0n=100;
if(up==fj)CO.K45=CO.U0n;

Va(up,CO,"_Uf",Og_);
function Og_(){return CO.K45;}


if(up==fj)CO.Ozf=false;
if(up==fj)CO.LDt=CO.Ozf;

Va(up,CO,"jfb",lOX);
function lOX(){return CO.LDt;}


if(up!=fj)up.gF=undefined;





if(up==fj)CO.POc=null;




if(up!=fj)up.sHG=false;


if(up!=fj)up.KQN=undefined;




if(up==fj)CO.JAS=5000;
if(up==fj)CO.knV=CO.JAS;




if(up==fj)CO.XyF=false;



if(up==fj)CO.yG3="livepassdl.conviva.com/module/";
if(up==fj)CO.LUW=undefined;












function ju(sz,n1,ME,sC,YA,bWC){
up.h5=sz;
up.WQ=n1;
up.I8=sC;
up.sHG=bWC;
up.Xv=new M8();
if(ME!=null){
up.Xv.q_(ME);
}

up.lQv=null;
up.G4D=null;
up.bB=null;
up.KQN=0;
if(YA!=null){

up.lQv=uPJ.orQ(YA);
up.A1();
if(bWC){
if(CO.Ykc(up.lQv)){

up.Tb();
}else{
up.L9(up.lY);
}
}
}else{

up.gF=null;

up.Tb();
}
}


LK(up,"D_d",D82);
function D82(){
up.I8=null;
up.Xv=new M8();
up.L9(up.lY);
up.sHG=true;
}











dN(up,CO,"mR",Za);
function Za(sz,n1,ME,sC){


if(CO.POc!=null){
CO.POc.wy();
CO.POc=null;
}
CO.POc=new CO(sz,n1,ME,sC,null,false);
return CO.POc;
}











dN(up,CO,"xWy",qbO);
function qbO(sz,n1,ME,sC){
O9.y8(CO.LUW!=null,"_fake_config_xml needs to be set");
if(CO.POc!=null){
CO.POc.wy();
CO.POc=null;
}

CO.POc=new CO(sz,n1,ME,sC,CO.LUW,false);
return CO.POc;
}









dN(up,CO,"Z2",Si);
function Si(sz,n1,YA,QZF){
if(QZF&&CO.POc!=null){


CO.POc.D_d();
}else{
O9.y8(CO.POc==null||!CO.POc.sHG,"createPeriodicLoader.instance");
O9.y8(YA!=null,"createPeriodicLoader.config");

CO.POc=new CO(sz,n1,null,null,YA,true);
}
return CO.POc;
}




dN(up,CO,"el",aY);
function aY(){

return CO.POc;
}


dN(up,CO,"bx",vl);
function vl(){
if(CO.POc!=null){
CO.POc.wy();
CO.POc=null;
}
CO.b9=null;
CO.dgH=false;

CO.ng=null;
CO.wA=CO.BX;
CO.XyF=false;
CO.grL=null;
CO.U7B=null;
CO.knV=CO.JAS;
}


OZ(up,"wy",NQ);
function NQ(){
if(up.f9!=null){
up.f9.wy();
up.f9=null;
}
if(up.Tko!=null){
up.Tko.wy();
up.Tko=null;
}
if(up.gF!=null){
up.gF.wy();
up.gF=null;
}
if(up.Xv!=null){
up.Xv.wy();
up.Xv=null;
}
up.G4D=null;
up.lQv=null;
up.h5=null;
}



LK(up,"bF",St);
function St(eCx){







var nI=undefined;
if(eCx){
nI=CO.Tsf(up.h5);
}else{
nI=CO.C4c(up.h5);
}
nI+="/lpconfig/cfg/";
nI+=CO.GK("c3.customerName",up.WQ);
var tis=undefined;
tis="JS";
nI+="&"+CO.GK("c3.platform",tis);
var wY=false;
wY=(up.gF!=null);

if(wY){

nI+="&"+CO.GK("c3.dver",Uj.Re);
}else{

nI+="&"+CO.GK("c3.sver",Uj.Re);
}
nI+="?random="+O9.bG();



nI+="&uuid="+gV.eSE();
return nI;
}

dN(up,CO,"GK",DR3);
function DR3(Tj,nQ){
return(O9.oN(Tj)+"="+O9.oN(nQ));
}






dN(up,CO,"Tsf",b5U);
function b5U(sz){
var Y_F=oL.Nq(sz,'/');
if(Y_F.ug>=3){
var pq=Y_F.tc(2);
if(CO.grL!=null){
return oL.ZLT(sz,pq,CO.grL);
}else if(pq=="livepass.conviva.com"){
return oL.ZLT(sz,pq,"livepassdl.conviva.com");
}else if(pq=="livepass.staging.conviva.com"){
return oL.ZLT(sz,pq,"livepassdl.staging.conviva.com");
}
}
return sz;
}

dN(up,CO,"C4c",J0F);
function J0F(sz){
var Y_F=oL.Nq(sz,'/');
if(Y_F.ug>=3){
var pq=Y_F.tc(2);
if(CO.U7B!=null){
return oL.ZLT(sz,pq,CO.U7B);
}else if(pq=="livepass.conviva.com"){
return oL.ZLT(sz,pq,"livepassdl2.conviva.com");
}else if(pq=="livepass.staging.conviva.com"){
return oL.ZLT(sz,pq,"livepassdl2.staging.conviva.com");
}
}
return sz;
}


ED(up,"OP",dt);
function dt(){
if(up.G4D!=null){
return up.G4D.vo();
}
return null;
}

OZ(up,"Tb",Tm);
function Tm(){
if(CO.b9!=null){
up.lQv=uPJ.orQ(CO.b9);
up.A1();
return;
}
var H1=up.bF(true);
ct.qF("LivePassConfigLoader","loading primary config "+H1);
var ym=null;

if(!up.sHG){

ym=new EW();
if(CO.knV!=0){
ym.Yb("timeoutMs",oL.fg(CO.knV));
}
}
up.f9=new nD(H1,
function(EU,fh){
up.we6(EU,fh);
},null,ym);
}

LK(up,"we6",DrT);
function DrT(EU,fh){
O9.Yv(
function(){
if(up.sHG){
if(EU==null){
up.oy5(fh.X5);
}else{
if(up.I8!=null)up.I8(EU);
}
}else{
if(EU==null){
CO.XyF=false;
ct.qF("LivePassConfigLoader","use the primary config");
up.oy5(fh.X5);
}else{

var cR5=up.bF(false);
if(cR5==fh.H1){
if(up.I8!=null)up.I8(EU);
}else{
ct.qF("LivePassConfigLoader","loading backup config "+cR5);
var ym=new EW();
if(CO.knV!=0){
ym.Yb("timeoutMs",oL.fg(CO.knV));
}
up.Tko=new nD(cR5,
function(fe,E7){
up.XBL(fe,E7);
},null,ym);
}
}
}
},"ProcessPrimaryResponse");
}

LK(up,"XBL",AuZ);
function AuZ(EU,fh){
O9.Yv(
function(){
if(EU==null){
CO.XyF=true;
up.oy5(fh.X5);
}else{

ct.qF("LivePassConfigLoader","loading the backup configuration failed");
if(up.I8!=null)up.I8(EU);
}
},"ProcessBackupResponse");
}

LK(up,"oy5",Sh7);
function Sh7(JEp){
ct.qF("LivePassConfigLoader","updateConfigXml");
var FaA=undefined;
FaA=JEp.fW();
if(FaA!=null){
up.lQv=uPJ.Y_(FaA);
O9.Yv(up.A1,"LPConfigLoader.HandleNewConfig");
}else{
SH.z2("LivePassConfigLoader newConfigDoc==null");
}
}



LK(up,"A1",s4);
function s4(){
if(up.lQv==null)return;
var Ykc=CO.Ykc(up.lQv);
if(!up.qun(up.lQv)){
var rU="LivePassConfigLoader.HandleNewConfig:"+
"Got an invalid livePassConfig ";

if(O9.rV()<0.001){



rU+=("doc="+up.lQv.vo());
rU=oL.n0(rU,0,1000);
}
O9.Ep(rU,true);
return;
}

if(Ykc){
up.G4D=up.lQv;
}else{
if(up.bB==null){

up.bB=up.hc();
}
up.G4D=up.lQv.Im(up.bB);
var osi=up.G4D.ixD("alternative").Bt;
if(osi!=1){



var MVp="LivePassConfigLoader.processConfigXML:"
+"Did not find exactly one alternative. alt="+oL.fg(up.bB)+", "
+"count="+osi;
if(O9.rV()<0.001){



MVp+=("doc="+up.lQv.vo());
MVp=oL.n0(MVp,0,1000);
}
O9.Ep(MVp,true);
}
}


if(!CO.dgH&&!Ykc){
up.KS=0;
try{
var BH="";
BH=up.G4D.SX("ccsWallTimeSec");
if(BH!=null){
up.KS=1000.0*oL.iGL(BH);
}
}catch(fe){
}
}else{


up.KS=0;
}


if(!Ykc){

try{
CO.S9x=VW.tn(up.G4D.SX("serviceConfigVersion"));
}catch(fe){

}
}


if(CO.U7B!=null){
CO.czI=up.G4D.SX("service");
}
up.KQN=0;
up.DJT(VW.Je);
}



LK(up,"DJT",l5d);
function l5d(p4b){

CO.K45=up.Gv("pingRatePercent","value",CO.U0n);



CO.LDt=up.UZr("lzmaEnabled","value",CO.Ozf);

var fYT=false;
while(p4b>0&&!fYT){
switch(up.KQN){

case 0:

up.ZE=up.Gv("heartbeatIntervalMs","value",
CO.ku);

up.ZE=up.Gv("heartbeatInterval","msecs",
up.ZE);






up.dp=up.Gv("heartbeatIntervalLightMs","value",
up.ZE);

up.wV=up.Gv("heartbeatIntervalUrgentFullMs","value",
CO.WC);

up.__=up.Gv("heartbeatIntervalUrgentLightMs","value",
CO.WC);



up.PQ=up.Gv("heartbeatIntervalPauseMs","value",
up.ZE);


up.Jy=up.Gv("initSelectResourceIntervalMs","value",
CO.LP);


up.c2=up.Gv("selectResourceIntervalMs","value",
CO.ql);

up.c2=up.Gv("selectResourceInterval","msecs",
up.c2);


up.Tl=up.SX("protocolVersion","value",
CO.e3);


up.Tl=up.SX("protocolVersion","ver",
up.Tl);


var D0=up.Gv("refreshIntervalSec","value",
CO.fa);

D0=up.Gv("refreshInterval","secs",
D0);

if(D0*1000!=up.lY){
up.lY=D0*1000;
if(up.gF!=null){
up.gF.wy();
up.L9(up.lY);
}
}


var Vo=up.Gv("maxPlayerPausedIntervalSec","value",
CO.uF);

Vo=up.Gv("maxPlayerPausedIntervalSec","secs",
Vo);
CO._B=1000*Vo;
break;
case 1:

var SR=up.Gv("maxPlayerBufferingIntervalSec","value",
CO.N0);

SR=up.Gv("maxPlayerBufferingIntervalSec","secs",
SR);
CO.Wh=1000*SR;

var iE=up.Gv("maxPlayerStoppedIntervalSec","value",
CO.zS);

iE=up.Gv("maxPlayerStoppedIntervalSec","secs",
iE);
CO.OU=1000*iE;

var tS1=up.Gv("minStartStopIntervalMs",
"value",CO.Ou_);
CO.WVf=tS1;



var AZ9=up.Gv("phtStopThresholdSec",
"value",CO.cgp);
CO.ukx=AZ9;

var Yxn=up.Gv("urlGeneratorTimeoutSec",
"value",CO.Fn5);
CO.nup=Yxn;


var gTJ=up.Gv("traceOnSwitchDurationThresholdSec",
"value",CO.S4t);
CO.B33=gTJ;


var tG=up.Gv("maxSwitchLockTimeSec","value",CO.J2);
CO.ln=tG*1000;


CO.fZ=(up.SX("fastSwitchUpEnabled","value","false")=="true");


CO.jUw=(up.SX("play2Disabled","value","false")=="true");

CO.Ze=(up.SX("unpublishNotifyEnabled","value","true")=="true");


CO.NUU=(up.SX("playStopEnabled","value",CO.MjM)=="true");

CO.Ix=(up.SX("recoverForByteRuleEnabled","value","true")=="true");
break;
case 2:

CO.a3=(up.SX("lazySwitchLockEnabled","value","false")=="true");

CO.MPH=(up.SX("bytesLoadedSwitchDownEnabled","value","true")=="true");

up.PMc=up.UZr("syncModeEnabled","value",true);

CO.sNi=up.lHg("livePlay2StartTimeoutSec","value",CO.Nee);

CO.Srw=up.Gv("resourceSwitchDampenIntervalSec","value",CO.L9P);

CO._CK=up.Gv("bytesLoadedWindowMs","value",CO.wg9);

CO.MOU=up.Gv("switchControlCheckIntervalMs","value",CO.VpK);

CO.OVq=up.Gv("frameDropRatioMediumThreshold","value",CO.dVe);

CO.LxP=up.Gv("liveLazySwitchBufferLengthThresholdMs","value",CO.Uid);

CO.JLC=up.Gv("vodLazySwitchBufferLengthThresholdMs","value",CO.rN9);

CO.haG=up.Gv("zeriLazySwitchBufferLengthThresholdMs","value",CO.Q1C);

CO.Vfx=up.Gv("baseRecoveryWaitTimeMs","value",CO.emZ);

CO.q5j=up.Gv("recoveryWaitBackoffRate","value",CO.iXJ);

CO.OHC=up.Gv("maxRecoveryWaitTimeMs","value",CO.q_u);

CO.pJ4=up.Gv("baseSwitchLockTimeMs","value",CO.UAc);
break;
case 3:
CO.hJk=up.Gv("switchLockBackoffRate","value",CO.ZLI);

CO.uzA=up.Gv("bufferTrendExtrapolationTimeMs","value",CO.MSg);

var lnq=(up.Gv("flashAccessPingPct","value",
CO.h4A));
CO.kxN=lnq/100.0;


var yz=up.Gv("maxPlayerErrorIntervalSec","value",
CO.vg);

yz=up.Gv("maxPlayerErrorIntervalSec","secs",
yz);
CO.HQ=1000*yz;


CO.zHg=up.SX("abName","value",CO.Kox);


var Ym9=up.Gv("bandwidthMbrSafetyPct","value",
CO.K84);
CO.Qpn=Ym9/100.0;


CO.eKR=(up.SX("flashAccessModuleDownloadEnabled","value","true")=="true");


CO.GAq=(up.SX("fakeBufferFullEnabled","value","true")=="true");

var yF=up.Gv("maxPlayerNotMonitoredIntervalSec","value",
CO.Mu);

yF=up.Gv("maxPlayerNotMonitoredIntervalSec","secs",
yF);

CO.mz=1000*yF;


CO.OQ=up.Gv("maxLiveControlBufferEvent","value",
CO.rH);

CO.D2=up.lHg("maxLiveControlDurationSec","value",
CO.Oi);

CO.xb=up.lHg("maxLiveControlBufferingTimeSec","value",
CO.qz0);

CO.ur=up.lHg("maxLiveControlInitBufferingTimeSec","value",
CO.NYf);
break;
case 4:
CO.CPP=up.lHg("maxVodControlBufferingTimeSec","value",
CO.eD8);

CO.MOY=up.lHg("maxVodControlInitBufferingTimeSec","value",
CO.F5Q);

CO.YrT=up.lHg("maxZeriControlBufferingTimeSec","value",
CO.Z1d);

CO.MW=up.Gv("liveBufferTimeSec","value",
CO.ao);

CO.nP=1000*up.Gv("bwUpdateIntervalSec","value",
CO.qS);


CO.P5=1000*up.Gv("tokenExpiredIntervalSec","value",
CO.CH);


CO.dj=(up.SX("connectionRacerMemoryEnabled","value","false")=="true");


CO.tz=up.Gv("ConfigLoadIgnoreSec","value",
CO.o7);

CO.uI=up.Gv("frameDropRatioThreshold","value",
CO.rA);


up.dB=up.Gv("joinHbDelayMs","value",
CO.gk);


up.nT6=(up.SX("keepAliveEnabled","value","true")=="true");
up.D2N=up.Gv("keepAliveSecs","value",CO.PGP);


up.ZOv=up.UZr("nominalBitrateOverrideEnabled","value",false);


CO.r0D=up.Gv("maxRepeatedEventAgeMs","value",
CO.M76);

CO._PF=up.Gv("maxRepeatedEventsPerSessInfo","value",
CO.UUz);

CO.Eii=up.Gv("fcSubscribeTryTimes","value",
CO.BPn);


CO.AKr=up.SX("fcSubscribeUrlRegex","value",
CO.IhZ);



CO.JLS=up.UZr("inferPlayingStateFromFramerate","value",
CO.xXe);

CO.wuk=up.UZr("netStreamInfoEnabled","value",
CO.you);

CO.CVM=up.UZr("convivaBwMeasurementEnabled","value",
CO.Nbp);

CO.QPE=up.Gv("chunkRecoveryCheckIntervalSec","value",
CO.avT);
CO.ti_=up.UZr("disableFullChunkReport","value",CO.DNM);
CO.GOJ=up.UZr("isCachedChunkCountedForBwMeasurement","value",CO.LbH);
CO.Gc2=up.Gv("chunkRecoveryBufferLengthProvisionPercent","value",
CO.GfX);
CO.mAR=up.Gv("vodBufferTimeMs","value",CO.gOO);


CO.Gwm=up.Gv("switchControlImpl","value",CO.xTh);

CO.Zgo=up.UZr("useHistBwAtStart","value",CO.pvY);
CO.L4E=up.Gv("manifestTimeoutMs","value",CO.GO1);
CO.rET=up.UZr("precisionServerEnabled","value",CO.cEQ);

CO.X8Z=up.Gv("hdsAudioChunkFailureLockTimeMs","value",CO.XMl);
CO.VaV=up.Gv("hdsAudioChunkDownloadTimeoutMs","value",CO.mNd);

CO.vI5=up.UZr("stageVideoEnabled","value",CO.fiE);

var iHQ=up.Gv("httpBandwidthMbrSafetyPct","value",CO.BQT);
CO.Vmh=iHQ/100.0;

CO.d3v=up.Gv("httpFrameDropRatioThreshold","value",CO.kYV);

CO.oAN=up.Gv("httpFrameDropRatioMediumThreshold","value",CO.gt3);

CO.uLH=up.Gv("httpBaseSwitchLockTimeMs","value",CO.URj);

var pQz=up.Gv("httpMaxSwitchLockTimeSec","value",CO.ke0);
CO.kTO=pQz*1000;

CO.qvB=up.Gv("httpSwitchLockBackoffRate","value",CO.Jh6);

CO.IjK=up.Gv("httpVodBufferTimeMs","value",CO.P1j);

CO.jf9=up.Gv("httpLiveBufferTimeSec","value",CO.nkp);

CO.zAe=up.Gv("httpLiveMinimumOffsetSec","value",CO.KRY);

CO.bgo=up.UZr("disableMonStats","value",CO.pul);

CO.gpk=up.Gv("stitchingMinKeyFrames","value",CO.apT);

CO.LhM=up.SX("hlsKeyToken","value",CO.MMn);

CO.y7X=up.Gv("switchUpMinBufferLengthMs","value",CO.fi6);

CO.CVl=up.UZr("alignedHls","value",CO.ort);

CO.lJy=up.UZr("ignoreDroppedFramesIfHidden","value",CO.TR3);

CO.cSA=up.UZr("enforcePrecision","value",CO.nIp);

CO._rL=up.UZr("httpOverrideExternalBufferTime","value",CO.tTm);

CO.Sbo=up.Gv("stitchingToleranceMs","value",CO.isR);

break;
default:

fYT=true;
break;
}
p4b--;
up.KQN++;
}
if(!fYT)return;


up.KQN=0;
if(up.Xv!=null){
up.Xv._o();
}
}





OZ(up,"Cv",s0);
function s0(){
var PR=null;
PR="jsModulePath";
var S5=new Yw();
if(up.G4D==null)return S5;

var VR=up.G4D.ixD(PR);
var bC=VR.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var gZ=bC[Jo];

var H1=undefined;
if(gZ.XTo.textContent!=""){
H1=gZ.XTo.textContent;
}else if(gZ.tc()){
H1=gZ.tc();
}
S5.Yb(H1);
}
return S5;
}

OZ(up,"hZ",dR);
function dR(){
return up.G4D.ixD("gateway");
}




LK(up,"hc",IR);
function IR(){
var tA=new Yw();
var ZA=undefined;
var FLr=up.lQv.ixD("alternative");
var bC=FLr.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var tE=bC[Jo];

ZA=new Uf();
ZA.bL=tE.I8_();
ZA.ns=tE.deB();

if(ZA.ns>0){
tA.Yb(ZA);
}
}


var v7=0.0;
var HH=tA.YC;
for(var wt=0;wt<HH.length;wt++){
var q8w=HH[wt];

v7+=q8w.ns;
}

var yE=O9.rV()*v7;
var jk=tA.YC;
for(var jB=0;jB<jk.length;jB++){
var Df=jk[jB];

yE=yE-Df.ns;
if(yE<=0){
return Df.bL;
}
}
return null;
}






OZ(up,"SX",N3);
function N3(PR,Vj,lF){
if(CO.ng!=null&&CO.ng.Wt(PR)){
return CO.ng.tc(PR);
}
var cN=lF;

try{
var fO=up.G4D.ixD(PR);
if(fO!=null&&fO.Bt>0){
var Heq=fO.tc(0);
cN=Heq.SX(Vj);
if(cN==null){
cN=lF;
}
}
}catch(fe){
}
return cN;
}

OZ(up,"Gv",SO);
function SO(PR,Vj,lF){
var S5=lF;
try{
S5=VW.tn(up.SX(PR,Vj,oL.fg(lF)));
}catch(fe){

}
return S5;
}











OZ(up,"UZr",Yb1);
function Yb1(PR,Vj,lF){
var CsT=up.SX(PR,Vj,null);
if(CsT==null){
return lF;
}else if(CsT=="true"){
return true;
}else{
return false;
}
}



OZ(up,"Zu",q3);
function q3(z0){
up.Xv.q_(z0);
}

OZ(up,"fA",El);
function El(z0){
if(up.Xv!=null){
up.Xv.X8(z0);
}
}

LK(up,"L9",c3);
function c3(G1){
if(up.gF!=null){
up.gF.wy();
}
up.gF=new Lt(G1,up.Tb,"LivePassConfigLoader.LoadConfigGeneral");
}

OZ(up,"J7",Hw);
function Hw(PR,Vj,lF){
var S5=lF;
try{
S5=n4.tn(up.SX(PR,Vj,oL.fg(lF)));
}catch(fe){

}
return S5;
}
















OZ(up,"lHg",T98);
function T98(PR,Vj,HgO){
var S5=HgO;
try{
var pd4=up.SX(PR,Vj,null);
if(pd4!=null){
S5=1000*VW.tn(pd4);
}
}catch(fe){

}
return S5;
}


OZ(up,"YY",Os);
function Os(IO){
var LN=up.bF(true);

if(oL.w_(LN,'?')>=0){
LN=oL.n0(LN,0,oL.w_(LN,'?'));
}
IO.a9("LivePass.configUrl",LN);
IO.a9("LivePass.uuid",gV.eSE());
IO.a9("LivePass.pingId",oL.fg(SH.Jl));
}

LK(up,"qun",bM3);
function bM3(mV){
if(mV!=null){
if(mV.u_j()=="livePassConfig"){
return true;
}
}
return false;
}

dN(up,CO,"fUC",j6U);
function j6U(nI,Wp){
var cN=undefined;
for(cN=nI;cN.length<Wp;cN='0'+cN);
return cN;
}

dN(up,CO,"ngj",Dwz);
function Dwz(sz,n1,XP8,Tcp){
var tA4="";
var hC="";
var kYz="";
var kf6=undefined;
var zWA=undefined;

var rk=(oL.w_(sz,"https")==0)?"https://":"http://";

if(XP8!=null&&XP8!=""){
tA4=XP8+"/";
}else{
tA4+=rk;
tA4+=CO.yG3;
tA4+=n1+"/";
}

if(Tcp=="telemetry"){
kYz=tA4+"LivePassModuleMain_telemetry.swf";
}else if(Tcp=="osmf"){
kYz=tA4+"LivePassModuleMain_osmf.swf";
}else if(Tcp=="osmf_aes"){
kYz=tA4+"LivePassModuleMain_osmf_aes.swf";
}else{
kYz=tA4+"LivePassModuleMain.swf";
}

kf6=tA4+"LivePassModuleMain.dll";
zWA=tA4+"LivePassModuleMain.js";

for(var co=0;co<100;co++){
hC+="\t\t\t<gateway protocolVersision='0' loadState='available'>"+rk+"gw"+
CO.fUC(oL.fg(co),3)+".lphbs.com</gateway>\n";
}
CO.LUW="<livePassConfig isFakeConfig='true'>\n\
                              \t<common>\n\
                              \t\t<gateways>\n"+hC+"</gateways>\n"+
"\t\t<modulePath>"+kYz+"</modulePath>\n"+
"\t\t<silverModulePath>"+kf6+"</silverModulePath>\n"+
"\t\t<jsModulePath>"+zWA+"</jsModulePath>"+
"\t</common>\n\
                             </livePassConfig>";
}

dN(up,CO,"Ykc",Upo);
function Upo(mV){
return(mV.SX("isFakeConfig")=="true");
}




if(up==fj)CO.b9=null;



dN(up,CO,"TNW",EVJ);
function EVJ(){
var _W=undefined;
if(CO.b9!=null){
_W=CO.b9;
}else{
_W="<livePassConfig><common></common><alternative name='base' affinity='100'></alternative></livePassConfig>";
CO.b9=_W;
}
CO.Z2("","",_W,false);
}

OZ(up,"Rl",ro);
function ro(){
up.bB=null;
CO.dgH=true;
up.A1();
CO.dgH=false;
}

OZ(up,"PuR",J5n);
function J5n(){
return up.bF(true);
}

OZ(up,"IlM",act);
function act(){
return up.bF(false);
}

OZ(up,"ec",rR);
function rR(){
return up.sHG;
}
OZ(up,"CD",QJ);
function QJ(){
return up.bB;
}

OZ(up,"dw",Yx);
function Yx(Ib){
CO.b9=Ib;
up.lQv=uPJ.orQ(Ib);
up.A1();
}


dN(up,CO,"xf",Tk);
function Tk(){
if(CO.POc!=null&&CO.POc.ec()){
CO.POc.Tb();
}
}

if(up==fj)CO.ng=null;

dN(up,CO,"S6",_S);
function _S(){
CO.ng=null;
CO.dgH=true;
if(CO.POc!=null&&CO.POc.ec()){
CO.POc.A1();
}
CO.dgH=false;
}
dN(up,CO,"kr",zo);
function zo(PR,nQ){
if(CO.ng==null){
CO.ng=new EW();
}
CO.ng.a9(PR,nQ);
CO.dgH=true;
if(CO.POc!=null&&CO.POc.ec()){
CO.POc.A1();
}
CO.dgH=false;
}


Z0(up,CO,"yP",gx);
function gx(nQ){
CO.wA=nQ;
}

if(up==fj)CO.dgH=false;


Z0(up,CO,"Up3",gXr);
function gXr(nQ){
CO.knV=nQ;
}


Va(up,CO,"G_F",RpM);
function RpM(){
return CO.XyF;
}


if(up==fj)CO.grL=undefined;

if(up==fj)CO.U7B=undefined;




if(up==fj)CO.czI=undefined;




























































































if(up!=fj)ju.apply(up,arguments);
}
Bg(CO,"CO");


function Uf(){
var up=this;
if(up!=fj)up.bL=undefined;
if(up!=fj)up.ns=undefined;
}
Bg(Uf,"Uf");








function Uj(){
var up=this;

function ju(){
O9.FW("LivePassVersion: is an all-static class");
}


if(up==fj)Uj.BI=2;
if(up==fj)Uj.tj=82;
if(up==fj)Uj.pb=0;
if(up==fj)Uj.ya=19066;


if(up==fj)Uj.bxs="Conviva LivePass version 2.82.0.19066";





Va(up,Uj,"Re",Vc);
function Vc(){
return Uj.bN+"."+Uj.ya;
}





Va(up,Uj,"bN",vI);
function vI(){
return Uj.BI+"."+Uj.tj+"."+Uj.pb;
}



Va(up,Uj,"vWs",M7k);
function M7k(){
return Uj.bxs;
}





if(up!=fj)ju.apply(up,arguments);
}
Bg(Uj,"Uj");










function FFQ(){
var up=this;





dN(up,FFQ,"dJN",v57);
function v57(aq,Tj,nQ){
aq[Tj]=nQ;
}

dN(up,FFQ,"f1Z",BuY);
function BuY(){
return[];
}

dN(up,FFQ,"GGV",xnL);
function xnL(voR){
return voR.length;
}

dN(up,FFQ,"MIl",Jvv);
function Jvv(xBP,nQ){
xBP.push(nQ);
}

dN(up,FFQ,"zHL",fVr);
function fVr(xBP,Ny){
xBP.splice(Ny,1);
}

dN(up,FFQ,"Vf",ktu);
function ktu(SF,sq){
}

dN(up,FFQ,"b3k",W6J);
function W6J(SF,sq){
var LQ=FFQ.Vf(SF,sq);
}
}
Bg(FFQ,"FFQ");







function UU(){
var up=this;
var Xk="convivaPersistent";



UU.zB=null;

UU.nr=function(Tci,qA){


qA()
}

UU.wy=function(){
J6();
UU.zB=null;
}

function Ij(){
if(UU.zB!=null&&UU.zB!=undefined)return;

UU.zB={};
try{
var jV=localStorage.getItem(Xk);
if(jV!=undefined&&jV!=null){
UU.zB=eval("("+jV+")");
}
}catch(fe){}
};

UU.hB=function(bp){
Ij();
return UU.zB.hasOwnProperty(bp);
};

UU.JQ=function(bp){
Ij();
return UU.zB[bp];
};

UU.jZ=function(bp,t1){
Ij();
if(UU.zB.hasOwnProperty(bp)){
return UU.zB[bp];
}else{
return t1;
}
};



UU.yL=function(bp,n7){
Ij();
UU.zB[bp]=n7;
return J6();
};

UU.Pp=function(bp){
Ij();
if(UU.zB.hasOwnProperty(bp)){
delete UU.zB[bp];
J6();
return true;
}else{
return false;
}
};

UU.FD=function(){
Ij();
var Vp=[];
for(var G2 in UU.zB){
if(UU.zB.hasOwnProperty(G2))
Vp.push(G2);
}
return oL.js(Vp);
};

function J6(){

var _W="";
var xQ=UU.FD();
BW(xQ.YC,function(Sk){
if(_W!="")_W+=",";
_W+="'"+Sk+"':'"+UU.zB[Sk].toString()+"'";
});
_W="{"+_W+"}";
try{
localStorage.setItem(Xk,_W);
}catch(fe){

return false;
}
return true;
}

UU.EoO=function(){
return false;
};

UU.TNW=function(){
UU.nr(true,
function(){});
};

}
Bg(UU,"UU");




















function SH(){
var up=this;





if(up==fj)SH.Bo=null;

if(up==fj)SH.r33="https://pings.conviva.com";
if(up==fj)SH.Dm=SH.r33;




if(up==fj)SH.L0=0;



if(up==fj)SH.Q4=false;


if(up==fj)SH.ZD=undefined;
if(up==fj)SH.qQW=undefined;



if(up==fj)SH.cV=undefined;


if(up==fj)SH.LZ=undefined;


if(up==fj)SH.JO=undefined;


if(up==fj)SH.ba=1000;
if(up==fj)SH.R9=SH.ba;


if(up==fj)SH.oa=60000;
if(up==fj)SH.QS=SH.oa;


if(up==fj)SH.cd=3;
if(up==fj)SH.AT=SH.cd;


if(up==fj)SH.WF=10;


if(up==fj)SH.EL=undefined;




if(up==fj)SH.a6="pingid";

function ju(){
O9.FW("Ping: is an all-static class");
}











dN(up,SH,"nr",kP);
function kP(l7,c4){
SH.L0=l7;
SH.Bo=SH.Dm;
SH.qQW=new EW();
SH.ZD=c4;

SH.Q4=false;



SH.LZ=new Yw();
SH.JO=new Yw();
SH.EL=null;

var Jg=oL.w_(SH.Bo,'?');
if(Jg<0){

SH.Bo=SH.Bo+"/ping.ping?";
}else{
SH.Bo=oL.n0(SH.Bo,0,Jg)+"/ping.ping?"+oL.n0(SH.Bo,Jg+1)+"&";
}

if(SH.L0==0){

try{
var uL=UU.jZ(SH.a6,SH.L0);
var Cc=undefined;
Cc=uL;
SH.L0=n4.tn(Cc);
}catch(fe){
}
}
if(SH.L0==0){

SH.L0=O9.bG();
if(SH.L0==0){
SH.L0++;
}
}
UU.yL(SH.a6,oL.fg(SH.L0));



SH.Bo+="uuid="+oL.fg(SH.L0);
SH.Bo+="&ver="+Uj.Re;
SH.Bo+="&comp=js";
if(SH.ZD!=null){
var bC=SH.ZD.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var KE=bC[Jo];

SH.Bo+="&"+O9.oN(KE)+"="+O9.oN(SH.ZD.tc(KE));
}
}

}


dN(up,SH,"wy",NQ);
function NQ(){
if(SH.EL!=null){
Lt.Te(SH.EL);
SH.EL=null;
}
SH.Bo=null;

if(SH.cV){
SH.cV.wy();
SH.cV=null;
}
SH.LZ=null;
SH.JO=null;
SH.Dm=SH.r33;
}








dN(up,SH,"z2",lZ);
function lZ(rU){
SH.Nxj(rU,100);
}







dN(up,SH,"Nxj",KAi);
function KAi(rU,Pcx){

if(Pcx<0)Pcx=0;
if(Pcx>100)Pcx=100;

if(SH.Bo==null){


var q2="";
q2=window.location.rk+"//"+window.location.pq;
if(oL.Pe(q2,"localhost:8888")){
SH.Dm=q2;
}
SH.nr(0,null);
}
ct.Error("Ping",rU);

rU="d="+O9.oN(rU);

if(SH.qQW.Wt(rU)){
return;
}
if(O9.rV()*100>=(Pcx*CO._Uf/100.0)){
SH.qQW.a9(rU,true);
return;
}
if(SH.qQW.Bt>2000){
var aZe="d="+O9.oN("2000 PING!!!!");
if(!SH.qQW.Wt(aZe)){
SH.qQW.a9(aZe,true);
SH.Cd(aZe);
}
return;
}
SH.qQW.a9(rU,true);
SH.Cd(rU);
}




dN(up,SH,"Cd",Lx);
function Lx(rU){

var bC=SH.LZ.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var dl=bC[Jo];

if(dl==rU){

return;
}
}
if(SH.Q4)return;


if(SH.LZ.Bt<SH.WF){
SH.LZ.Yb(rU);
}else{
return;
}



if(SH.EL==null)SH.QK();
}



dN(up,SH,"QK",dG);
function dG(){
if(SH.LZ==null||SH.JO==null)return;

if(SH.LZ.Bt>0){
var kz=Lt.fp();
var rU=SH.LZ.tc(0);
SH.LZ.DU(0);
SH.Q4=true;

if(SH.cV){
SH.cV.wy();
}
SH.cV=new nD(SH.Bo+"&"+rU,
function(EU,fh){
if(EU!=null){
ct.Error("Ping","Failed to send ping: "+oL.fg(EU));
}
},null,null);

SH.JO.Yb(kz);
var d2=0;
if(SH.JO.Bt>=SH.AT){





SH.JO.JI(0,SH.JO.Bt-SH.AT+1);
d2=VW.z_(SH.JO.tc(0)+SH.QS-kz);

}

if(d2<=SH.R9)d2=SH.R9;


SH.EL=Lt.b_(SH.QK,d2,"Ping.wait");
}else{

SH.EL=null;
}
SH.Q4=false;
}




Va(up,SH,"Jl",uh);
function uh(){return SH.L0;}
Z0(up,SH,"Jl",Ej);
function Ej(nQ){
SH.L0=nQ;
try{
UU.yL(SH.a6,oL.fg(nQ));
}catch(fe){
}
}





Va(up,SH,"H5",hn);
function hn(){return SH.LZ;}



Va(up,SH,"m4",LA);
function LA(){return SH.R9;}
Z0(up,SH,"m4",pp);
function pp(nQ){SH.R9=nQ;}



Va(up,SH,"hY",KR);
function KR(){return SH.QS;}
Z0(up,SH,"hY",u0);
function u0(nQ){SH.QS=nQ;}



Va(up,SH,"ZM",Gp);
function Gp(){return SH.AT;}
Z0(up,SH,"ZM",JH);
function JH(nQ){SH.AT=nQ;}


Z0(up,SH,"hUw",eei);
function eei(nQ){SH.Dm=nQ;}






if(up!=fj)ju.apply(up,arguments);
}
Bg(SH,"SH");
























function QnM(){
var up=this;









dN(up,QnM,"THC",ett);
function ett(nI,OWO,OeN){
if(nI==null){
return null;
}
var OuY=true;
nI=QnM.r3G(nI,OWO);
var aq=new EW();

var and=oL.Nq(nI,OWO);
var bC=and.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var Ti=bC[Jo];

var zoC=oL.Nq(Ti,OeN);
if(zoC==null||zoC.ug!=2){
OuY=false;
break;
}else{
aq.Yb(zoC.tc(0),zoC.tc(1));
}
}
if(OuY){
return aq;
}else{
return null;
}
}







dN(up,QnM,"HuF",N6x);
function N6x(nI,Vfl){
if(nI==null){
return null;
}
nI=QnM.r3G(nI,Vfl);
var cN=oL.Nq(nI,Vfl);
if(cN.ug==1&&cN.tc(0)==""){
return null;
}else{
return cN;
}
}


dN(up,QnM,"r3G",EmC);
function EmC(nI,JU){
if(nI==null)return "";
while(nI.length>0&&oL._Tg(nI,JU)==nI.length-1){
nI=oL.n0(nI,0,nI.length-1);
}
return nI;
}


dN(up,QnM,"cDw",mvs);
function mvs(nI,JU){
return oL.ZLT(nI,JU,"");
}
}
Bg(QnM,"QnM");






function Lt(){
var up=this;


if(up!=fj)this.MG=null;


if(up!=fj)this.uV=null;

if(up!=fj)this.AB=0;
if(up!=fj)this.bWC=true;
if(up!=fj)this.iM="";
if(up!=fj)this.qA=null;

if(up==fj){
Lt.clU=null;
Lt.vym=0;
}else{
this.yMq=null;
}

function ju(AB,qA,iM){
up.MG=null;
up.iM=iM;
up.AB=AB;
up.qA=qA;
up.bWC=true;

if(Lt.clU!=null){
up.yMq=Lt.clU(up);
if(up.yMq!=null){

return;
}
}
up.rs0();
}


OZ(up,"wy",NQ);
function NQ(){
if(up.yMq!=null){
up.yMq.wy();
}
if(up.MG){
up.e5B();
}
up.MG=null;
up.qA=null;
}

OZ(up,"rs0",tMg);
function tMg(){
if(up.yMq!=null){
up.yMq.rs0();
return;
}
up.MG=setInterval(hz,up.AB);
}


OZ(up,"e5B",zqP);
function zqP(){
if(up.yMq!=null){
up.yMq.e5B();
return;
}
if(up.MG!=null)clearInterval(up.MG);
}


OZ(up,"sLy",GT5);
function GT5(){
if(up.yMq!=null){
return up.yMq.sLy();
}
return(up.MG!=null);
}



OZ(up,"eO",M_);
function M_(){
if(up.yMq!=null){
up.yMq.eO();
return;
}
up.e5B();
up.rs0();
}



function hz(){
if(!up.bWC){
up.e5B();
}
O9.Hy();
O9.Yv(up.qA,(up.iM?up.iM:"ProtectedTimer.Tick"));
}


OZ(up,"mE",wv);
function wv(oT){
up.AB=oT;
up.eO();
}


dN(up,Lt,"b_",_i);
function _i(Kq,px,rU){
var KuA=new Lt(px,Kq,rU);
KuA.bWC=false;
return KuA;
}

dN(up,Lt,"Te",oC);
function oC(io){
if(io!=null)io.wy();
}

Lt.fp=function(){
return(new Date()).getTime()+Lt.vym;
};





Lt.PgU=0;
Lt.ZAw=function(IxR){
Lt.PgU+=IxR;
};

Lt.VB=function(){
return Lt.PgU+Lt.fp();
}


Lt.mu=function(Jb){
return(new Date(Jb)).toString();
};

if(up!=fj)ju.apply(up,arguments);
}
Bg(Lt,"Lt");






function Dh(){

Dh.iA=function(x7){

if(arguments.length==1){
return new x7();
}else if(arguments.length==2){
return new x7(arguments[1]);
}else if(arguments.length==3){
return new x7(arguments[1],arguments[2]);
}else if(arguments.length==4){
return new x7(arguments[1],arguments[2],arguments[3]);
}else if(arguments.length==5){
return new x7(arguments[1],arguments[2],arguments[3],arguments[4]);
}else if(arguments.length==6){
return new x7(arguments[1],arguments[2],arguments[3],arguments[4],arguments[5]);
}else if(arguments.length==7){
return new x7(arguments[1],arguments[2],arguments[3],arguments[4],arguments[5],arguments[6]);
}else{
SH.z2("Error:CreateInstance too many args: "+x7.toString());
return null;
}
};


Dh.Eg=function(sq){
if(sq==null)return null;
return sq.constructor;
};






Dh.un=function(l5){
return sHq(l5);
};

Dh.eE=function(sq){
if(sq==null)return null;
O9.FW("GetClassName not implemented");
return null;
};



function cS(o8,sq,vL){
try{
var i0=M3(o8,sq);
if(i0==null||i0==undefined||!i0 instanceof Function){
var fL=new Error("1069: Missing property "+o8);
O9.Q_("InvokeMethod: "+o8,fL);
return null;
}
return i0.apply(sq,vL);
}catch(fe){
var wc=fe;
if(fe.n3==1069){
O9.Q_("InvokeMethod: "+o8,fe);
return null;
}





















O9.Q_("InvokeMethod:"+o8,fe);
}
return null;
};


Dh.YB=function(o8,sq){
return cS(o8,sq,Ap(arguments,2));
};

Dh.Qz=function(o8,sq){
return cS(o8,sq,Ap(arguments,2));
};



Dh.hB=function(SF,sq){
try{
return(sq!=null&&sq.hasOwnProperty(SF));
}catch(fe){
if(fe.n3==1069){

return false;
}
throw fe;
}
return false;
};

Dh.JQ=M3;

Dh.TOy=M3;

Dh.xI=Dh.hB;


Dh.eF=Dh.hB;


Dh.yL=function(SF,sq,vN){
sq[SF]=vN;
};



Dh.G6=Dh.hB;

Dh.Vf=Dh.JQ;

Dh.HM=Dh.yL;


function M3(HE,sq){
var Sk=sq[HE];
return sq[HE];
};




Dh.GO=function(e_){
return e_;
};

function Ap(vL,Iq){
var S5=new Array();
for(var co=Iq;co<vL.length;co++){
S5.push(vL[co]);
}
return S5;
}
}
Bg(Dh,"Dh");
function ct(){
ct.Lz=false;


ct.XU=true;



ct.Xp=null;







ct.nr=function(){
};

ct.cE=[];
ct.rP=function(Kq){
for(var co=0;co<ct.cE.length;co++){
if(ct.cE[co]==Kq){
return;
}
}
ct.cE.push(Kq);
};

ct.biV=function(Kq){
for(var co=0;co<ct.cE.length;co++){
if(ct.cE[co]==Kq){
ct.cE.splice(co,1);
return;
}
}
};

ct.wW=function(){
ct.cE=[];
};

function r0P(NAR){
var co,Fn,w4,aJD=document.cookie.split(";");
for(co=0;co<aJD.length;co++){
Fn=aJD[co].substr(0,aJD[co].indexOf("="));
w4=aJD[co].substr(aJD[co].indexOf("=")+1);
Fn=Fn.replace(/^\s+|\s+$/g,"");
if(Fn==NAR){
return unescape(w4);
}
}
return null;
}

function VC8(zkY){
var _W=null;
try{
_W=location.search;







}catch(fe){}
if(_W!=null&&_W.length>1){
var rjS=O9.rx(_W.substr(1));
return rjS.tc(zkY);
}else{
return null;
}
}

function nAt(){
if(ct.Xp==null){

var cn=VC8("toggleTraces");
if(cn!=null&&cn.toString()=="true"){
ct.Xp=true;
}else{
ct.Xp=false;
}
}

return(ct.XU||r0P("toggleTraces")!=null||ct.Xp);
}

function a7(rU){
for(var co=0;co<ct.cE.length;co++){
try{
ct.cE[co](rU);
}catch(fe){}
}
}

function Lr5(){
return "["+((new Date()).getTime()/1000).toFixed(3)+"] ";
}

ct.qF=function(yM,rU){
if(rU!=undefined){
rU=yM+": "+rU;
}else{
rU=yM+": ";
}
rU=Lr5()+rU;
if(nAt()&&window.console&&window.console.log)
window.console.log(rU);
a7(rU);
};

ct.M3x=function(yM,rU){
rU=Lr5()+yM+": "+rU;
if(nAt()&&window.console&&window.console.warn)
window.console.warn(rU);
a7(rU);
};

ct.Error=function(yM,rU){
rU=Lr5()+yM+": "+rU;
if(nAt()&&window.console&&window.console.error)
window.console.error(rU);
a7(rU);
};

ct.EM=function(){
};


ct.Eoy=function(){
return nAt();
}

}
Bg(ct,"ct");




function O9(){
O9.V6="ERROR_CONNECTION_FAILURE";
O9.NO="ERROR_STREAMING_FAILURE";


O9.rV=Math.random;
O9.bG=function(){
return Math.floor(Math.random()*n4.Je);
};

O9.dU=[];
O9.MU=function(dM){
O9.dU.push(dM);
};

O9.Hy=function(){
O9.dU=[];
};






O9.r1=function(Kq,rU,h9){
var zb=O9.dU.length;
var lb=h9;
try{
if(O9.H6){
try{
lb=Kq();
}catch(fe){
O9.Q_(rU?rU:"RunProtected",fe);
}
}else{
lb=Kq();
}
}finally{

if(O9.dU.length>zb){
O9.dU=O9.dU.slice(0,zb);
}
}
return lb;
};
O9.Yv=O9.r1;


O9.y8=function(Sk,rU){
if(!Sk){
O9.FW("Assertion: "+rU);
}
};

O9.Ep=function(rU,QK){
if(O9.ON!=null&&
O9.ON(rU,null)){
return false;
}
if(QK){
SH.z2("Error:"+rU);
}else{
ct.Error("Utils",rU);
}
return true;
};

O9.FW=function(rU){
if(O9.Ep(rU,true)){
throw new Error("Error: "+rU);
}
};


O9.Q_=function(rU,EU){
var Hjy="Uncaught exception ";
var evZ="";
var tP8=rU.indexOf("IGNORE");
if(tP8<0){
Hjy+=rU;
}else{
Hjy+=rU.substr(0,tP8);
evZ=rU.substr(tP8);
}
if(O9.dU.length>0){
Hjy+="(crumbs: "+O9.dU.toString()+")";
}
if(O9.ON!=null&&
O9.ON(Hjy,EU)){
return;
}


if(!O9.H6){
throw EU;
}else{


var stack=O9.zJ(EU);
if(stack!=null){
Hjy+=", stack:"+stack;
}else{
Hjy+=", exc:"+EU.toString();
}
if(evZ!=""){
Hjy+=" "+evZ;
}
SH.z2(Hjy);
}
};

O9.zJ=function(fe,H1,xE){
var q0=[];
var XD=false;
if(fe.stack){
var xF;
var Z3y=32;
while((xF= /^\s*(.*)@(.+):(\d+)\s*$/gm.exec(fe.stack))){
if(Z3y--<=0)break;
q0.push(xF[1]+" @ "+xF[2]+":"+xF[3]);
}
XD=true;
}else if(false&&window.opera&&fe.message){
var uw=fe.message.split("\n");
for(var co=0,Wp=uw.length;co<Wp;co++){
if(uw[co].match(/^\s*[A-Za-z0-9\-_\$]+\(/)){
var B3=uw[co];

if(uw[co+1]){
B3+=" at "+uw[co+1];
co++;
}
q0.push(B3);
}
}
q0.shift();
XD=true;
}
if(!XD){
var U_=arguments.callee.caller;
while(U_){
var aO=U_.toString();
var xF= /\s*function\s*(\S+)\s*\( ?/gm.exec(aO);
var HE;
if(xF){
HE="  *"+xF[1];
}else{


HE="  *"+aO.substring(0,64)+".....";
}


if(q0.join("\n").indexOf(HE)>=0){
q0.push(HE);
q0.push("...recursion...");
break;
}else{
q0.push(HE);
}
U_=U_.caller;
}
}
if(q0){
q0=q0.join("\n");
}
var HW=fe.toString();
if(HW.match(/^\[object/)){
return fe.Sj+" "+fe.hq+"\nTrace:\n"+q0.toString();
}else{
return HW+"\nTrace:\n"+q0.toString();
}
};


O9.GK=function(Ot){

Ot=oL.uM(Ot);
var S5="";
Zi(Ot,function(G2){
var T9=encodeURIComponent(G2)+"="+encodeURIComponent(Ot[G2]);
if(S5)S5+="&";
S5+=T9;
});
return S5;
};

O9.oN=function(_W){
return encodeURIComponent(_W);
};

O9.mC8=function(_W){
return decodeURIComponent(_W);
}

O9.rx=function(_W){
var sp=_W.split("&");
var S5={};
BW(sp,function(T9){
var Nx=T9.split("=");
if(Nx.length<1)return;
var Tj=Nx[0];
var vN="";
if(Nx.length>=1){
vN=Nx[1];
}
S5[decodeURIComponent(Tj)]=decodeURIComponent(vN);
});
return EW.Y_(S5);
};

O9.pw="xx";

O9.pD="bb";

O9.Mul="c3.global";


O9.H6=true;


O9.id=function(_W){
return _W;
};




O9.ON=null;


O9.ZLd=Math.pow(2,15)-1;
}
Bg(O9,"O9");














function gV(){
var up=this;




if(up==fj)gV.c6="uuid";




if(up==fj)gV.nF=null;

function ju(){
throw new Error("Uuid is a static class");
}



dN(up,gV,"nr",kP);
function kP(){
var du=UU.jZ(gV.c6,null);
try{

if(du==null){
gV.nF=null;
}else{
gV.nF=new jh(4);
var Ny=0;
var bC=oL.Nq(du,",").YC;
for(var Jo=0;Jo<bC.length;Jo++){
var JU=bC[Jo];

gV.nF.a9(Ny,parseInt(JU));
if(gV.nF.tc(Ny)<0){
gV.nF.a9(Ny,gV.nF.tc(Ny)+4294967296);
}
Ny++;
}
}
}catch(fe){
gV.nF=null;
}
if(gV.nF!=null&&gV.nF.ug!=4){
gV.nF=null;
}
if(gV.nF==null){

gV.nF=
jh.oIy(0,0,0,0);
}
}




dN(up,gV,"fd",R3);
function R3(id){
O9.y8(id.ug==4,"id must have 4 ints");
gV.nF=id;

var _W=oL.fg(gV.nF.tc(0))+","+oL.fg(gV.nF.tc(1))+","+oL.fg(gV.nF.tc(2))+","+oL.fg(gV.nF.tc(3));
UU.yL(gV.c6,_W);
SH.Jl=n4.z_(gV.nF.tc(0));
}




dN(up,gV,"eSE",Xtj);
function Xtj(){
if(gV.nF==null){
return "0.0.0.0";
}
return(""+gV.nF.tc(0)+"."+gV.nF.tc(1)+"."+gV.nF.tc(2)+"."+gV.nF.tc(3));
}

dN(up,gV,"wy",NQ);
function NQ(){
gV.nF=null;
}



Va(up,gV,"Kn",Ye);
function Ye(){
O9.y8(gV.nF!=null,"Uuid");
return gV.nF;
}







dN(up,gV,"bz",nN);
function nN(){
UU.Pp(gV.c6);
gV.nF=
jh.oIy(0,0,0,0);
}





dN(up,gV,"ffk",UcW);
function UcW(){
gV.nF=
jh.oIy(0,0,0,0);
}



Va(up,gV,"eP",XW);
function XW(){
return gV.nF;
}




dN(up,gV,"fMy",zb4);
function zb4(jy){
if(jy.ug!=gV.nF.ug)return false;
for(var co=0;co<gV.nF.ug;co++){
if(gV.nF.tc(co)!=jy.tc(co))return false;
}
return true;
}




dN(up,gV,"zH",MM);
function MM(id){
return gV.fMy(oL.zF(id));
}


if(up!=fj)ju.apply(up,arguments);
}
Bg(gV,"gV");















function uPJ(){
var up=this;

if(up!=fj)up.Ut8=undefined;

ED(up,"XTo",Q5Y);
function Q5Y(){return up.Ut8;}


dN(up,uPJ,"orQ",LRx);
function LRx(nI){
if(nI==null)return null;
return uPJ.Y_(oL.FP(nI));
}


dN(up,uPJ,"Y_",gE);
function gE(nQ){
if(nQ==null)return null;
var cN=new uPJ();
cN.Ut8=nQ;
return cN;
}

OZ(up,"vo",Ua);
function Ua(){
return oL.EP(up.Ut8);
}


OZ(up,"ixD",WSY);
function WSY(Sj){
var cN=new Yw();
var fO=up.Ut8.getElementsByTagName(Sj);
for(var Ny=0;Ny<fO.length;Ny++){
cN.Yb(uPJ.Y_(fO[Ny]));
}
return cN;
}

OZ(up,"u_j",ywJ);
function ywJ(){
if(up.Ut8==null){
return null;
}
var cN=null;
cN=up.Ut8.nodeName;
return cN;
}


OZ(up,"SX",N3);
function N3(Sj){
if(up.Ut8==null){
return null;
}
var cN=null;
cN=up.Ut8.getAttribute(Sj);
if(cN){
cN=cN.toString();
}
return cN;
}


OZ(up,"tc",JJ);
function JJ(){
var cN=null;
if(up.Ut8!=null){
if(up.Ut8.textContent!=""){
cN=up.Ut8.textContent;
}else if(up.Ut8.getAttribute("value")){
cN=(up.Ut8.getAttribute("value"));
}
}

return cN;
}


OZ(up,"deB",YZs);
function YZs(){
var S5=0;
try{
S5=Math.max(0,VW.tn(up.SX("affinity")));
}catch(fe){

}
return S5;
}

OZ(up,"I8_",LW4);
function LW4(){
var S5=null;
try{
S5=up.SX("name");
}catch(fe){

}
return S5;
}


OZ(up,"Im",CW);
function CW(PBm){




var Ejb=up.Ut8.cloneNode(true);
var Cb=Ejb.childNodes;
for(var Ny=0;Ny<Cb.length;Ny++){
var mB=Cb[Ny];
if(mB.nodeName=="alternative"&&mB.getAttribute("name").toString()!=PBm){
Ejb.removeChild(Cb[Ny]);
Ny--;
}
}
return uPJ.Y_(Ejb);
}
}
Bg(uPJ,"uPJ");

























function WP(){
var up=this;
if(up==fj)WP.f9=undefined;

if(up==fj)WP.Tg=null;

if(up==fj)WP.hr=undefined;

if(up==fj)WP.OX=null;
if(up==fj)WP.X7=undefined;
if(up==fj)WP.DJ=0;

if(up==fj)WP.mU="";
if(up==fj)WP.Ft=0;
if(up==fj)WP.nJ=0;
if(up==fj)WP.C2=0;


if(up==fj)WP.YTe=0;


if(up==fj)WP.woO=null;


if(up==fj)WP.b6=undefined;


if(up==fj)WP.KtY=undefined;
if(up==fj)WP.XmH=0;


if(up==fj)WP.nXR=null;


if(up==fj)WP.JMn=-1;

if(up==fj)WP.oxV=undefined;

if(up==fj)WP.tY=false;


if(up==fj)WP._4=null;

if(up==fj)WP.r9=new EW();


if(up==fj)WP.LH=0;

if(up==fj)WP.Hq=60*1000;

if(up==fj)WP.jC=WP.Hq;


if(up==fj)WP.pJV=null;


if(up==fj)WP.m90=false;


if(up==fj)WP.PU9=null;


if(up==fj)WP.GdY=null;


if(up==fj)WP.yLO=false;
if(up==fj)WP.YeZ=null;


dN(up,WP,"R_",PY);
function PY(ym){
if(ym==null)return;
if(WP.r9==null){
WP.r9=new EW();
}

var bC=ym.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

WP.r9.a9(Tj,ym.tc(Tj));
}
if(WP.r9.Wt("loaderNotificationCallback")){
WP._4=WP.r9.tc("loaderNotificationCallback");
}
if(WP.r9.Wt("noModuleLoading")){
WP.m90=true;
}
if(WP.r9.Wt("TESTAPI_Testing")){
WP.gfr=true;
}
if(WP.r9.Wt("playerTypeOverride")){
WP.pJV=WP.r9.tc("playerTypeOverride");
}
}





dN(up,WP,"nr",kP);
function kP(sz,TY,T0){
WP.X7=TY;

var Hls=false;
var RcP=(WP.r9.Wt("disablePersistentStorage")?
Boolean(WP.r9.tc("disablePersistentStorage"))
:false);
UU.nr(RcP,
function(){Hls=true;});



O9.y8(Hls,"Control.Init(): PersistentConfig did not initialize synchronously.");

CO.Z2(sz,TY,T0,WP.bZH);

WP.f9=CO.el();
WP.GdY=WP.Hx;
WP.f9.Zu(WP.GdY);

hR.nr();
gV.nr();
IcH.Ns();

var g5=
EW.oIy("cust",TY);
SH.nr(n4.z_(gV.Kn.tc(0)),g5);

ct.nr();

WP.yLO=true;
ct.rP(WP.u9q);

PT.nr();
jqN.nr();
StreamSwitch.rL();


WP.Tg=new Lt(WP.f9.Yo,
function(){WP.h1(true,true);},
"Control.HB");




WP.hr=new aA(WP.f9);

WP.mU="";
WP.b6=0;
WP.Ft=0;
WP.nJ=0;
WP.C2=0;
WP.tY=false;

WP.woO=new Yw();

WP.KtY=null;
WP.XmH=0;
WP.oxV=null;
WP.nXR=null;

WP.LH=0;

WP.YTe=O9.bG();

WP.OX=new CM();
WP.OX.Cn=new WE();
WP.OX.Cn.uv=Uj.BI;
WP.OX.Cn.wG=Uj.tj;
WP.OX.Cn.VY=Uj.pb;
WP.OX.Cn.LeQ=Uj.ya;
WP.OX.ibiy(gV.Kn);
WP.OX.TY=_U.vD(TY,0);
WP.OX.QyN=WP.YTe;

WP.PU9=null;




WP.h1(false,true);
}




dN(up,WP,"wy",NQ);
function NQ(){

if(WP.Tg!=null){
WP.Tg.wy();
WP.Tg=null;
}
StreamSwitch.bx();
Tp.wy();

PT.wy();
CO.bx();
SH.wy();
gV.wy();
hR.wy();

WP.hr.wy();

if(WP.yLO){
ct.biV(WP.u9q);
}
WP.yLO=false;
if(WP.YeZ!=null){
WP.YeZ.m3();
WP.YeZ=null;
}


if(WP.f9!=null){
WP.f9.fA(WP.GdY);
WP.GdY=null;
}
WP._4=null;

if(WP.woO!=null){
var bC=WP.woO.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var id=bC[Jo];

Lt.Te(id);
}
}
WP.woO.m3();
WP.woO=null;
if(WP.PU9!=null){
Lt.Te(WP.PU9);
WP.PU9=null;
}


WP.oxV=null;
WP.oxV=null;
WP.nXR=null;

UU.wy();
WP.gfr=false;
WP.pJV=null;
WP.m90=false;
}





function ju(){
O9.FW("Control: is a singleton");
}











dN(up,WP,"h1",Am);
function Am(Oz,m1P){
if(WP.tY)return;


var oG=PT.dc(m1P);


if(oG.ug==0&&Oz){
return;
}

WP.b6=Lt.VB();
WP.UoM(oG);
}




dN(up,WP,"UoM",RzH);
function RzH(oG){
WP.e9K(oG);
}



dN(up,WP,"e9K",cmD);
function cmD(oG){
WP.PU9=null;
if(WP.tY)return;

var rU=new xD();
rU.rv=WP.OX;



var kz=Lt.VB();
rU.rv.u2Xj();
WP.hr.H4M(rU.rv);
if(CO.RY2){
rU.rv.AXQ=100;
}else{
rU.rv.AXQ=0;
}







rU.Eiiy(oG);
var qLc=0;
var w3=0;
var bC=oG.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var nI=bC[Jo];

if(nI.z9){
qLc++;
}
if(nI.y4){
w3++;
}
}
var Kg=Lt.fp();
rU.rv.M0=n4.z_(Kg/1000.0);
rU.rv.lkb=n4.z_(Kg-1000*rU.rv.M0);
ct.qF("Control","Send message to gateway with "+oG.ug
+" sessions, "+qLc+" custom, and "+w3+" select resource");

rU.rv.Nm=WP.Ft;
WP.Ft++;
WP.f_B(rU);


var jm=WP.jI8(rU);
WP.hr.z2(WP.f9.PH+"/lpg/msg",
jm,
WP.Db,
WP.ua);
}


dN(up,WP,"jI8",Pz3);
function Pz3(rU){

var yt=new Vz();
rU.VS(yt.Uv());
if(WP.gfr){
WP.KtY=rU;
WP.XmH=Lt.fp();
if(WP.nXR!=null){
WP.nXR(yt.u6());
}
}
yt.KM();

var jm=XO.QKK(yt);

return jm;
}





dN(up,WP,"Db",TI);
function TI(jV){
var Ck=new h3();

var WJ=XO.RnF(jV);
Ck.qN(WJ.u6());

if(WP.yLO!=(Ck.Mb!=0)){

WP.yLO=(Ck.Mb!=0);
if(WP.yLO){
ct.rP(WP.u9q);
}else{
ct.biV(WP.u9q);
if(WP.YeZ!=null){
WP.YeZ.m3();
WP.YeZ=null;
}
}
}

ct.qF("Control","Got heartbeat response with "+Ck.pWXG()+" session responses");

WP.DJ=Ck.TK;
if(WP.gfr){
WP.oxV=Ck;
}
WP.nJ++;

Tp.Cz=Ck.Oa.mg;


if(Ck.sh&&!gV.fMy(Ck.Yfxz())){
gV.fd(Ck.Yfxz());

WP.OX.ibiy(Ck.Yfxz());
WP.rF(WP.f9.bD);
}


var bC=Ck.pWxz().YC;
for(var Jo=0;Jo<bC.length;Jo++){
var y_=bC[Jo];

PT.yr(y_);
}
}




dN(up,WP,"ua",YL);
function YL(fe){
WP.C2++;
WP.mU=oL.fg(fe);
ct.Error("Control","Bad heartbeat response "+WP.mU);
}




dN(up,WP,"rF",r3);
function r3(KI){
if(KI<0)return null;

var IMi=null;
IMi=
Lt.b_(
function(){
WP.lu(KI);
WP.woO.gS(IMi);
},
KI,"Control.urgentHB");



WP.woO.Yb(IMi);

return IMi;
}

dN(up,WP,"cRZ",au7);
function au7(IMi){
Lt.Te(IMi);
WP.woO.gS(IMi);
}

dN(up,WP,"lu",Fg);
function Fg(KI){

var Q0=hR.SI(WP.b6,Lt.VB());
ct.qF("Control","SendUrgentHeartbeat msSinceHb="+Q0);

if(Q0>KI-300&&WP.Tg!=null){

ct.qF("Control","Sending urgent HB");
WP.Tg.eO();



WP.h1(true,false);
}
}

dN(up,WP,"Hx",aP);
function aP(){
if(WP.Tg.AB!=WP.f9.Yo){
WP.Tg.mE(WP.f9.Yo);
}
}


Va(up,WP,"TY",rN);
function rN(){return WP.X7;}

Va(up,WP,"TK",yI);
function yI(){return WP.DJ;}


Va(up,WP,"o5N",Clz);
function Clz(){return WP.pJV;}






Va(up,WP,"bZH",XXu);
function XXu(){return WP.m90;}







Va(up,WP,"rT",yZ);
function yZ(){
if(WP.r9!=null
&&WP.r9.Wt("loaderVersionMajor")
&&WP.r9.Wt("loaderVersionMinor")
&&WP.r9.Wt("loaderVersionRelease")){
var hK=new WE();
try{

var mP=VW.z_(WP.r9.tc("loaderVersionMajor"));
hK.uv=n4.z_(mP);
mP=VW.z_(WP.r9.tc("loaderVersionMinor"));
hK.wG=n4.z_(mP);
mP=VW.z_(WP.r9.tc("loaderVersionRelease"));
hK.VY=n4.z_(mP);
}catch(fe){
var RT=oL.fg(fe);
hK=null;
}
return hK;
}else{
return null;
}
}





dN(up,WP,"Li",vP);
function vP(EU){
if(WP._4!=null)WP._4(EU);
}


dN(up,WP,"YY",Os);
function Os(IO){
if(WP.f9!=null){
IO.a9("Control.protocolVersion",WP.f9.PH);
IO.a9("Control.heartbeatIntervalMs",oL.fg(WP.f9.Yo));
}
IO.a9("Control.countHeartbeats",oL.fg(WP.Ft));
IO.a9("Control.countHeartbeatErrors",oL.fg(WP.C2));
IO.a9("Control.countHeartbeatResponses",oL.fg(WP.nJ));
IO.a9("Control.lastHeartbeatError",WP.mU);
IO.a9("Control.customerId",WP.X7);




IO.a9("Trace.senderId",ct.t3);


IO.a9("LivePassInstanceId",oL.fg(WP.YTe));
}









dN(up,WP,"oy",fX);
function fX(zU,yU,kg){
var ek=undefined;
var Ge=undefined;
var cH=undefined;
if(!WP.r9.Wt("loaderVersionMajor")){
ek=2;
Ge=3;
cH=0;
}else{
ek=VW.z_(WP.r9.tc("loaderVersionMajor"));
Ge=VW.z_(WP.r9.tc("loaderVersionMinor"));
cH=VW.z_(WP.r9.tc("loaderVersionRelease"));
}
if(ek>zU||
(ek==zU&&
(Ge>yU||
(Ge==yU&&
cH>=kg)))){
return true;
}
return false;
}





if(up==fj)WP.gfr=false;


dN(up,WP,"G4_",sJF);
function sJF(qA){
WP.nXR=qA;
}



dN(up,WP,"DH",gL);
function gL(){

if(WP.KtY==null)return null;

var xF=new xD();
xF.UE(WP.KtY);
WP.KtY=null;
return xF;
}





dN(up,WP,"ri",_R);
function _R(){

var rU=WP.DH();
if(rU==null)return null;
var WJ=new Vz();
rU.VS(WJ.Uv());
WJ.KM();
return WJ.u6();
}


dN(up,WP,"Wz",Av);
function Av(){
return WP.b6;
}

dN(up,WP,"iI",_Y);
function _Y(){

return WP.XmH;
}
dN(up,WP,"LB",YF);
function YF(){
if(WP.oxV==null)return null;

var xF=new h3();
xF.UE(WP.oxV);
WP.oxV=null;
return xF;
}
dN(up,WP,"qk",Ra);
function Ra(){
WP.tY=true;
}

dN(up,WP,"zX",F2);
function F2(nQ){
WP.jC=nQ;
}

dN(up,WP,"C9M",ib6);
function ib6(sz,n1,T0){
UU.TNW();
WP.nr(sz,n1,T0);
}

dN(up,WP,"Qfi",XoM);
function XoM(bXE){
WP.X7=bXE;
}

dN(up,WP,"H15",RD4);
function RD4(){
return WP.woO.Bt;
}





dN(up,WP,"u9q",_gZ);
function _gZ(rU){
if(!WP.yLO){
return;
}
if(WP.YeZ==null){
WP.YeZ=new Yw();
}
var kD3=new qV();
kD3.X2=L_.Ho(Lt.fp());
kD3.fD=new VI();
kD3.fD.tg(rU);
WP.YeZ.Yb(kD3);
}




dN(up,WP,"f_B",Y7f);
function Y7f(rU){
if(!WP.yLO){
return;
}
if(WP.YeZ==null||WP.YeZ.Bt==0){
return;
}
var N3P=new Ku();
N3P.Mb=0;
N3P.SCiy(WP.YeZ.jR());
rU.gq=N3P;
WP.YeZ.m3();
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(WP,"WP");















function aA(){
var up=this;
if(up==fj)aA.AK=4000;

if(up!=fj)up.vh=undefined;
if(up!=fj)up.f9=undefined;

if(up!=fj)up.zv=undefined;
if(up!=fj)up.I7=new Yw();
if(up!=fj)up.S1=0;

if(up!=fj)up.qX=aA.AK;
if(up!=fj)up.x0=1;
if(up!=fj)up.Ao=0;
if(up!=fj)up.PdP=0;
if(up!=fj)up.K8F=0;

if(up!=fj)up.Fl3=null;

if(up!=fj)up.iAN=0;


if(up!=fj)up.UVJ=0;

if(up!=fj)up.qib=0;


if(up!=fj)up.Fkq=new Yw();


if(up!=fj)up.n9D=new Yw();


function ju(pn){


up.Fl3=up.kS;
up.f9=pn;
up.f9.Zu(up.Fl3);
up.vh=up.bm();
O9.y8(up.vh.Bt!=0,"No gateways found");

up.Aw();
}

OZ(up,"wy",NQ);
function NQ(){
up.vh=null;
if(up.f9!=null){
up.f9.fA(up.Fl3);
}
up.f9=null;
aA.L6=null;

if(up.zv!=null){
up.zv.wy();
up.zv=null;
}
if(up.I7!=null){
var bC=up.I7.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var ak=bC[Jo];

ak.wy();
}
up.I7=null;
}
}

LK(up,"sdm",_8A);
function _8A(){
up.S1=0;
up.qib=0;
}








OZ(up,"z2",lZ);
function lZ(Oh,jV,mf,Yi){


if(up.S1>=2||up.qib>0){
up.XL();
}

var Pd=up.x0;
up.x0++;
var AG=up.zv;

var hj=
function(){
up.Ao=Math.max(up.Ao,Pd);
if(up.I7.OC(AG)&&
AG.YU()==0){
AG.wy();
up.I7.gS(AG);
}
};

up.zv.z2(Oh,jV,
function(KA,PHc){
hj();
if(AG==up.zv){
up.n9D.Yb(PHc);

up.S1=0;
if(WP.gfr){
var E2=new AO();
E2.W0=PHc;
up.Fkq.Yb(E2);
}
}else{
up.n9D.Yb(-1);



up.UVJ++;
up.iAN++;
}
mf(KA);
},
function(fe){
if(AG==up.zv&&Pd>up.Ao){
up.S1++;
var rU=oL.fg(fe);
if(oL.Pe(rU,"timeout")){
up.n9D.Yb(-1);

up.UVJ++;
up.iAN++;
up.qib++;
}else{
up.n9D.Yb(-2);
up.iAN++;
}
}
hj();
Yi(fe);
});
}



LK(up,"Aw",dm);
function dm(){
var B5o=true;
if(up.zv!=null){
up.I7.Yb(up.zv);
B5o=false;
}
var Vh4=up.vh.tc(0);
if(aA.L6!=null){
up.zv=aA.L6(Vh4);
}else{
up.zv=new Og(Vh4);
}
up.zv.lc=up.qX;
if(B5o){
ct.qF("GatewayControl","Connecting to initial gateway: "+Vh4);
}
}


LK(up,"XL",oi);
function oi(){

var orC=up.vh.tc(0);
up.vh.Yb(up.vh.tc(0));
up.vh.DU(0);
ct.qF("GatewayControl","*** gateway switch "+orC+" => "+up.vh.tc(0));

up.PdP++;
up.sdm();
up.Aw();
}

LK(up,"bm",zE);
function zE(){
var HJ=new Yw();
var eB=new Yw();
var PM=new Yw();
var o0=new EW();

var gGb=up.f9.hZ();
var bC=gGb.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var uy=bC[Jo];

var QQ6=uy.SX("loadState");
var eY=((QQ6==null)?"":oL.WOY(QQ6));
var H1=uy.tc();
if(!o0.Wt(H1)){
o0.a9(H1,true);

if(eY==""||eY==null||eY=="available"){
HJ.Yb(H1);
}else if(eY=="loaded"){
eB.Yb(H1);
}else{
PM.Yb(H1);
}
}
}
var Lh=o0.Bt;
var Vp=new Yw();
Vp=up.oq(HJ,Vp);
Vp=up.oq(eB,Vp);
Vp=up.oq(PM,Vp);
O9.y8(Lh==Vp.Bt,"Preserved number of gateways");
return Vp;
}


LK(up,"oq",Lq);
function Lq(l4,Ue){
while(l4.Bt>0){

var Ny=VW.z_(Math.floor(O9.rV()*l4.Bt));
Ue.Yb(l4.tc(Ny));
l4.DU(Ny);
}
return Ue;
}

LK(up,"kS",Mt);
function Mt(){
var db=up.bm();

if(0==db.Bt){

return;
}
var ZS=up.vh.tc(0);
up.vh=db;

var aE=db.Hh(ZS);

if(aE<0){

up.Aw();
}else{
var cx=db.tc(aE);

up.vh.DU(aE);
up.vh.gX(0,cx);
}
up.K8F++;
}

OZ(up,"H4M",eVA);
function eVA(rv){
rv.rMEiy(up.n9D.jR());

up.n9D=new Yw();
}


OZ(up,"IT4",X0W);
function X0W(Xy){
Xy.A3=up.iAN-up.UVJ;
Xy.qx=up.UVJ;
Xy.k4iy(up.Fkq.jR());

up.Fkq=new Yw();
up.iAN=0;
up.UVJ=0;
}

dN(up,aA,"YY",Os);
function Os(IO){
return;
}



ED(up,"Xi",kj);
function kj(){
return up.vh;
}


Wf(up,"l6",oK);
function oK(nQ){
up.qX=nQ;
if(up.zv!=null){
up.zv.lc=nQ;
}
}
ED(up,"l6",jd_);
function jd_(){return up.qX;}


if(up==fj)aA.L6=null;


ED(up,"ttk",bfB);
function bfB(){
if(up.zv!=null){
return up.zv.YU();
}
return 0;
}

ED(up,"On5",e9J);
function e9J(){
return up.S1;
}

ED(up,"Mrn",zJ5);
function zJ5(){
return up.PdP;
}

ED(up,"WoS",Nr1);
function Nr1(){
return up.K8F;
}

ED(up,"T7G",ifW);
function ifW(){
if(up.zv==null){
return null;
}else{
return up.zv.T7G;
}
}
OZ(up,"MVu",Kj5);
function Kj5(){
up.XL();
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(aA,"aA");











function _U(){
var up=this;
if(up==fj)_U.kO=0;
if(up==fj)_U.WM=1;
if(up==fj)_U.ki=2;
if(up==fj)_U.z6=3;




if(up==fj)_U.P_="CNO";



if(up!=fj)up.Ay=undefined;
if(up!=fj)up.Gh=undefined;
if(up!=fj)up.dK=undefined;
if(up!=fj)up.oS=undefined;
if(up!=fj)up.m_=undefined;
if(up!=fj)up.QL=undefined;

if(up!=fj)up.bs=undefined;
if(up!=fj)up.wu=undefined;









if(up==fj)_U.xr=1;
if(up!=fj)up.CJ=undefined;



if(up!=fj)up.rT7=undefined;









function ju(KC){
up.wu=_U.kO;
up.QL=0;

up.Ay=ConvivaContentInfo.o1(KC);
up.Gh=new yj();

up.hA=oL.PX(up.Ay.hA);

up.bs=VW.z_(O9.bG());
up.CJ=_U.xr;
_U.xr++;
up.oS=Tp.Flu();
up.m_=Lt.fp();



up.dK=null;


up.Gh.JZ=VW.z_(up.bs);
up.Gh.Gj=false;
up.Gh.cX=-1;
up.Gh.kY=-1;
up.Gh.OV=_U.vD(null,0);
up.Gh.dQ=_U.vD(WP.TY+".Default",0);
up.Gh.jz=new VI();
if(up.hA.Wt(_U.P_)&&
(up.hA.tc(_U.P_)!=null)&&
(up.hA.tc(_U.P_)!="")){
ct.qF("GenericSession","CNO: Changing assetName from \""+up.Ay.CXF
+"\" to \""+up.hA.tc(_U.P_)+"\"");
up.Gh.jz.tg(up.hA.tc(_U.P_));
}else{
ct.qF("GenericSession","CNO: No change");
up.Gh.jz.tg(up.Ay.CXF);
}

up.Gh.ZT=0;
up.Gh.TMi=VW.z_(up.Ay.TMi);
up.Gh.oP9=up.Ay.oP9;
up.Gh.Kjn=L_.Ho(up.m_);
if(up.Ay.xQh!=null){
up.Gh.xQh=new VI();
up.Gh.xQh.tg(up.Ay.xQh);
}
}





OZ(up,"wy",NQ);
function NQ(){
up.AGP();
}

OZ(up,"AGP",kRf);
function kRf(){
if(up.dK!=null){
up.dK.wy();
up.dK=null;
}

PT.Z6(up.Gh.JZ);
}


ED(up,"Jl",uh);
function uh(){return up.bs;}



ED(up,"Bl",fJ);
function fJ(){return up.CJ;}


ED(up,"FR",tU);
function tU(){return up.dK;}
Wf(up,"FR",xl);
function xl(nQ){up.dK=nQ;}



ED(up,"IW",f6);
function f6(){
if(up.oS<=0.0&&Tp.Cz>0.0){

var yd=Lt.fp()-up.m_;
up.oS=Tp.Flu()-yd;
}
return((up.oS>0.0)?up.oS:0.0);
}


ED(up,"CXF",IBV);
function IBV(){return up.Ay.CXF;}


ED(up,"sY",hw);
function hw(){return up.wu;}



ED(up,"hA",ml);
function ml(){return up.rT7;}
Wf(up,"hA",gn);
function gn(nQ){
var qcR=new aSf();
qcR.lqB(nQ);
qcR.B2(up.Ay);
up.rT7=qcR.TQW();
up.MA0();
}


ED(up,"KC",i5);
function i5(){return up.Gh;}


ED(up,"Z3",mq);
function mq(){return up.Ay;}






ED(up,"NT",T4);
function T4(){return up.QL;}


OZ(up,"MA0",Qf0);
function Qf0(){
up.Ay.hA=oL.uM(up.rT7);
up.Gh.hA=new VI();
up.Gh.hA.tg(O9.GK(up.rT7));
}






OZ(up,"U3",dP);
function dP(){

var OM=new pA();

if(up.dc(OM,false)){
PT.de(OM);
}
}







OZ(up,"dc",oZ);
function oZ(_D,EoN){
up.B2(_D);
up.Z1(_D,EoN);
return _D.z9;
}

OZ(up,"B2",cT);
function cT(_D){
_D.KC=up.Gh;
}

OZ(up,"Z1",e8);
function e8(_D,EoN){
_D.z9=false;
if(up.dK!=null){
var aJ=up.dK.yJ(EoN,_D.yWeN());
if(aJ!=null){
_D.z9=true;
_D.X_=aJ;
}
}
}




OZ(up,"yr",hT);
function hT(y_){
}






OZ(up,"F3",us);
function us(Xa,Sf,L2){
var _D=new pA();
_D.KC=up.Gh;

if(Xa!=null){
_D.ZN=true;
_D.HX=Xa;
}
if(Sf!=null){
_D.y4=true;
_D.eN=Sf;
}
if(L2!=null){
_D.z9=true;
_D.X_=L2;
}



ct.qF("Control["+up.Bl+"]","Sending HB for session "+up.Jl);
WP.UoM(
jh.oIy(_D));
}

OZ(up,"Li",vP);
function vP(iv,message){
WP.Li(new ConvivaNotification(iv,message,up.CXF));
}





dN(up,_U,"vD",JC);
function JC(Oo,rZ){
var S5=new Oy();
if(rZ!=0||Oo==null){
S5.wf=false;
S5.kn=rZ;
}else{
S5.wf=true;
S5.C6=new VI();
S5.C6.tg(Oo);
}
return S5;
}





OZ(up,"Gs9",qtu);
function qtu(){
return up.Ay.CXF==O9.Mul;
}




OZ(up,"YY",Os);
function Os(IO){
if(up.dK!=null){
var Sj="Metrics[\""+up.dK.bL+"\"]";
}
}






if(up!=fj)ju.apply(up,arguments);
}
Bg(_U,"_U");














function Og(){
var up=this;

if(up!=fj)up.N2=undefined;
if(up!=fj)up.t5=undefined;

function ju(Vr){
up.N2=Vr;
up.t5=new Yw();
up.lc=0;
}

OZ(up,"wy",NQ);
function NQ(){
if(up.t5!=null){
var NW=up.t5;
up.t5=null;
var bC=NW.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var jr=bC[Jo];

jr.wy();
}
}
}








OZ(up,"z2",lZ);
function lZ(Oh,jV,mf,Yi){
var qA=
function(EU,fh){

if(up.t5!=null){
up.t5.gS(fh);
}
if(EU!=null){

if(!O9.H6){
ct.Error("GWConnection",oL.fg(EU));
}
if(Yi!=null)Yi(EU);
}else{
if(mf!=null)mf(fh.X5,fh.T8T);
}

};


var pv=new EW();
if(up.lc>0){
pv.a9("timeoutMs",oL.fg(up.lc));
}
pv.a9("contentType","application/octet-stream");

var iCN=undefined;
if(Og.xT0==null){
iCN=new nD(up.N2+"/"+Oh,qA,
jV,
pv);
}else{
iCN=Og.xT0(Oh,qA,
jV,
pv);
}
up.t5.Yb(iCN);
}


OZ(up,"YU",gI);
function gI(){
return(up.t5==null?0:up.t5.Bt);
}

OZ(up,"M5T",TPd);
function TPd(){
if(up.t5!=null&&up.t5.Bt>0){
if(up.t5.tc(0).T8T>=up.lc){
return true;
}
}
return false;
}

if(up!=fj)up.qkQ=undefined;


ED(up,"lc",eS);
function eS(){
return up.qkQ;
}
Wf(up,"lc",Fl);
function Fl(nQ){
up.qkQ=nQ;
}

ED(up,"T7G",ifW);
function ifW(){
return up.N2;
}

if(up==fj)Og.xT0=null;
if(up!=fj)ju.apply(up,arguments);
}
Bg(Og,"Og");













function eI(){
var up=this;



function ju(){
}




OZ(up,"Yc",fB);
function fB(ym){

var pv=oL.PX(ym);

if(pv.Wt("traceSenderId")){
ct.t3=pv.tc("traceSenderId");
}

if(pv.Wt("traceToConsole")){
ct.XU=pv.tc("traceToConsole");
}
WP.R_(pv);
}




OZ(up,"Ns",D3);
function D3(sz,TY,ai){
ct.qF("LivePassModule","Starting module "+Uj.vWs);



var GV=null;
if((typeof ai==="string")){
GV=ai;
}else{
GV=ai.toString();
}

WP.nr(sz,TY,GV);
}

OZ(up,"UL",VT);
function VT(_w,KC){
up.DSY(_w,KC);
}


OZ(up,"Pn",Ow);
function Ow(_w,jz){
PT.ia(_w,jz);
}


OZ(up,"ox",gv);
function gv(){

WP.wy();
}













ED(up,"hK",Rx);
function Rx(){
return "v"+Uj.Re;
}


ED(up,"CY",pQ);
function pQ(){
return Uj.Re;
}



LK(up,"fv",Ou);
function Ou(_w,KC){
var _D=up.zL(_w);
if(_D==null){
_D=up.DSY(_w,KC);
}
return _D;
}

LK(up,"DSY",uPu);
function uPu(_w,KC){
return PT.sA(_w,KC,true);
}


OZ(up,"eN",f_);
function f_(_w,KC,YM){

var _D=up.fv(_w,KC);
if(_D==null)return;
_D.Ag(YM);

}




OZ(up,"Ks",VD);
function VD(_w,b8){
var _D=up.zL(_w);
if(_D!=null){
_D.DG(b8);
}
}






OZ(up,"iwg",yD1);
function yD1(_w,b8,DIe){
var _D=up.zL(_w);
if(_D!=null){
_D.DG(b8);
}
}





OZ(up,"uvO",b2H);
function b2H(_w,w6){
var _D=up.zL(_w);
if(_D!=null){
_D.YYM(w6);
}
}





OZ(up,"tlE",VJG);
function VJG(_w,M9){
var _D=up.zL(_w);
if(_D!=null){
_D.IN5(M9);
}
}







OZ(up,"iVI",W3h);
function W3h(_w,cX){
var _D=up.zL(_w);
if(_D!=null){
_D.cDl(cX);
}
}




OZ(up,"Wd",be);
function be(_w,KC,G_,w6,ym){


var _D=up.fv(_w,KC);

var vu=null;
vu=oL.PX(ym);
_D.KwN(G_,w6,0,vu);
}





OZ(up,"KV",md);
function md(_w){
var _D=up.zL(_w);
if(_D!=null){
_D.Uw();
}
}










OZ(up,"oP",wT);
function wT(_w){
var _D=up.zL(_w);
if(_D!=null){
_D.wy();
}
}


LK(up,"zL",sn);
function sn(_w){
return PT.qU(_w);
}




OZ(up,"jt",qD);
function qD(_w){
var _D=PT.qU(_w);
if(_D!=null){
_D.wy();
}
}



OZ(up,"Kl",sI);
function sI(_w){
up.jt(_w);
}


OZ(up,"Xr",uH);
function uH(vt,Sj,qY){
var _D=PT.qU(vt);
ct.qF("API","sendEvent name="+Sj);
if(_D!=null&&_D.FR!=null){
var RXG=new J0C();
RXG.Sj=Sj;
RXG.kB=oL.PX(qY);
_D.FR.UY(RXG);
}
}


OZ(up,"Fq",mG);
function mG(vt,Sj,Ml,kB,Jh){
var _D=PT.qU(vt);
if(_D!=null&&_D.FR!=null){
var RXG=new J0C();
RXG.Sj=Sj;
RXG.Ml=oL.PX(Ml);
RXG.kB=oL.PX(kB);
RXG.PV=oL.PX(Jh);
_D.FR.UY(RXG);
}
}

OZ(up,"gxz",Jqk);
function Jqk(_w){
var _D=up.zL(_w);
if(_D!=null){
_D.gxz();
}
}

OZ(up,"KSn",Awm);
function Awm(_w){
var _D=up.zL(_w);
if(_D!=null){
_D.KSn();
}
}

OZ(up,"euf",i8S);
function i8S(_w){
var _D=up.zL(_w);
if(_D!=null){
_D.euf();
}
}




OZ(up,"Hg",ol);
function ol(Ds){
Ds.a9("LivePass.moduleVersion",up.CY);
O9.Yv(
function(){
WP.YY(Ds);
aA.YY(Ds);
PT.YY(Ds);
},"gatherStats");
}



OZ(up,"Xp",AQ);
function AQ(jl){
ct.XU=jl;
}


OZ(up,"anN",YOk);
function YOk(rU){
WP.u9q(rU);
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(eI,"eI");












function tZ(){
var up=this;

if(up!=fj)up.Rk=undefined;

if(up!=fj)up.aN=undefined;

if(up!=fj)up.Pq=0;

if(up!=fj)up.s_M=null;


if(up!=fj)up.pfD=0;


if(up!=fj)up.uB=undefined;




if(up!=fj)up.RE=false;







function ju(hu,V7,e06){_U.call(up,hu);
up.yq5=false;
up.wu=(V7?_U.ki:_U.z6);


up.Ay.obv(up.Bl);


up.dK=new _A(up.Ay.CXF,new EW(),up);

up.QL=1;
up.Rk=V7;
up.Gh.Gj=false;



up.aN=new GY(up);
if(up.Ay.N_!=null){
var N_=oL.PX(up.Ay.N_);
up.aN.Nd(N_);
}



up.Pq=WP.Wz();
if(e06){



up.uB=new mv(up,up.W3t);
}else{
up.uB=new mv(up,up.Iyv);
}
if(!up.Rk&&up.Ay.fi){
up.Gh.Gj=true;
}
if(!up.Rk){
O9.y8(false,"");

}else{
ct.qF("Ms["+up.Bl+"]","MediaSession(), Running in Light API mode");
}
up.DaB();
}


















OZ(up,"wy",NQ);
function NQ(){

if(up.aN!=null){

up.aN.Xo(Ez.cz);

up.U3();

if(!up.yq5){
WP.rF(CO.el().bD);
}
}

up.AGP();
}

OZ(up,"isO",Ctg);
function Ctg(){
if(up.s_M!=null){
up.s_M.ox();
up.s_M=null;
}
}





OZ(up,"AGP",kRf);
function kRf(){
if(up.aN!=null){
up.aN.wy();
up.aN=null;
}
if(up.uB!=null){
up.uB.wy();
up.uB=null;
}
up.PhAGP();
}


ED(up,"Sc",FZ);
function FZ(){return oL.js(up.Ay.Sc);}


ED(up,"ywE",jLl);
function jLl(){

var f5=oL.js(up.Ay.Sc);
if(f5==null||f5.Bt==0){
if(up.Ay.xQh!=null){
return up.Ay.xQh;
}
}

return null;
}


ED(up,"fMC",XR3);
function XR3(){
return null;
}


OZ(up,"XRr",sk0);
function sk0(){
return oR.oH;
}


ED(up,"eU",PG);
function PG(){return up.uB.eU;}



OZ(up,"Ag",LE);
function LE(YM){
var b58=
(up.Ay.fi&&(up.Ay.Sc==null||
up.Ay.Sc.Bt==0));
if(b58){
up.Li(ConvivaNotification.rg,
"MediaSession: candidateResources must be set");
return;
}

up.uB.NK(YM);
}



ED(up,"Af",tr);
function tr(){
return((up.aN==null||up.aN.ca==Ux.nw)?
0:up.aN.dD());
}


ED(up,"R2",g1);
function g1(){


return up.aN;
}



OZ(up,"Iyv",mzm);
function mzm(Nn){
O9.y8(false,"ResourceSwitchRequest");
}



OZ(up,"W3t",w8p);
function w8p(Nn){
O9.y8(false,"ResourceSwitchRequest");
}


ED(up,"V7",e9);
function e9(){return up.Rk;}

LK(up,"ld",_g);
function _g(ma,HP){
up.Gh.OV=_U.vD(ma,HP);
up.aN.ld(ma,HP);
}




OZ(up,"Gcn",XeK);
function XeK(sr){
for(var co=0;co<up.uB.Ngz.ug;co++){
if(sr==up.uB.Ngz.tc(co).w6.T3())
return up.uB.Ngz.tc(co).rZ;
}
return GY.JRP;
}








OZ(up,"KwN",hWI);
function hWI(G_,sr,rZ,ym){
if(up.aN==null){

return 0;
}
if(up.aN.ca!=Ux.nw){
up.aN.vY();
}
ct.qF("Ms["+up.Bl+"]","Start session for resource "+(sr!=null?sr:"null"));

if(up.Ay!=null&&up.Ay._fK!=null){
up.aN._fK=up.Ay._fK;
}



if(up.V7==true){
sr=tZ.hEL(sr,up.aN.w6,up.Ay);
if(sr!=null){
up.ld(sr,rZ);
}
}
if(up.Rk==true&&VW.z_(up.Ay.Su)>0){
up.aN.VpZ(VW.z_(up.Ay.Su));
}
if(G_!=null){
up.aN.lQ(G_);
up.pfD=Lt.fp();
}
if(!up.yq5){
WP.rF(CO.el().aa);
}

up.s_M=new yqn();
up.s_M.V7=up.Rk;
up.s_M.LhD=up.aN;
up.s_M.KC=up.Ay;
up.s_M.emK=up.dK;
up.s_M.OqY();
up.isO();
return up.aN.id;
}




OZ(up,"Uw",wQ);
function wQ(){
if(up.aN==null)return;
if(up.aN.ca==Ux.nw)return;
up.aN.vY();
}




OZ(up,"DG",c7);
function c7(b8){
if(up.aN==null)return;


ct.qF("Ms["+up.Bl+"]","LightReportError(): "+b8);
var k3=undefined;
switch(b8){
case O9.V6:
k3=RJ.PP;
break;
case O9.NO:
k3=RJ.C8;
break;
default:
k3=RJ.Sz;
break;
}

if(k3!=RJ.Sz){
ct.qF("Ms["+up.Bl+"]","LightReportError() using legacy error code (integer): "+oL.fg(k3));
up.aN.IE(k3,null,up.aN.Jdf.ouW);
}else if(b8!=null&&b8!=""){
ct.qF("Ms["+up.Bl+"]","LightReportError() using custom error message (string): "+b8);
up.aN.hXN(b8);
}else{
ct.qF("Ms["+up.Bl+"]","LightReportError(): invalid error message");
}
}

OZ(up,"YYM",dB9);
function dB9(w6){
if(up.aN==null)return;
if(!up.Rk)return;


ct.qF("MS["+up.Bl+"]","LightSetCurrentResource "+w6);

up.aN.PX9(up.aN.Qk,w6,GY.JRP,ky.I6);
up.KC.OV=_U.vD(w6,up.aN.sa);
}

OZ(up,"IN5",ubO);
function ubO(M9){
if(up.aN==null)return;
if(!up.Rk)return;


ct.qF("Ms["+up.Bl+"]","LightSetCurrentBitrate "+M9);
up.aN.NVn(VW.z_(M9),WT0.I6);
}

OZ(up,"cDl",ROZ);
function ROZ(cX){
if(up.aN==null)return;
if(!up.Rk)return;


ct.qF("Ms["+up.Bl+"]","LightSetContentLength "+cX);
up.aN.FN(VW.z_(cX),GY.gWD);
}






OZ(up,"dc",oZ);
function oZ(_D,EoN){




up.B2(_D);
var na=Lt.VB();

var yH=true;
if(up.sY==_U.ki){

var Lg=CO.el().W1;

if(Lg!=CO.el().Yo&&
up.Pq!=0&&

hR.SI(up.Pq,na)<Lg-200){

ct.qF("Ms["+up.Bl+"]","Skip MonitorStats for light session (hbIntervalLight)");
yH=false;
}
}

if(yH){
var OM=null;

if(up.aN!=null){
OM=up.aN.uo(_D.KC,!EoN);
}else{


}
if(OM!=null){
_D.ZN=true;
_D.HX=OM;
}
}
if(up.uB!=null&&up.Gh.Gj){



var y_=up.uB.wP();
_D.y4=(y_!=null);
if(_D.ZN){

up.RE=false;
}else{

if(y_!=null&&!up.RE){
up.RE=true;
_D.y4=true;
}else{
_D.y4=false;
}
}
if(_D.y4){
_D.eN=y_;
}
}

if(yH&&_D.ZN){
up.Z1(_D,EoN);
}





if(_D.ZN&&CO.hIA==true){
_D.ZN=false;
}

yH=_D.ZN||_D.y4||_D.z9;
if(yH){
up.Pq=na;
}
return yH;
}

OZ(up,"FM8",A7s);
function A7s(na){
if(up.aN==null){
return 0;
}else{
return up.aN.FM8(na);
}
}













OZ(up,"ArX",mbi);
function mbi(){
return up.Z3.xQh;
}




OZ(up,"yr",hT);
function hT(y_){
up.Phyr(y_);
if(y_.gj&&up.aN!=null){
up.aN.TO(y_.lp);
}
if(y_.h4&&up.uB!=null){
up.uB.JF(y_.Zk,false);
}
if(up.dK!=null){
up.dK.yr(y_);
}
}















dN(up,tZ,"hEL",Gmb);
function Gmb(B8y,nhh,KC){
var lb=B8y;
if(lb==null&&nhh==null){
if(KC!=null&&KC.hTs!=null){
lb=KC.hTs;
}else if(KC!=null&&KC.w6!=null){
lb=KC.w6;
}else if(KC!=null&&KC._fK!=null){
lb=KC._fK;
}else if(KC!=null&&KC.hA!=null){
var Mbj=KC.hA.hasOwnProperty("serverName")
if(Mbj){
var qL=KC.hA["serverName"];
lb=qL;
}
}
}
var Cek=oL.js(KC.Sc);
if(lb!=null&&Cek.Bt==0){
Cek.Yb(lb);
}
if(lb==null&&nhh==null){
lb="unknown";
}
return lb;
}


LK(up,"DaB",O5h);
function O5h(){
var nW1=
function(rU,gp){
O9.Ep("Fatal: "+rU+(gp!=null?" IGNORE "+gp:""),true);
ct.Error("Ms["+up.Bl+"]",
rU+(gp!=null?" ("+gp+")":"")
+"  Due to this fatal error, the session must be destroyed.");
WP.Li(new ConvivaNotification(ConvivaNotification.rg,
rU+(gp!=null?" ("+gp+")":""),
up.CXF));
up.AGP();
};
var Vuc=
function(rU,gp){
ct.M3x("Ms["+up.Bl+"]",
rU+(gp!=null?" ("+gp+")":""));
};
up.Ay.XUT(nW1,Vuc,up.Rk);
}

OZ(up,"gxz",Jqk);
function Jqk(){
if(up.aN!=null){
up.aN.gxz();
}
}

OZ(up,"KSn",Awm);
function Awm(){
if(up.aN!=null){
up.aN.KSn();
}
}

OZ(up,"euf",i8S);
function i8S(){
if(up.aN!=null){
ct.qF("Ms["+up.Bl+"]","reportAdError()");
up.aN.IE(RJ.EwJ,null,up.aN.Jdf.ouW);
}else{
ct.Error("Ms["+up.Bl+"]","call reportAdError() before monitor is created");
}
}





OZ(up,"YY",Os);
function Os(IO){
up.PhYY(IO);
if(up.aN!=null)up.aN.YY(IO,up.Gh);
if(up.uB!=null)up.uB.Hg(IO);
}

OZ(up,"zuz",HM1);
function HM1(){
return 0;
}





ED(up,"vA",PO);
function PO(){return up.aN;}
Wf(up,"vA",l3W);
function l3W(nQ){up.aN=nQ;}




if(up!=fj)up.akq=undefined;
ED(up,"yq5",HM2);
function HM2(){return up.akq;}
Wf(up,"yq5",E2t);
function E2t(nQ){up.akq=nQ;}


if(up!=fj)up.YyD=undefined;
ED(up,"GCS",p_E);
function p_E(){return up.YyD;}
Wf(up,"GCS",YzC);
function YzC(nQ){up.YyD=nQ;}

OZ(up,"DRn",J1b);
function J1b(B8y,nhh,KC){
return tZ.hEL(B8y,nhh,KC);
}

OZ(up,"l78",rYH);
function rYH(ZPJ){
up.uB.l78(ZPJ);
}


if(up!=fj)ju.apply(up,arguments);
}
Bg(tZ,"tZ");













function mv(){
var up=this;




if(up==fj)mv.DF=3;

if(up==fj)mv.mY=300*1000;

if(up==fj)mv.Z6o=-1;





if(up==fj)mv.Ud=300*1000;


if(up==fj)mv.bU=mv.mY;


if(up==fj)mv.IM=0;

if(up==fj)mv.Bj=0;

if(up==fj)mv.nC=0;

if(up==fj)mv.qn=0;


dN(up,mv,"rL",ry);
function ry(){
mv.IM=0;
mv.nC=Er.XC;
mv.Bj=0;
mv.qn=Er.rE;
}

dN(up,mv,"bx",vl);
function vl(){
}




if(up!=fj)up.ta=undefined;


if(up!=fj)up.Y0=undefined;



if(up==fj)mv.Qg=15*60;
if(up==fj)mv.H9=15;
if(up!=fj)up.Pr=undefined;



if(up!=fj)up.oJ=0;
if(up!=fj)up.Qc=0;


if(up!=fj)up._a=0;


if(up!=fj)up.lU=0;


if(up!=fj)up.QCo=0;


if(up!=fj)up.Hm=undefined;

if(up!=fj)up.fI=undefined;



if(up!=fj)up.K9=0;


if(up!=fj)up.CI=undefined;


if(up!=fj)up.qK=0;


if(up!=fj)up.Wqe=undefined;





if(up!=fj)up.Jw=undefined;


if(up!=fj)up.FH=null;

if(up!=fj)up.GXC=null;

if(up!=fj)up.xQt=-1;

ED(up,"ld_",OlH);
function OlH(){return up.xQt;}

if(up!=fj)up.YdZ=null;







function ju(wi,Iyv){
up.CI=wi;
up.Wqe=Iyv;

up._a=0;
up.QCo=0;

up.lU=-1;
up.fI=new FQ(n4.z_(mv.Ud),
n4.z_(mv.Ud/20));
up.Hm=null;
up.Y0=new jh(0);
up.ta=new Yw();
up.YdZ=null;
if(up.CI!=null){
if(up.CI.Sc!=null&&up.CI.Sc.Bt>0){
up.ta=up.QCE(up.CI.Sc);
}
else if(up.CI.fMC!=null&&up.CI.fMC.Bt>0){
var f5=new Yw();
var bC=up.CI.fMC.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var w6=bC[Jo];

f5.Yb(w6);
}
up.ta=up.QCE(f5);
}
else if(up.CI.ywE!=null){
up.YdZ=up.CI.ywE;
}
else{
ct.Error("R["+up.CI.Bl+"]","No candidate resource available.");
}
}
up.oJ=Er.XC;
up.Qc=Er.rE;
up.Jw=null;

up.Pr=new Yw();
up.FH=new jh(0);
up.GXC=null;
}

LK(up,"QCE",cbB);
function cbB(f5){
var AAz=new Yw();

if(f5!=null){
var bC=f5.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var w6=bC[Jo];

var Nn=new GH();
Nn.w6=_U.vD(w6,0);
AAz.Yb(Nn);
}
}

return AAz;
}

OZ(up,"wy",NQ);
function NQ(){
up.as();
up.Wqe=null;
up.CI=null;

if(up.fI!=null){
up.fI.wy();
up.fI=null;
}
up.Jw=null;
up.ta=null;
up.Y0=null;

up.FH=null;
up.GXC=null;
}

LK(up,"as",kV);
function kV(){
if(up.Hm!=null){
up.Hm.wy();
up.Hm=null;
}
}


ED(up,"eU",PG);
function PG(){return up.fI;}


ED(up,"Ngz",ZiI);
function ZiI(){return up.Y0;}


ED(up,"KS3",zVm);
function zVm(){return up.lU;}


ED(up,"H3",bn);
function bn(){return up.oJ;}

ED(up,"GF",Vb);
function Vb(){return up.Qc;}










OZ(up,"NK",rq);
function rq(IB){

if(up.Hm!=null)return;
up.xQt=-1;
up.Hm=new Lt(
CO.el().O2,
up.Ww,"ResSel.send");

up.qK=mv.DF;
up.K9=Lt.VB();
up.Jw=IB;
up.Ww();
}





LK(up,"Ww",kx);
function kx(){
O9.y8(up.Hm!=null,"sendImmediateRequest");
up.qK--;
if(up.qK<0){
ct.Error("R["+up.CI.Bl+"]","timeout");
up.Qb(Er.S7,false);
return;
}
up.CI.F3(null,up._M(),null);
}




OZ(up,"Cm",zk);
function zk(){
up.K9=Lt.VB();
up.Qb(Er.XC,true);
}




LK(up,"Qb",hP);
function hP(AR,Zp){

var y_=new j7();

y_.Nm=mv.Z6o;
y_.AR=VW.z_(AR);
y_.oI=Er.rE;

if(up.ta!=null&&up.ta.Bt>0){
y_.f5Gw(n4.z_(up.ta.Bt));
for(var co=0;co<up.ta.Bt;co++){
O9.y8(up.ta.tc(co).w6.wf,"fakeSelectResponse:hasString");
var E2=new OA();
E2.w6=new VI();
var ve3=null;
ve3=up.ta.tc(co).w6.C6.T3();
O9.y8(ve3!=null,"fakeResource should not be null");
ct.qF("ResourceSelector","fakeSelectResponse "+ve3);
E2.w6.tg(ve3);
E2.rZ=co;
y_.f5XZ(n4.z_(co),E2);
}

}else{
var E2=new OA();
E2.w6=new VI();
var ve3=null;
if(up.YdZ!=null){
ve3=up.YdZ;
}
O9.y8(ve3!=null,"fakeResource should not be null");
ct.qF("ResourceSelector","fakeSelectResponse "+ve3);
E2.w6.tg(ve3);
E2.rZ=0;
y_.f5Gw(1);
y_.f5XZ(n4.z_(0),E2);
}

up.QCo++;
up.JF(y_,Zp);
}





OZ(up,"wP",eo);
function eo(){
var kz=Lt.VB();
if(kz-up.K9<CO.el().C3)return null;
up.K9=kz;
return up._M();
}


LK(up,"_M",Xl);
function Xl(){
mv.IM++;

var jr=new Ym();
jr.Nm=up._a;
up.QCo=jr.Nm;
up._a++;

if(up.ta!=null&&up.ta.Bt>0){
jr.Bciy(up.ta.jR());

for(var co=0;co<up.ta.jR().ug;co++){
var w6=up.ta.jR().tc(co).w6;
if(w6.wf){
ct.qF("R["+up.CI.Bl+"]","resource "+co+" "+w6.C6.T3());
}else{
ct.qF("R["+up.CI.Bl+"]","resource "+co+" "+w6.kn);
}
}
}else{
jr.ywE=new VI();
jr.ywE.tg(up.YdZ);
ct.qF("R["+up.CI.Bl+"]","virtualUrl = "+up.YdZ);
}

var z1=Lt.fp()/1000;

var Se=0;

for(Se=0;Se<up.Pr.Bt;Se++){
if(up.Pr.tc(Se).cc>z1-mv.Qg){
break;
}
}

if(Se>0){
var Wp=up.Pr.Bt;
if(Wp-Se>mv.H9)
Se=Wp-mv.H9;

up.Pr.JI(0,VW.z_(Se));
}

jr.Djiy(up.Pr.jR());
jr.JNiy(up.FH);



if(up.GXC!=null){
jr.UcG=new tNj();
jr.UcG.UE(up.GXC);
jr.UcG.u2pHE();
}
jr.Ky=up.CI.FM8(Lt.VB());

return jr;
}



OZ(up,"JF",uN);
function uN(y_,Zp){
var PE=-1;

if(y_.Nm>=0){
if(up.Hm==null&&
y_.Nm<up.QCo){

ct.qF("R["+up.CI.Bl+"]",
"Received a stale response with status code "+
y_.AR+" and warning code "+
y_.oI+" with "+
y_.f5XG()+" resources");
return;
}
up.lU=y_.Nm;

up.FH=y_.Wuxz();
}else{

}

if(up.Hm!=null){
up.xQt=VW.z_(y_.Nm);
up.QCo++;
up.as();
}

if(!Zp){
var cb=hR.SI(
up.K9,Lt.VB());
up.fI.yS(cb);
}

ct.qF("R["+up.CI.Bl+"]","Got response with status code "+y_.AR+" and warning code "+y_.oI+" with "+y_.f5XG()+" resources");



if((y_.oI&Er.sy)==0&&
y_.yWDgv()){
if(y_.Dgv.pHE!=null){
up.GXC=new tNj();
up.GXC.UE(y_.Dgv);
}


if(up.GXC==null){

SH.z2("First Sequencing Policy Info doesn't contain policy name");
}else{
ct.qF("R["+up.CI.Bl+"]","Matching Sequencing Policy: "+up.GXC.pHE.T3()+" ShareId : "+up.GXC.mSS+" ServiceConfigVersion : "+up.GXC.pKR);
}
}else{
up.GXC=null;
ct.qF("R["+up.CI.Bl+"]","No Matching Sequencing policy for this session");
}

up.oJ=y_.AR;
up.Qc=y_.oI;
if(y_.AR!=Er.XC){
mv.nC=y_.AR;
if(y_.AR!=Er.S7){
mv.Bj++;
}
}
if(y_.oI!=Er.rE){
mv.qn=y_.oI;
}

if(y_.f5XG()<=0){
if(up.Jw!=null){
if(y_.aZ&&y_.pk!=null)
{
PE=y_.pk.PE;
}
up.Jw(new D4u(up.oJ,up.Qc,new Yw(),PE));
}
return;
}

up.Y0=y_.f5xz();
if(up.Y0!=null){
for(var co=0;co<up.Y0.ug;co++){
var w6=up.Y0.tc(co);
var dX=w6.w6.T3();
var ed=w6.rZ;
ct.qF("R["+up.CI.Bl+"]","resource "+co+" "+ed+" "+dX);
}
}

if(y_.aZ&&y_.pk!=null){
ct.qF("R["+up.CI.Bl+"]","maxBitrateKbps "+y_.pk.PZ);
ct.qF("R["+up.CI.Bl+"]","minBitrateKbps "+y_.pk.uZ);
ct.qF("R["+up.CI.Bl+"]","startBitrateKbps "+y_.pk.PE);
}


if(up.Jw!=null){

var mpS=new Yw();
for(var pm8=0;pm8<up.Y0.ug;pm8++){
var S3=up.Y0.tc(pm8).w6.T3();
var rZ=up.Y0.tc(pm8).rZ;
mpS.Yb(S3);

up.CI.R2.lf(S3,rZ);
}

if(y_.aZ&&y_.pk!=null)
{
PE=y_.pk.PE;
}
var S5=new D4u(up.oJ,up.Qc,mpS,PE);
up.Jw(S5);
up.Jw=null;
return;
}else{
if(up.CI.V7){
return;
}
}

}

LK(up,"R4I",pFZ);
function pFZ(){

up.K9=-mv.bU;
WP.rF(CO.el().bD);
}


dN(up,mv,"YY",Os);
function Os(IO){
IO.a9("SelectResource.nrRequests",oL.fg(mv.IM));
IO.a9("SelectResource.nrCrcErrors",oL.fg(mv.Bj));
if(mv.nC!=Er.XC){
IO.a9("SelectResource.lastErrorCode",oL.fg(mv.nC));
}
if(mv.qn!=Er.rE){
IO.a9("SelectResource.lastWarningFlags",oL.fg(mv.qn));
}
}



OZ(up,"Hg",ol);
function ol(IO){
if(up.GXC!=null&&up.GXC.pHE!=null){
IO.a9("SequencingPolicyInfo","Name: "+up.GXC.pHE.T3()+" ShareId : "+up.GXC.mSS+" ServiceConfigVersion : "+up.GXC.pKR);
}else{
IO.a9("SequencingPolicyInfo","No Matching Sequencing policy for this session");
}
}


ED(up,"ruz",WBZ);
function WBZ(){return up.GXC;}

OZ(up,"l78",rYH);
function rYH(f5){
up.Y0=f5;
}

OZ(up,"Lbg",fek);
function fek(){
return up._M();
}





if(up!=fj)ju.apply(up,arguments);
}
Bg(mv,"mv");









function PT(){
var up=this;


if(up==fj)PT.dLI=new EW();


if(up==fj)PT.yep=new EW();



if(up==fj)PT.He0=new Yw();

function ju(){
throw new Error("SessionFactory is a static only class");
}


dN(up,PT,"nr",kP);
function kP(){
PT.yep.m3();
PT.dLI.m3();
mv.rL();
}

dN(up,PT,"wy",NQ);
function NQ(){

var Zjf=new Yw();
var bC=PT.dLI.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xF=bC[Jo];

Zjf.Yb(xF);
}
var HH=Zjf.YC;
for(var wt=0;wt<HH.length;wt++){
var _af=HH[wt];

_af.wy();
}
PT.dLI.m3();
PT.yep.m3();
PT.He0.m3();
mv.bx();
}


dN(up,PT,"qU",QAu);
function QAu(_w){
if(PT.yep.Wt(_w)){
return PT.yep.tc(_w);
}else{
return null;
}
}




dN(up,PT,"sA",GIw);
function GIw(_w,KC,V7){
var _D=new tZ(KC,V7,false);
PT.dLI.a9(VW.z_(_D.Jl),_D);
PT.yep.a9(_w,_D);
return _D;
}




dN(up,PT,"ia",YMe);
function YMe(_w,jz){
var KC=new ConvivaContentInfo(jz,
oL.R5(new Yw()),
new EW());
var _D=new fS(KC);
PT.dLI.a9(VW.z_(_D.Jl),_D);
PT.yep.a9(_w,_D);
return _D;
}









dN(up,PT,"Z6",AtE);
function AtE(id){
PT.dLI.gS(id);

var bC=PT.yep.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var _w=bC[Jo];

var _D=PT.yep.tc(_w);
if(_D.KC.JZ==id){
PT.yep.gS(_w);
return;
}
}
}









dN(up,PT,"dc",oZ);
function oZ(m1P){


var S5=new Yw();
var bC=PT.He0.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var zjb=bC[Jo];

S5.Yb(zjb);
}
PT.He0.m3();
var HH=PT.dLI.YC;
for(var wt=0;wt<HH.length;wt++){
var xF=HH[wt];

var OM=new pA();


if(xF.dc(OM,m1P)){



ct.qF("Control["+xF.Bl+"]","Sending HB for session "+xF.Jl);
S5.Yb(OM);
}
}
return S5.jR();
}


dN(up,PT,"de",Q9U);
function Q9U(zjb){
PT.He0.Yb(zjb);
}




dN(up,PT,"yr",hT);
function hT(y_){

if(!PT.dLI.Wt(y_.JZ))return;

var _D=PT.dLI.tc(y_.JZ);
_D.yr(y_);
}





dN(up,PT,"YY",Os);
function Os(IO){
var bC=PT.dLI.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xF=bC[Jo];

xF.YY(IO);
}
mv.YY(IO);
}





Va(up,PT,"Qo",Blm);
function Blm(){return PT.He0;}



dN(up,PT,"rxI",Sl8);
function Sl8(Bii){
if(PT.dLI.Wt(Bii)){
return PT.dLI.tc(Bii);
}else{
return null;
}
}


dN(up,PT,"Czl",rlc);
function rlc(v2m){
var bC=PT.dLI.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xF=bC[Jo];

if(xF.KC.jz.T3()==v2m)return xF;
}
return null;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(PT,"PT");













function aSf(){
var up=this;



if(up==fj)aSf.xZL="c3.fp.os";
if(up==fj)aSf.tJp="c3.br";
if(up==fj)aSf.UBf="c3.br.v";
if(up==fj)aSf.dgE="c3.fp.ps";
if(up==fj)aSf.mSx="c3.fp.major";
if(up==fj)aSf.Xbm="c3.fp.minor";
if(up==fj)aSf.kHq="c3.fp.minor1";
if(up==fj)aSf.pSY="c3.sl.major";

if(up==fj)aSf.ZM8="c3.device.id";
if(up==fj)aSf.AcX="c3.device.model";
if(up==fj)aSf.m9z="c3.device.ver";
if(up==fj)aSf.yz5="c3.device.type";
if(up==fj)aSf.UHt="c3.device.conn";
if(up==fj)aSf.Jof="c3.pt.os";
if(up==fj)aSf.O_2="c3.pt.os.ver";
if(up==fj)aSf.jlb="c3.pt";
if(up==fj)aSf.utK="c3.pt.ver";
if(up==fj)aSf.tIc="c3.pt.br";
if(up==fj)aSf.PLZ="c3.pt.br.ver";
if(up==fj)aSf.QKj="c3.ovpp.name";
if(up==fj)aSf.bGS="c3.framework";
if(up==fj)aSf.BnU="c3.framework.ver";
if(up==fj)aSf.uUL="c3.plugin";
if(up==fj)aSf.Nau="c3.plugin.ver";
if(up==fj)aSf.UQi="c3.player.name";
if(up==fj)aSf.Fgb="c3.viewer.id";



if(up==fj)aSf.Ve9="c3.video.isLive";
if(up==fj)aSf._T2="c3.ab.name";
if(up==fj)aSf.Mqb="c3.int";
if(up==fj)aSf.zCk="full";
if(up==fj)aSf.JHF="light";


if(up==fj)aSf.GpE="Lua";
if(up==fj)aSf.SrM="Js";
if(up==fj)aSf.Qy1="Fl";
if(up==fj)aSf.wWW="Sl";


if(up==fj)aSf.Khw="T";
if(up==fj)aSf.BvQ="F";


if(up==fj)aSf.sNv="c3.rand";
if(up!=fj)up.PTP=undefined;

if(up!=fj)up.rT7=undefined;
if(up!=fj)up.W7O=undefined;

function ju(){
up.rT7=null;
up.W7O=null;
up.PTP=(VW.z_(O9.rV()*20))*5;
}


OZ(up,"TQW",QH2);
function QH2(){
if(iV.UV_!=null){
up.rT7.a9(aSf.AcX,iV.UV_);
}
up.rT7.a9(aSf.Jof,iV.pw);
up.rT7.a9(aSf.xZL,iV.pw);
up.rT7.a9(aSf.tIc,iV.pD);
up.rT7.a9(aSf.tJp,iV.pD);
up.rT7.a9(aSf.PLZ,iV.Tf);
up.rT7.a9(aSf.UBf,iV.Tf);
var _M3=CO.kd9;
if(_M3!=null&&_M3.length>0){
up.rT7.a9(aSf._T2,_M3);
}


up.rT7.a9(aSf.jlb,aSf.SrM);
if(WP.o5N!=null){
up.rT7.a9(aSf.jlb,WP.o5N);
}


if(up.W7O.nFQ!=null){
up.rT7.a9(aSf.QKj,up.W7O.nFQ);
}
if(up.W7O.eQZ!=null){
up.rT7.a9(aSf.bGS,up.W7O.eQZ);
}
if(up.W7O.Jqo!=null){
up.rT7.a9(aSf.BnU,up.W7O.Jqo);
}
if(up.W7O.wL2!=null){
up.rT7.a9(aSf.uUL,up.W7O.wL2);
}
if(up.W7O.alT!=null){
up.rT7.a9(aSf.Nau,up.W7O.alT);
}
if(up.W7O.o6d!=null){
up.rT7.a9(aSf.Fgb,up.W7O.o6d);
}
if(up.W7O.yuB!=null){
up.rT7.a9(aSf.ZM8,up.W7O.yuB);
}
if(up.W7O.lTq!=null){
up.rT7.a9(aSf.yz5,up.W7O.lTq);
}
if(up.W7O.qMR!=null){
up.rT7.a9(aSf.UQi,up.W7O.qMR);
}
up.rT7.a9(aSf.Ve9,(up.W7O.cex?aSf.Khw:aSf.BvQ));


if(up.PTP<10){
up.rT7.a9(aSf.sNv,"0"+oL.fg(up.PTP));
}else{
up.rT7.a9(aSf.sNv,oL.fg(up.PTP));
}


up.rT7.a9(aSf.Mqb,aSf.JHF);
return up.rT7;
}

OZ(up,"lqB",bU8);
function bU8(OtD){
up.rT7=new EW();

if(OtD!=null){
var bC=OtD.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];

up.rT7.a9(yw,OtD.tc(yw));
}
}
}

OZ(up,"B2",cT);
function cT(LC){
up.W7O=LC;
}






































if(up!=fj)ju.apply(up,arguments);
}
Bg(aSf,"aSf");





function h3(){

this.P0=function(){
return 4;
};
this.r2=function(){
return(this.shIt==true);
};
this.nUD=function(){
return(this.CjiIt==true);
};
Ip.Kt(this,true,h3);
};
yR(h3,"h3");
Ip.B6(h3
,"Kx"+",u2"
,"on"+",u1"
,"ic"+",u2"
,"Mb"+",i1"
,"Oa"+",i8"
,"pW"+",a=c="+"T_"+""
,"sh"+",b,e"
,"Yf"+",a=u4:"+"P0"+"(),e,c="+"r2"+"()"
,"TK"+",u4,e"
,"ST"+",u1,e"
,"Cji"+",b,e,o="+"ST"+":0"
,"wrD"+",i4,e,o="+"ST"+":1,c="+"nUD"+"()"
);

function xD(){

Ip.Kt(this,true,xD);
};
yR(xD,"xD");
Ip.B6(xD
,"Kx"+",u2"
,"on"+",u1"
,"ic"+",u2"
,"rv"+",c="+"CM"+""
,"Ei"+",a=c="+"pA"+""
,"gq"+",c="+"Ku"+""
);




function aj(){

Ip.Kt(this,false,aj);
};
yR(aj,"aj");
Ip.B6(aj
,"on"+",u1"
,"ic"+",u2"
,"M9"+",u2"
,"WR"+",i4,d=-1"
,"B0"+",i4,d=-1,e"
,"ST"+",u1,e"
,"qt"+",i4,d=-1,e,o="+"ST"+":0"
);

function WE(){

Ip.Kt(this,false,WE);
};
yR(WE,"WE");
Ip.B6(WE
,"on"+",u1"
,"ic"+",u2"
,"uv"+",u1"
,"wG"+",u1"
,"VY"+",u1"
,"ST"+",u1,e"
,"LeQ"+",u4,e,o="+"ST"+":0"
);

function Er(){

Ip.Kt(this,false,Er);
};
yR(Er,"Er");
Ip.B6(Er
,"on"+",u1"
,"ic"+",u2"
);






Er.XC=0;

Er.CE=4;

Er.UR=5;

Er.bFr=6;

Er.S7=32;

Er.bW=-2;

Er.rE=0;

Er.Rv=1;

Er.sy=2;

Er.ga=4;

Er.EO=8;


function qV(){

Ip.Kt(this,false,qV);
};
yR(qV,"qV");
Ip.B6(qV
,"on"+",u1"
,"ic"+",u2"
,"X2"+",i8"
,"fD"+",s"
);

function OA(){

Ip.Kt(this,false,OA);
};
yR(OA,"OA");
Ip.B6(OA
,"on"+",u1"
,"ic"+",u2"
,"w6"+",s"
,"rZ"+",i4"
,"yT"+",b"
);

function hs(){

this.OI=function(){
return this.KDIt==true;
};
Ip.Kt(this,false,hs);
};
yR(hs,"hs");
Ip.B6(hs
,"on"+",u1"
,"ic"+",u2"
,"Sj"+",s"
,"X2"+",i8"
,"KD"+",b"
,"OE"+",i4,c="+"OI"+"()"
,"Nm"+",i4"
,"cO"+",i4"
,"Ml"+",m"
,"kB"+",m"
,"PV"+",m"
);

function RO(){

Ip.Kt(this,false,RO);
};
yR(RO,"RO");
Ip.B6(RO
,"on"+",u1"
,"ic"+",u2"
,"uZ"+",i4"
,"PZ"+",i4"
);

function tS(){

Ip.Kt(this,false,tS);
};
yR(tS,"tS");
Ip.B6(tS
,"on"+",u1"
,"ic"+",u2"
,"PE"+",i4"
,"uZ"+",i4"
,"PZ"+",i4"
);

function WY(){

Ip.Kt(this,false,WY);
};
yR(WY,"WY");
Ip.B6(WY
,"on"+",u1"
,"ic"+",u2"
);





WY.Jn=0;
WY.cB=1;


function ud(){

Ip.Kt(this,false,ud);
};
yR(ud,"ud");
Ip.B6(ud
,"on"+",u1"
,"ic"+",u2"
,"n9"+",i8"
,"OE"+",i8"
);

function GH(){

Ip.Kt(this,false,GH);
};
yR(GH,"GH");
Ip.B6(GH
,"on"+",u1"
,"ic"+",u2"
,"w6"+",c="+"Oy"+""
);

function xm(){

Ip.Kt(this,false,xm);
};
yR(xm,"xm");
Ip.B6(xm
,"on"+",u1"
,"ic"+",u2"
,"qx"+",i4"
,"A3"+",i4"
,"k4"+",a=c="+"AO"+""
);

function yj(){

Ip.Kt(this,false,yj);
};
yR(yj,"yj");
Ip.B6(yj
,"on"+",u1"
,"ic"+",u2"
,"Gj"+",b"
,"JZ"+",i4"
,"dQ"+",c="+"Oy"+""
,"hA"+",s"
,"jz"+",s"
,"cX"+",i4,d=-1"
,"Ai"+",i4"
,"kY"+",i2,d=-1"
,"OV"+",c="+"Oy"+",e"
,"ZT"+",i2,d=0,e"
,"ST"+",u1,e"
,"TMi"+",i4,d=0,e,o="+"ST"+":0"
,"oP9"+",i1,e,o="+"ST"+":1"
,"Kjn"+",i8,d=0,e,o="+"ST"+":2"
,"xQh"+",s,e,o="+"ST"+":3"
);

function jb(){

this.XP=function(){
return this.irIt==true;
};
Ip.Kt(this,false,jb);
};
yR(jb,"jb");
Ip.B6(jb
,"on"+",u1"
,"ic"+",u2"
,"IH"+",c="+"ud"+""
,"Sj"+",s"
,"t4"+",m"
,"ir"+",b"
,"nQ"+",d,c="+"XP"+"()"
);

function Ku(){

Ip.Kt(this,false,Ku);
};
yR(Ku,"Ku");
Ip.B6(Ku
,"on"+",u1"
,"ic"+",u2"
,"Mb"+",i1"
,"SC"+",a=c="+"qV"+""
);

function RV(){

Ip.Kt(this,false,RV);
};
yR(RV,"RV");
Ip.B6(RV
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"AR"+",i1"
);

function PL(){

Ip.Kt(this,false,PL);
};
yR(PL,"PL");
Ip.B6(PL
,"on"+",u1"
,"ic"+",u2"
,"w6"+",c="+"Oy"+""
,"ws"+",i4"
,"Xt"+",i8"
,"Jc"+",i2,d=-1,e"
,"V4"+",a=c="+"RJ"+",e"
,"Gi"+",i2,d=-1,e"
,"WR"+",i4,d=-1,e"
,"iO"+",i4,d=-1,e"
,"B0"+",i4,d=-1,e"
);

function j7(){

this.Md=function(){
return(this.aZIt==true);
};
Ip.Kt(this,false,j7);
};
yR(j7,"j7");
Ip.B6(j7
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"AR"+",i1"
,"oI"+",i4"
,"f5"+",a=c="+"OA"+""
,"Wu"+",a=u1,e"
,"aZ"+",b,e"
,"pk"+",c="+"tS"+",e,c="+"Md"+"()"
,"ST"+",u1,e"
,"Dgv"+",c="+"tNj"+",e,o="+"ST"+":0"
);

function CM(){

this.xW=function(){
return 4;
};
Ip.Kt(this,false,CM);
};
yR(CM,"CM");
Ip.B6(CM
,"on"+",u1"
,"ic"+",u2"
,"ib"+",a=u4:"+"xW"+"()"
,"Cn"+",c="+"WE"+""
,"TY"+",c="+"Oy"+""
,"Xy"+",c="+"xm"+",e"
,"M0"+",u4,e"
,"ST"+",u1,e"
,"Xj"+",u2,d=0,e,o="+"ST"+":0"
,"QyN"+",u4,e,o="+"ST"+":1"
,"AXQ"+",i4,e,o="+"ST"+":2"
,"rME"+",a=i4,e,o="+"ST"+":3"
,"lkb"+",u4,e,o="+"ST"+":4"
,"Nm"+",i4,e,o="+"ST"+":5"
);

function Zq(){

Ip.Kt(this,false,Zq);
};
yR(Zq,"Zq");
Ip.B6(Zq
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"IH"+",c="+"ud"+""
,"eY"+",m"
,"EG"+",a=c="+"jb"+""
);

function oR(){

Ip.Kt(this,false,oR);
};
yR(oR,"oR");
Ip.B6(oR
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"dv"+",i4,d=-1"
,"EA"+",i4,d=-1"
,"vG"+",i4,d=-1"
,"IC"+",i2,d=-1"
,"sb"+",i2,d=-1"
,"jD"+",i2,d=-1"
,"au"+",i4"
,"zg"+",i4"
,"zc"+",i4"
,"Ky"+",i4"
,"_f"+",i4,d=-1"
,"ps"+",i4,d=-1"
,"fF"+",i1"
,"uX"+",a=c="+"PL"+""
,"LI"+",i4"
,"rp"+",i4"
,"lw"+",i4,d=-1,e"
,"w0"+",i4,d=-1,e"
,"LM"+",i4,d=-1,e"
,"oF"+",i4,e"
,"Gu"+",i1,e"
,"_7"+",a=c="+"aj"+",e"
,"ZL"+",i4,d=0,e"
,"E8"+",i4,e"
,"vi"+",i2,d=-1,e"
,"Q5"+",i4,d=-16777220,e"
);






oR.oH=-16777220;

oR.gt=-16777219;


function Ym(){

this.Md=function(){
return(this.aZIt==true);
};
Ip.Kt(this,false,Ym);
};
yR(Ym,"Ym");
Ip.B6(Ym
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"RI"+",a=s"
,"yv"+",i2,d=-1"
,"Bc"+",a=c="+"GH"+",e"
,"Dj"+",a=c="+"ky"+",e"
,"JN"+",a=u1,e"
,"aZ"+",b,e"
,"pk"+",c="+"RO"+",e,c="+"Md"+"()"
,"p9"+",b,e"
,"Ky"+",i4,e"
,"ST"+",u1,e"
,"UcG"+",c="+"tNj"+",e,o="+"ST"+":0"
,"ywE"+",s,e,o="+"ST"+":1"
);

function T_(){

this.Lw=function(){
return this.h4It==true;
};
this.CT=function(){
return this.gjIt==true;
};
this.r_4=function(){
return this.BumIt==true;
};
Ip.Kt(this,false,T_);
};
yR(T_,"T_");
Ip.B6(T_
,"on"+",u1"
,"ic"+",u2"
,"JZ"+",i4"
,"h4"+",b"
,"Zk"+",c="+"j7"+",c="+"Lw"+"()"
,"gj"+",b"
,"lp"+",c="+"RV"+",c="+"CT"+"()"
,"ST"+",u1,e"
,"Bum"+",b,e,o="+"ST"+":0"
,"dZc"+",c="+"mGV"+",e,o="+"ST"+":1,c="+"r_4"+"()"
);

function QR(){

this.qa=function(){
return(this.O4It==true);
};
Ip.Kt(this,false,QR);
};
yR(QR,"QR");
Ip.B6(QR
,"on"+",u1"
,"ic"+",u2"
,"j_"+",i1"
,"GD"+",i8"
,"e6"+",a=c="+"Zq"+""
,"oe"+",i4,e"
,"O4"+",b,e"
,"yA"+",a=c="+"hs"+",e,c="+"qa"+"()"
,"ST"+",u1,e"
,"YH2"+",a=c="+"sYs"+",e,o="+"ST"+":0"
);

function pA(){

this.eC=function(){
return this.y4It==true;
};
this.EB=function(){
return this.ZNIt==true;
};
this.Fh=function(){
return this.z9It==true;
};
Ip.Kt(this,false,pA);
};
yR(pA,"pA");
Ip.B6(pA
,"on"+",u1"
,"ic"+",u2"
,"KC"+",c="+"yj"+""
,"y4"+",b"
,"eN"+",c="+"Ym"+",c="+"eC"+"()"
,"ZN"+",b"
,"HX"+",c="+"oR"+",c="+"EB"+"()"
,"z9"+",b,e"
,"X_"+",c="+"QR"+",e,c="+"Fh"+"()"
,"ST"+",u1,e"
,"_L4"+",a=c="+"a_Y"+",e,o="+"ST"+":0"
);




function _g7(){

Ip.Kt(this,false,_g7);
};
yR(_g7,"_g7");
Ip.B6(_g7
,"on"+",u1"
,"ic"+",u2"
);






_g7.EQT=0;

_g7.ibQ=1;

_g7.NqQ=2;


function mer(){

Ip.Kt(this,false,mer);
};
yR(mer,"mer");
Ip.B6(mer
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"n1E"+",a=i4"
);

function WT0(){

Ip.Kt(this,false,WT0);
};
yR(WT0,"WT0");
Ip.B6(WT0
,"on"+",u1"
,"ic"+",u2"
);






WT0.Lnh=0;
WT0.I6=1;
WT0.hO=2;
WT0.BS=3;


function BN1(){

Ip.Kt(this,false,BN1);
};
yR(BN1,"BN1");
Ip.B6(BN1
,"on"+",u1"
,"ic"+",u2"
);






BN1.dHj=0;

BN1.JE2=1;

BN1.Ah4=2;
BN1.j10=3;
BN1.Nxc=4;
BN1.egY=5;
BN1.ev2=6;
BN1.Azd=7;
BN1.s8r=8;
BN1.MFM=9;
BN1.yfk=10;
BN1.EuH=11;
BN1.HpP=12;
BN1.cRm=13;
BN1.aFH=14;
BN1.jCc=15;
BN1.irD=16;
BN1.OQn=17;
BN1.Y8O=18;
BN1.GXc=19;
BN1.XHH=20;
BN1.kND=21;
BN1.JTY=22;
BN1.DTi=23;
BN1.WMQ=24;
BN1.heZ=25;
BN1.dB5=26;
BN1.dOj=27;
BN1.FzB=28;


function a_Y(){

Ip.Kt(this,false,a_Y);
};
yR(a_Y,"a_Y");
Ip.B6(a_Y
,"on"+",u1"
,"ic"+",u2"
,"GsS"+",s"
,"ST"+",u1"
,"FYj"+",a=s,o="+"ST"+":0"
);

function EOD(){

Ip.Kt(this,false,EOD);
};
yR(EOD,"EOD");
Ip.B6(EOD
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"M9"+",i4,o="+"ST"+":1"
,"rZ"+",i4,e,o="+"ST"+":2"
);

function M24(){

Ip.Kt(this,false,M24);
};
yR(M24,"M24");
Ip.B6(M24
,"on"+",u1"
,"ic"+",u2"
);






M24.Lnh=0;

M24.vn5=1;

M24.nrH=2;


function Yoz(){

Ip.Kt(this,false,Yoz);
};
yR(Yoz,"Yoz");
Ip.B6(Yoz
,"on"+",u1"
,"ic"+",u2"
);






Yoz.RH=0;

Yoz.V67=1;

Yoz.PM=2;


function lJG(){

Ip.Kt(this,false,lJG);
};
yR(lJG,"lJG");
Ip.B6(lJG
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"QW8"+",i4,o="+"ST"+":0"
,"Bg8"+",i4,o="+"ST"+":1"
);

function hl1(){

Ip.Kt(this,false,hl1);
};
yR(hl1,"hl1");
Ip.B6(hl1
,"on"+",u1"
,"ic"+",u2"
,"Ky"+",i4"
,"vG"+",i4"
,"M_6"+",i4"
,"qt"+",i2"
,"ST"+",u1,e"
,"bJq"+",i4,e,o="+"ST"+":0"
);

function qkH(){

Ip.Kt(this,false,qkH);
};
yR(qkH,"qkH");
Ip.B6(qkH
,"on"+",u1"
,"ic"+",u2"
,"CaI"+",i4"
,"rvS"+",i2"
);

function nHd(){

Ip.Kt(this,false,nHd);
};
yR(nHd,"nHd");
Ip.B6(nHd
,"on"+",u1"
,"ic"+",u2"
,"CaI"+",i4"
,"rvS"+",i4"
);

function RJ(){

Ip.Kt(this,false,RJ);
};
yR(RJ,"RJ");
Ip.B6(RJ
,"on"+",u1"
,"ic"+",u2"
,"k3"+",i1"
,"Mf"+",i2"
,"ST"+",u1,e"
,"QxR"+",s,e,o="+"ST"+":0"
);






RJ.Sz=0;
RJ.PP=1;
RJ.GG=2;
RJ.Il=3;
RJ.gg=4;
RJ.qH=5;
RJ.C8=6;
RJ.iN=7;
RJ.l2=8;
RJ.v6=9;
RJ.Ed=10;
RJ.sE=11;
RJ.Yq=12;
RJ.J1=13;
RJ.TG=14;
RJ.BV=15;
RJ.nn=16;
RJ.ty=17;
RJ.wz=30;
RJ.t_=31;
RJ.mO=32;
RJ.MJ=33;
RJ.KT=50;
RJ.Dn=51;
RJ.wq=52;
RJ.Bn=53;

RJ.dKY=55;

RJ.zD0=63;

RJ.Mm=64;

RJ.pe=65;

RJ.G8=70;

RJ.R6=71;

RJ.bj=72;

RJ.kI=73;

RJ.AF=74;

RJ.ks=75;

RJ.m8=76;

RJ.IyA=54;

RJ.eSQ=100;

RJ.NA2=101;

RJ.oI7=102;

RJ.DvD=103;

RJ.d_U=81;

RJ.Fm0=82;

RJ.ext=83;

RJ.Vym=84;

RJ.F02=85;

RJ.Iv4=86;

RJ.C4l=87;

RJ.ljS=88;

RJ.tXT=89;

RJ.lMA=90;

RJ.c86=91;

RJ._vy=92;

RJ.B1i=93;

RJ.sS0=94;

RJ.O_g=95;

RJ.Frk=96;

RJ.VSP=97;

RJ.dn4=98;

RJ.RNO=99;

RJ.OYx=104;

RJ.UxR=105;

RJ.TvN=106;

RJ.det=34;

RJ.We0=-1;

RJ.p5W=-2;

RJ.pMT=-3;

RJ.qlI=-4;

RJ.kss=-5;

RJ.jEJ=-6;

RJ.rWF=-7;

RJ.MD0=-8;

RJ.utY=-9;

RJ.brk=-10;

RJ.Eyr=-11;

RJ.Vq1=-12;

RJ.XFg=-13;

RJ.Leq=-14;

RJ.Xpy=-15;

RJ.aqI=-16;
RJ.wOf=-17;

RJ.L5j=-18;
RJ.WSV=-19;
RJ.pON=-20;

RJ.FI4=-21;

RJ._EK=-22;
RJ.KZS=-23;

RJ.NvK=-24;

RJ.zlK=-25;

RJ.nns=-26;

RJ.HAz=-27;

RJ.q79=-28;

RJ.bdg=-29;

RJ.sY8=-30;

RJ.ao_=-31;

RJ.bpH=-32;

RJ.tYD=-33;

RJ.KwX=-34;

RJ.Pb6=-35;

RJ.Dfo=-36;

RJ.TJO=-37;

RJ.Tx1=-38;

RJ.fEN=-39;

RJ.fVN=-40;

RJ.WJf=-41;

RJ.SB5=-42;

RJ._sL=-43;

RJ.B6T=-44;

RJ.RFw=-45;

RJ.YY1=-46;

RJ.H7y=-47;

RJ.A9m=-48;
RJ.Wjf=-49;

RJ.cml=-50;

RJ.QV4=-51;

RJ.Fqh=-52;

RJ.ixj=-53;

RJ.BBn=-54;

RJ.QGd=-55;

RJ.rxv=-56;

RJ.EwJ=20;

RJ.QJl=-57;

RJ.DJ6=-58;

RJ.ws5=-59;

RJ.vJH=-60;

RJ.FEy=-61;

RJ.Cby=-62;

RJ.UDk=-63;

RJ.tO4=-64;

RJ.BX_=-65;

RJ.IKP=-66;

RJ.MUM=-70;

RJ.DtU=-71;

RJ.fq_=-72;

RJ.Jxt=-73;

RJ.eos=-74;

RJ.PSL=-75;

RJ.jkg=-76;

RJ.dFq=-77;

RJ.R2Z=-78;

RJ.Kc7=-79;

RJ.Y8v=-80;

RJ.RQN=-81;

RJ.E21=-82;

RJ.lyh=-83;

RJ.txG=-84;

RJ.LcC=-85;

RJ.URs=-86;

RJ.xSu=-87;

RJ.Joc=-88;

RJ.rHW=-89;

RJ.pxJ=-90;

RJ.vFy=-91;

RJ.fq3=-92;

RJ.VIQ=-93;

RJ.poj=-94;

RJ.gSb=-95;

RJ.ci8=-96;

RJ.Q8l=-97;

RJ.YPR=-98;

RJ.xxy=-99;

RJ.q43=-100;

RJ.SH9=-101;

RJ.HgM=-102;

RJ.UfL=-103;

RJ.iQf=-104;

RJ.xKt=-105;

RJ.Esp=-106;


function dM7(){

Ip.Kt(this,false,dM7);
};
yR(dM7,"dM7");
Ip.B6(dM7
,"on"+",u1"
,"ic"+",u2"
,"RED"+",s"
,"H1"+",s"
);

function e3S(){

Ip.Kt(this,false,e3S);
};
yR(e3S,"e3S");
Ip.B6(e3S
,"on"+",u1"
,"ic"+",u2"
,"RED"+",s"
);

function AFS(){

Ip.Kt(this,false,AFS);
};
yR(AFS,"AFS");
Ip.B6(AFS
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"Q5"+",i4,o="+"ST"+":1"
,"WHm"+",i4,o="+"ST"+":2"
);

function k8L(){

Ip.Kt(this,false,k8L);
};
yR(k8L,"k8L");
Ip.B6(k8L
,"on"+",u1"
,"ic"+",u2"
,"Sj"+",s"
,"ST"+",u1"
,"Ml"+",m,o="+"ST"+":0"
,"kB"+",m,o="+"ST"+":1"
,"PV"+",m,o="+"ST"+":2"
);

function Q6O(){

Ip.Kt(this,false,Q6O);
};
yR(Q6O,"Q6O");
Ip.B6(Q6O
,"on"+",u1"
,"ic"+",u2"
);






Q6O.tsU=0;

Q6O.XrR=1;

Q6O.nl6=2;


function X6Z(){

Ip.Kt(this,false,X6Z);
};
yR(X6Z,"X6Z");
Ip.B6(X6Z
,"on"+",u1"
,"ic"+",u2"
);






X6Z.X0O=0;

X6Z.GZI=1;

X6Z.KFJ=2;

X6Z.ft=3;

X6Z.lKE=4;





X6Z.Ad7=0;

X6Z.Jb0=1;

X6Z.D2p=2;





X6Z.qPU=0;

X6Z.Xw5=1;

X6Z.TiT=2;

X6Z.RFl=3;

X6Z.dWl=4;





X6Z.JOP=0;

X6Z.O1m=1;

X6Z.WHL=2;

X6Z.cGL=3;


function OEK(){

Ip.Kt(this,false,OEK);
};
yR(OEK,"OEK");
Ip.B6(OEK
,"on"+",u1"
,"ic"+",u2"
);






OEK.iBj=0;

OEK.Bh0=1;

OEK.giS=2;


function dVm(){

Ip.Kt(this,false,dVm);
};
yR(dVm,"dVm");
Ip.B6(dVm
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"zg"+",i4,d=-1,e,o="+"ST"+":1"
);

function srQ(){

Ip.Kt(this,false,srQ);
};
yR(srQ,"srQ");
Ip.B6(srQ
,"on"+",u1"
,"ic"+",u2"
);






srQ.Lnh=0;
srQ.JGS=1;
srQ.XGF=2;
srQ.c9Y=3;
srQ.E99=4;
srQ.PmG=5;
srQ.siE=6;
srQ.sIo=7;
srQ.Vz8=8;
srQ.rAU=9;
srQ.Dzm=10;
srQ.dlm=11;
srQ._bg=12;
srQ.Fmw=13;
srQ.DmE=14;
srQ.GRf=15;
srQ.vC7=16;
srQ.Wjg=17;
srQ.Dik=18;
srQ.maU=19;
srQ.SyR=20;
srQ._Pq=21;
srQ.cZk=22;
srQ.UmY=23;
srQ.wCS=24;
srQ.yku=25;
srQ.jaE=26;
srQ.d_x=27;
srQ.DBk=27;
srQ.jHK=28;
srQ.RMn=29;


function Ux(){

Ip.Kt(this,false,Ux);
};
yR(Ux,"Ux");
Ip.B6(Ux
,"on"+",u1"
,"ic"+",u2"
);






Ux.Lnh=0;

Ux.cz=1;

Ux.CS=3;

Ux.DV=6;

Ux.Qh=12;

Ux.nw=98;

Ux.QG=99;

Ux.ft=100;


function EmX(){

Ip.Kt(this,false,EmX);
};
yR(EmX,"EmX");
Ip.B6(EmX
,"on"+",u1"
,"ic"+",u2"
);






EmX.Lnh=0;

EmX.lbi=1;

EmX.tpF=2;


function sXh(){

Ip.Kt(this,false,sXh);
};
yR(sXh,"sXh");
Ip.B6(sXh
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"Xt"+",i4,d=-1,o="+"ST"+":1"
);

function AO(){

Ip.Kt(this,false,AO);
};
yR(AO,"AO");
Ip.B6(AO
,"on"+",u1"
,"ic"+",u2"
,"W0"+",i4"
);

function sqT(){

Ip.Kt(this,false,sqT);
};
yR(sqT,"sqT");
Ip.B6(sqT
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"R7p"+",i4,o="+"ST"+":0"
,"fWb"+",i4,o="+"ST"+":1"
,"BZA"+",i4,o="+"ST"+":2"
,"fK"+",i4,o="+"ST"+":3"
,"yTl"+",i4,o="+"ST"+":4"
,"gAc"+",i4,o="+"ST"+":5"
,"ifs"+",i4,o="+"ST"+":6"
);

function ot(){

Ip.Kt(this,false,ot);
};
yR(ot,"ot");
Ip.B6(ot
,"on"+",u1"
,"ic"+",u2"
);


ot.oQ="bufTime";

ot.oM="connTime";

ot.oDW="fBtRcvd";

ot.Fz="c3.apiErr";

ot.Fo="protoPort";

ot.jx="c3.oldConfig";

ot.qZ="c3.pluginInfo";

ot.Bi="vResChanged";

ot.Gz="vSizeChanged";

ot.Ju="smode";

ot.cA="S";

ot.HZ="A";

ot.vp="sRs";

ot.HD="sBr";

ot.ht="why";

ot.vHA="reasons";

ot.Kd="type";

ot.xy="err";

ot.AID="swTrace";

ot.Hh6="res";

ot.Qt="addr";

ot.e4="proto";

ot.su="port";

ot.Ik="bufT";

ot.da="playT";

ot.V3="lastPlay";

ot.je="joinT";

ot.rW="joinBufT";

ot.W7L="ttfByte";

ot.Ih="bufLen";

ot.K_="minBufLen";

ot.wZ="maxBufLen";

ot.Dr="loadB";

ot.IQ="dropF";

ot.en="phtD";

ot.cJ="rateF";

ot.ha="dwnR";

ot.Ob="minDwnR";

ot._K="maxDwnR";

ot.KF="avgFPS";

ot.Iz="avgPlayFPS";

ot.my="encFPS";

ot.N8="totalT";

ot.Xq="totalPlayT";

ot.ZB="totalStopT";

ot.Ln="totalPauseT";

ot.X0="totalBufT";

ot.Ax="totalSleepT";

ot.sN="swT";

ot.d6="swQT";

ot.Wi="rsErr";

ot.Nu="vHSize";

ot.X4="vWSize";

ot.Xb="avcProf";

ot.EZ="vHRes";

ot.Ya="vWRes";

function Rmb(){

Ip.Kt(this,false,Rmb);
};
yR(Rmb,"Rmb");
Ip.B6(Rmb
,"on"+",u1"
,"ic"+",u2"
);






Rmb.Lnh=0;
Rmb.Le=1;
Rmb.I6=2;
Rmb.hO=3;
Rmb.m6b=4;


function tNj(){

Ip.Kt(this,false,tNj);
};
yR(tNj,"tNj");
Ip.B6(tNj
,"on"+",u1"
,"ic"+",u2"
,"Dkh"+",i4"
,"tQf"+",i4"
,"mSS"+",i4"
,"pKR"+",i4"
,"ST"+",u1"
,"pHE"+",s,o="+"ST"+":0"
);

function VpD(){

Ip.Kt(this,false,VpD);
};
yR(VpD,"VpD");
Ip.B6(VpD
,"on"+",u1"
,"ic"+",u2"
);





VpD.dTi=0;


function Ez(){

Ip.Kt(this,false,Ez);
};
yR(Ez,"Ez");
Ip.B6(Ez
,"on"+",u1"
,"ic"+",u2"
);






Ez.Lnh=0;

Ez.Le=1;

Ez.it=2;

Ez.Io=3;

Ez.cz=4;


function wdT(){

Ip.Kt(this,false,wdT);
};
yR(wdT,"wdT");
Ip.B6(wdT
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"h7b"+",i4,o="+"ST"+":0"
,"w6"+",s,o="+"ST"+":1"
,"ouW"+",u2,o="+"ST"+":2"
);

function Oy(){

this.RR=function(){
return this.wfIt==true;
};
this.bw=function(){
return this.wfIt==false;
};
Ip.Kt(this,false,Oy);
};
yR(Oy,"Oy");
Ip.B6(Oy
,"on"+",u1"
,"ic"+",u2"
,"wf"+",b"
,"C6"+",s,c="+"RR"+"()"
,"kn"+",i4,c="+"bw"+"()"
);

function UN(){

Ip.Kt(this,false,UN);
};
yR(UN,"UN");
Ip.B6(UN
,"on"+",u1"
,"ic"+",u2"
,"D6"+",i2"
,"e2"+",i2"
,"xx"+",i2"
,"cD"+",i2"
,"a_"+",i1"
,"fP"+",i1"
);






UN.FSb=0;

UN.X6=1;

UN._c=2;

UN.aR=3;

UN.lg=4;

UN.mgp=5;

UN.idN=6;




UN.ft=0;

UN.v1E=1;

UN.M87=2;

UN.t9M=3;

UN.DV=4;

UN.o5K=5;

UN.UD7=6;

UN.VPs=7;

UN.xZ=8;

UN.mLh=9;

UN.Zv=10;

UN.lVI=11;

UN.dCo=12;

UN.dkg=13;

UN.bq5=14;

UN.hKx=15;

UN.xZ0=16;

UN.kKC=17;

UN.tmB=18;

UN.MD_=28;

UN.tRi=19;

UN.cv9=20;

UN.Wtg=21;

UN.NC3=22;

UN.VaR=23;

UN.MWt=24;

UN.flG=25;

UN.eWw=26;

UN.QCV=27;

UN.qhA=29;

UN.sou=30;

UN.jpu=31;


function Mcb(){

Ip.Kt(this,false,Mcb);
};
yR(Mcb,"Mcb");
Ip.B6(Mcb
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"ouW"+",u2,o="+"ST"+":0"
,"n_B"+",i4,o="+"ST"+":1"
,"dxR"+",s,o="+"ST"+":2"
);

function ICp(){

Ip.Kt(this,false,ICp);
};
yR(ICp,"ICp");
Ip.B6(ICp
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1,e"
,"fm"+",i1,e,o="+"ST"+":0"
,"eY"+",i1,e,o="+"ST"+":1"
);

function Ptl(){

Ip.Kt(this,false,Ptl);
};
yR(Ptl,"Ptl");
Ip.B6(Ptl
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"ca"+",i1,o="+"ST"+":0"
,"BgX"+",i4,o="+"ST"+":1"
,"SeK"+",i4,o="+"ST"+":2"
,"WR"+",i4,o="+"ST"+":3"
,"UM"+",i4,o="+"ST"+":4"
,"qsk"+",i1,e,o="+"ST"+":5"
);

function njx(){

Ip.Kt(this,false,njx);
};
yR(njx,"njx");
Ip.B6(njx
,"on"+",u1"
,"ic"+",u2"
,"AIg"+",i1"
);

function BZ3(){

Ip.Kt(this,false,BZ3);
};
yR(BZ3,"BZ3");
Ip.B6(BZ3
,"on"+",u1"
,"ic"+",u2"
,"w6"+",c="+"Oy"+""
,"DXb"+",i4"
,"t4e"+",i4"
,"Dne"+",i4"
);

function FBp(){

Ip.Kt(this,false,FBp);
};
yR(FBp,"FBp");
Ip.B6(FBp
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1,e"
,"lb"+",i1,e,o="+"ST"+":0"
,"uZ"+",i4,e,o="+"ST"+":1"
,"PZ"+",i4,e,o="+"ST"+":2"
);

function LfH(){

Ip.Kt(this,false,LfH);
};
yR(LfH,"LfH");
Ip.B6(LfH
,"on"+",u1"
,"ic"+",u2"
,"Od4"+",c="+"RJ"+""
,"RED"+",s"
,"vZj"+",b"
);

function tL2(){

Ip.Kt(this,false,tL2);
};
yR(tL2,"tL2");
Ip.B6(tL2
,"on"+",u1"
,"ic"+",u2"
,"ca"+",i1,d="+(Ux.ft)+""
,"ST"+",u1"
,"zg"+",i4,o="+"ST"+":0"
,"zc"+",i4,o="+"ST"+":1"
,"rp"+",i4,o="+"ST"+":2"
,"LI"+",i4,o="+"ST"+":3"
,"M9"+",i4,o="+"ST"+":4"
,"Z1P"+",i4,o="+"ST"+":5"
,"jD"+",i4,o="+"ST"+":6"
,"FVF"+",i4,o="+"ST"+":7"
,"JEk"+",u1"
,"IC"+",i4,d=-1,o="+"JEk"+":0"
,"dv"+",i4,o="+"JEk"+":1"
,"HBK"+",b,o="+"JEk"+":2"
,"y0L"+",s,o="+"JEk"+":3"
,"_fK"+",s,o="+"JEk"+":4"
,"xQh"+",s,o="+"JEk"+":5"
,"w6"+",s,o="+"JEk"+":6"
,"LZy"+",i1,e,o="+"JEk"+":7"
,"x8D"+",u1,e"
,"Cn"+",s,e,o="+"x8D"+":0"
,"UlN"+",i4,e,o="+"x8D"+":1"
,"HRl"+",m,e,o="+"x8D"+":2"
,"_x_"+",b,e,o="+"x8D"+":3"
);






tL2.Fzg=1;

tL2.yNw=1;

tL2.oLA=3;

tL2.Co4=4;

tL2.cDt=7;


function IZV(){

Ip.Kt(this,false,IZV);
};
yR(IZV,"IZV");
Ip.B6(IZV
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"yvU"+",i1,o="+"ST"+":0"
,"VW9"+",i1"
);

function YxJ(){

Ip.Kt(this,false,YxJ);
};
yR(YxJ,"YxJ");
Ip.B6(YxJ
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"SC7"+",i1,o="+"ST"+":0"
,"Ngi"+",b,o="+"ST"+":1"
,"M9"+",i4,o="+"ST"+":2"
,"w6"+",s,o="+"ST"+":3"
,"_fK"+",s,o="+"ST"+":4"
,"CXF"+",s,o="+"ST"+":5"
,"hA"+",m,o="+"ST"+":6"
);

function pXP(){

Ip.Kt(this,false,pXP);
};
yR(pXP,"pXP");
Ip.B6(pXP
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"bvs"+",a=c="+"nHd"+",o="+"ST"+":0"
,"j3c"+",a=c="+"nHd"+",o="+"ST"+":1"
,"M4V"+",a=c="+"qkH"+",o="+"ST"+":2"
);

function sTg(){

Ip.Kt(this,false,sTg);
};
yR(sTg,"sTg");
Ip.B6(sTg
,"on"+",u1"
,"ic"+",u2"
,"Ti0"+",i2"
,"ST"+",u1"
,"ouW"+",u2,o="+"ST"+":0"
);

function khJ(){

Ip.Kt(this,false,khJ);
};
yR(khJ,"khJ");
Ip.B6(khJ
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"Anr"+",i4,o="+"ST"+":0"
,"Dy9"+",i1,e,o="+"ST"+":1"
);

function gdL(){

Ip.Kt(this,false,gdL);
};
yR(gdL,"gdL");
Ip.B6(gdL
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"lZd"+",s,o="+"ST"+":0"
,"H1"+",s,e,o="+"ST"+":1"
,"oFS"+",s,e,o="+"ST"+":2"
,"bf0"+",i1,d=-1,e,o="+"ST"+":3"
,"CF2"+",i1,e,o="+"ST"+":4"
);

function xMA(){

Ip.Kt(this,false,xMA);
};
yR(xMA,"xMA");
Ip.B6(xMA
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"rT"+",s,o="+"ST"+":0"
,"LZy"+",i1"
,"co2"+",s,o="+"ST"+":1"
,"QxU"+",s,o="+"ST"+":2"
,"MNx"+",i1,o="+"ST"+":3"
,"S03"+",i1,o="+"ST"+":4"
,"cHG"+",i1"
);

function ysh(){

Ip.Kt(this,false,ysh);
};
yR(ysh,"ysh");
Ip.B6(ysh
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"mRK"+",a=c="+"RJ"+",o="+"ST"+":1"
);

function vYD(){

Ip.Kt(this,false,vYD);
};
yR(vYD,"vYD");
Ip.B6(vYD
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"ca"+",i1,o="+"ST"+":0"
,"qsk"+",i1,e,o="+"ST"+":1"
);

function mGV(){

Ip.Kt(this,false,mGV);
};
yR(mGV,"mGV");
Ip.B6(mGV
,"on"+",u1"
,"ic"+",u2"
,"JZ"+",i4"
,"bHE"+",i1"
,"ST"+",u1"
,"L97"+",s,o="+"ST"+":0"
,"BNE"+",a=c="+"EOD"+""
,"MV8"+",b,o="+"ST"+":1"
,"wrD"+",i4,o="+"ST"+":2"
,"tcT"+",b,o="+"ST"+":3"
);






mGV.cQb=0;

mGV.j0x=1;

mGV.Szl=2;

mGV.cO0=3;

mGV.yn1=4;


function Eav(){

Ip.Kt(this,false,Eav);
};
yR(Eav,"Eav");
Ip.B6(Eav
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"w6"+",s,o="+"ST"+":0"
,"Od4"+",c="+"RJ"+""
);

function ky(){

this._v=function(){
return(this.geIt==true);
};
Ip.Kt(this,false,ky);
};
yR(ky,"ky");
Ip.B6(ky
,"on"+",u1"
,"ic"+",u2"
,"cc"+",u4"
,"KG"+",i4"
,"FU"+",i4"
,"GB"+",u1"
,"TQ"+",i1"
,"k3"+",i1"
,"ge"+",b,e"
,"sB"+",c="+"UN"+",e,c="+"_v"+"()"
);





ky.Gg=1;
ky.TA=2;
ky.N9=3;





ky.I6=0;

ky.zx=1;

ky.hO=2;

ky.BS=3;


function yVL(){

Ip.Kt(this,false,yVL);
};
yR(yVL,"yVL");
Ip.B6(yVL
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"TZX"+",i1,o="+"ST"+":0"
,"TpH"+",i4,o="+"ST"+":1"
);

function ILo(){

Ip.Kt(this,false,ILo);
};
yR(ILo,"ILo");
Ip.B6(ILo
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"NR"+",i1,o="+"ST"+":0"
);

function AXJ(){

Ip.Kt(this,false,AXJ);
};
yR(AXJ,"AXJ");
Ip.B6(AXJ
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"k3"+",i1,o="+"ST"+":0"
,"Anr"+",i4,o="+"ST"+":1"
,"oEO"+",s,o="+"ST"+":2"
,"O3z"+",c="+"pXP"+",o="+"ST"+":3"
,"bmB"+",i4,e,o="+"ST"+":4"
,"MMC"+",i4,e,o="+"ST"+":5"
,"qdG"+",a=c="+"hl1"+",e,o="+"ST"+":6"
,"H1"+",s,e,o="+"ST"+":7"
,"JEk"+",u1,e"
,"ouW"+",u2,e,o="+"JEk"+":0"
);

function RPD(){

Ip.Kt(this,false,RPD);
};
yR(RPD,"RPD");
Ip.B6(RPD
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"MMC"+",i4,o="+"ST"+":0"
,"dI0"+",a=c="+"njx"+",o="+"ST"+":1"
,"jD"+",i4,o="+"ST"+":2"
,"O3z"+",c="+"pXP"+",o="+"ST"+":3"
,"bmB"+",i4,e,o="+"ST"+":4"
,"qdG"+",a=c="+"hl1"+",e,o="+"ST"+":5"
,"ouW"+",u2,e,o="+"ST"+":6"
,"KdP"+",i1,e,o="+"ST"+":7"
);

function FEH(){

Ip.Kt(this,false,FEH);
};
yR(FEH,"FEH");
Ip.B6(FEH
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"ca"+",i1,o="+"ST"+":0"
,"NR"+",i1,o="+"ST"+":1"
,"lZd"+",s,o="+"ST"+":2"
,"Anr"+",i4,o="+"ST"+":3"
,"h7b"+",i4,o="+"ST"+":4"
,"LZy"+",i1"
,"O3z"+",c="+"pXP"+",o="+"ST"+":5"
,"vG"+",i4,d=-1,o="+"ST"+":6"
,"f_S"+",i2,d=-1,o="+"ST"+":7"
,"JEk"+",u1"
,"k9T"+",i2,d=-1,o="+"JEk"+":0"
,"dv"+",i4,d=-1,o="+"JEk"+":1"
,"jD"+",i2,d=-1,o="+"JEk"+":2"
,"IC"+",i2,d=-1,o="+"JEk"+":3"
,"sb"+",i2,d=-1,o="+"JEk"+":4"
,"zg"+",i4,d=0,o="+"JEk"+":5"
,"zc"+",i4,d=0,o="+"JEk"+":6"
,"LI"+",i4,d=-1,o="+"JEk"+":7"
,"x8D"+",u1"
,"TU1"+",i4,d=-1,o="+"x8D"+":0"
,"ap8"+",i2,d=-1,o="+"x8D"+":1"
,"lz2"+",i2,d=-1,o="+"x8D"+":2"
,"uY0"+",i1,o="+"x8D"+":3"
,"zjC"+",a=c="+"sXh"+",o="+"x8D"+":4"
,"_n3"+",a=c="+"BZ3"+",o="+"x8D"+":5"
,"O49"+",a=c="+"dVm"+",e,o="+"x8D"+":6"
,"zir"+",a=c="+"ysh"+",e,o="+"x8D"+":7"
,"vq7"+",u1,e"
,"qsk"+",i1,e,o="+"vq7"+":0"
,"Dy9"+",i1,e,o="+"vq7"+":1"
,"qdG"+",a=c="+"hl1"+",e,o="+"vq7"+":2"
,"mSS"+",i4,e,o="+"vq7"+":3"
,"oF"+",i4,d=-1,e,o="+"vq7"+":4"
,"rp"+",i4,d=-1,e,o="+"vq7"+":5"
,"y0L"+",s,e,o="+"vq7"+":6"
,"Gii"+",i2,d=-1,e,o="+"vq7"+":7"
,"z7b"+",u1,e"
,"Z1P"+",i2,d=-1,e,o="+"z7b"+":0"
,"TvW"+",c="+"Mcb"+",e,o="+"z7b"+":1"
,"XvR"+",i1,e,o="+"z7b"+":2"
,"oFS"+",s,e,o="+"z7b"+":3"
,"pKR"+",i4,e,o="+"z7b"+":4"
);

function suI(){

Ip.Kt(this,false,suI);
};
yR(suI,"suI");
Ip.B6(suI
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"xfe"+",c="+"YxJ"+",o="+"ST"+":0"
,"J34"+",c="+"YxJ"+",o="+"ST"+":1"
);

function yGM(){

Ip.Kt(this,false,yGM);
};
yR(yGM,"yGM");
Ip.B6(yGM
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"hk3"+",a=c="+"Eav"+",o="+"ST"+":0"
);

function szi(){

Ip.Kt(this,false,szi);
};
yR(szi,"szi");
Ip.B6(szi
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"ca"+",i1,d="+(Ux.CS)+",o="+"ST"+":0"
,"dv"+",i4,o="+"ST"+":1"
,"E8"+",i4,o="+"ST"+":2"
,"rp"+",i4,o="+"ST"+":3"
,"LI"+",i4,o="+"ST"+":4"
,"OJp"+",i4,o="+"ST"+":5"
,"zir"+",a=c="+"ysh"+",e,o="+"ST"+":6"
,"qsk"+",i1,e,o="+"ST"+":7"
);

function lEc(){

Ip.Kt(this,false,lEc);
};
yR(lEc,"lEc");
Ip.B6(lEc
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"k3"+",i1,o="+"ST"+":0"
,"lZd"+",s,o="+"ST"+":1"
,"D6"+",i2,o="+"ST"+":2"
,"xx"+",i2,o="+"ST"+":3"
,"cD"+",i2,o="+"ST"+":4"
,"oEO"+",s,o="+"ST"+":5"
,"O3z"+",c="+"pXP"+",o="+"ST"+":6"
,"v6K"+",i1,e,o="+"ST"+":7"
,"JEk"+",u1,e"
,"ZlP"+",s,e,o="+"JEk"+":0"
,"szo"+",s,e,o="+"JEk"+":1"
,"qdG"+",a=c="+"hl1"+",e,o="+"JEk"+":2"
,"Anr"+",i4,e,o="+"JEk"+":3"
,"bmB"+",i4,e,o="+"JEk"+":4"
,"MMC"+",i4,e,o="+"JEk"+":5"
,"H1"+",s,e,o="+"JEk"+":6"
,"ouW"+",u2,e,o="+"JEk"+":7"
);

function bOB(){

Ip.Kt(this,false,bOB);
};
yR(bOB,"bOB");
Ip.B6(bOB
,"on"+",u1"
,"ic"+",u2"
,"ST"+",u1"
,"szo"+",s,o="+"ST"+":0"
,"v6K"+",i1,o="+"ST"+":1"
,"KdP"+",i1,o="+"ST"+":2"
,"dI0"+",a=c="+"njx"+",o="+"ST"+":3"
,"O3z"+",c="+"pXP"+",o="+"ST"+":4"
,"ZlP"+",s,e,o="+"ST"+":5"
,"qdG"+",a=c="+"hl1"+",e,o="+"ST"+":6"
,"bmB"+",i4,e,o="+"ST"+":7"
,"JEk"+",u1,e"
,"MMC"+",i4,e,o="+"JEk"+":0"
,"ouW"+",u2,e,o="+"JEk"+":1"
);

function sYs(){

this.OI=function(){
return this.iFMIt==true;
};
this.DMT=function(){
return this.fmIt==srQ.JGS;
};
this.Nql=function(){
return this.fmIt==srQ.XGF;
};
this.ku5=function(){
return this.fmIt==srQ.c9Y;
};
this.X8m=function(){
return this.fmIt==srQ.E99;
};
this.Xjb=function(){
return this.fmIt==srQ._Pq;
};
this.WZI=function(){
return this.fmIt==srQ.SyR;
};
this.uPL=function(){
return this.fmIt==srQ.cZk;
};
this.X7Z=function(){
return this.fmIt==srQ.PmG;
};
this.TDC=function(){
return this.fmIt==srQ.siE;
};
this.xvB=function(){
return this.fmIt==srQ.sIo;
};
this.VTl=function(){
return this.fmIt==srQ.Vz8;
};
this.kzj=function(){
return this.fmIt==srQ.rAU;
};
this.OyH=function(){
return this.fmIt==srQ.Dzm;
};
this.b2q=function(){
return this.fmIt==srQ.dlm;
};
this.E3z=function(){
return this.fmIt==srQ._bg;
};
this.ikN=function(){
return this.fmIt==srQ.Fmw;
};
this.tW6=function(){
return this.fmIt==srQ.GRf;
};
this.zn0=function(){
return this.fmIt==srQ.DmE;
};
this.U2B=function(){
return this.fmIt==srQ.Wjg;
};
this.wLO=function(){
return this.fmIt==srQ.Dik;
};
this.OHi=function(){
return this.fmIt==srQ.maU;
};
this.vE2=function(){
return this.fmIt==srQ.UmY;
};
this.FtV=function(){
return this.fmIt==srQ.wCS;
};
this.hsy=function(){
return this.fmIt==srQ.yku;
};
this.PBD=function(){
return this.fmIt==srQ.jaE;
};
this._P8=function(){
return this.fmIt==srQ.d_x;
};
this.EMT=function(){
return this.fmIt==srQ.DBk;
};
this.Tks=function(){
return this.fmIt==srQ.jHK;
};
this.feC=function(){
return this.fmIt==srQ.RMn;
};
Ip.Kt(this,false,sYs);
};
yR(sYs,"sYs");
Ip.B6(sYs
,"on"+",u1"
,"ic"+",u2"
,"Nm"+",i4"
,"cO"+",i4"
,"Ky"+",i4"
,"iFM"+",b"
,"OE"+",i4,d=-1,c="+"OI"+"()"
,"ST"+",u1"
,"sWk"+",m,o="+"ST"+":0"
,"E_B"+",m,o="+"ST"+":1"
,"zuh"+",m,o="+"ST"+":2"
,"fm"+",i1"
,"KRb"+",c="+"k8L"+",c="+"DMT"+"()"
,"EPv"+",c="+"FEH"+",e,c="+"Nql"+"()"
,"lvu"+",c="+"yGM"+",e,c="+"ku5"+"()"
,"J4I"+",c="+"Ptl"+",e,c="+"X8m"+"()"
,"YgT"+",c="+"LfH"+",e,c="+"Xjb"+"()"
,"Blh"+",c="+"tL2"+",e,c="+"WZI"+"()"
,"aUU"+",c="+"lJG"+",e,c="+"uPL"+"()"
,"xij"+",c="+"szi"+",e,c="+"X7Z"+"()"
,"x1g"+",c="+"vYD"+",e,c="+"TDC"+"()"
,"r_0"+",c="+"ILo"+",e,c="+"xvB"+"()"
,"rGb"+",c="+"bOB"+",e,c="+"VTl"+"()"
,"Mp1"+",c="+"lEc"+",e,c="+"kzj"+"()"
,"AyR"+",c="+"RPD"+",e,c="+"OyH"+"()"
,"fJL"+",c="+"AXJ"+",e,c="+"b2q"+"()"
,"daO"+",c="+"wdT"+",e,c="+"E3z"+"()"
,"fhe"+",c="+"yVL"+",e,c="+"ikN"+"()"
,"zh3"+",c="+"xMA"+",e,c="+"tW6"+"()"
,"Ams"+",c="+"sqT"+",e,c="+"zn0"+"()"
,"Vuh"+",c="+"AFS"+",e,c="+"U2B"+"()"
,"mzE"+",c="+"gdL"+",e,c="+"wLO"+"()"
,"Iur"+",c="+"khJ"+",e,c="+"OHi"+"()"
,"umu"+",c="+"sTg"+",e,c="+"vE2"+"()"
,"TU1"+",i4,d=-1,e,o="+"ST"+":3"
,"bsD"+",i8,d=0,e,o="+"ST"+":4"
,"jYC"+",c="+"ICp"+",e,c="+"FtV"+"()"
,"wSB"+",c="+"dM7"+",e,c="+"hsy"+"()"
,"FTv"+",c="+"FBp"+",e,c="+"PBD"+"()"
,"_K4"+",c="+"mer"+",e,c="+"_P8"+"()"
,"HHX"+",c="+"IZV"+",e,c="+"EMT"+"()"
,"nZl"+",c="+"suI"+",e,c="+"Tks"+"()"
,"BTK"+",c="+"e3S"+",e,c="+"feC"+"()"
);










function JHM(){
var up=this;
if(up!=fj)up.wyb=null;

function ju(OlI,XvR){nv.call(up);
up.fm=srQ.wCS;

up.wyb=new ICp();
up.wyb.fm=VW.z_(OlI);
up.wyb.eY=VW.z_(XvR);
}

OZ(up,"yZ8",zDR);
function zDR(){
var EjT=up.PhyZ8();
EjT.fm=up.fm;
EjT.jYC=up.wyb;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
return true;
}

OZ(up,"gyP",Qh6);
function Qh6(){return "AdEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+"adType="+up.wyb.fm;
nI=nI+"adState="+up.wyb.eY;
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(JHM,"JHM");












function mtl(){
var up=this;

if(up!=fj)up.Xop=undefined;

ED(up,"ouW",Zid);
function Zid(){return up.Xop;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.Xop=nQ;}


if(up!=fj)up.F4Y=undefined;

ED(up,"k3",DwL);
function DwL(){return up.F4Y;}
Wf(up,"k3",cCy);
function cCy(nQ){up.F4Y=nQ;}



if(up!=fj)up.QPz=undefined;

ED(up,"Anr",Nwx);
function Nwx(){return up.QPz;}
Wf(up,"Anr",a9p);
function a9p(nQ){up.QPz=nQ;}



if(up!=fj)up.b7q=undefined;

ED(up,"MMC",l46);
function l46(){return up.b7q;}
Wf(up,"MMC",BDs);
function BDs(nQ){up.b7q=nQ;}


if(up!=fj)up.HSi=undefined;

ED(up,"oEO",uo3);
function uo3(){return up.HSi;}
Wf(up,"oEO",JEw);
function JEw(nQ){up.HSi=nQ;}




if(up!=fj)up.TQx=undefined;

ED(up,"bmB",Pbv);
function Pbv(){return up.TQx;}
Wf(up,"bmB",F54);
function F54(nQ){up.TQx=nQ;}



if(up!=fj)up.LrE=undefined;

Wf(up,"qdG",nDk);
function nDk(nQ){up.LrE=nQ;}



if(up!=fj)up.TrP=undefined;

ED(up,"H1",UPq);
function UPq(){return up.TrP;}
Wf(up,"H1",MzQ);
function MzQ(nQ){up.TrP=nQ;}

function ju(){nv.call(up);
up.fm=srQ.dlm;

up.F4Y=WT0.Lnh;
up.QPz=-1;
up.b7q=-1;
up.HSi=null;
up.TQx=0;
up.LrE=null;
up.TrP=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var fJL=new AXJ();
fJL.k3=up.F4Y;


fJL.bmB=up.TQx;

if(up.QPz>=0)fJL.Anr=up.QPz;
if(up.b7q>=0)fJL.MMC=up.b7q;

if(up.HSi!=null){
fJL.oEO=new VI();
fJL.oEO.tg(up.HSi);
}

if(up.LrE!=null){
fJL.qdGiy(up.LrE);
}

if(up.TrP!=null){
fJL.H1=new VI();
fJL.H1.tg(up.TrP);
}

fJL.ouW=up.Xop;






var EjT=up.PhyZ8();
EjT.fm=srQ.dlm;
EjT.fJL=fJL;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
if(up.F4Y!=WT0.I6)return false;
if(up.QPz==up.TQx)return false;
return true;
}

OZ(up,"gyP",Qh6);
function Qh6(){return "BitrateSwitchEndEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";swId="+up.Xop;
nI=nI+";"+up.J0m(up.F4Y);
nI=nI+";dBr="+up.QPz;
nI=nI+";sBr="+up.TQx;
if(up.HSi!=null){
nI=nI+";switchTrace=("+up.HSi+")";
}
if(up.TrP!=null){
nI=nI+";url="+up.TrP;
}
return nI;
}

LK(up,"J0m",ArE);
function ArE(EU){
switch(EU){
case WT0.Lnh:
return "uninitialized";
case WT0.I6:
return "success";
case WT0.hO:
return "failed";
case WT0.BS:
return "interrupted";
default:
return "";
}
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(mtl,"mtl");












function aJS(){
var up=this;

if(up!=fj)up.Xop=undefined;

ED(up,"ouW",Zid);
function Zid(){return up.Xop;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.Xop=nQ;}


if(up!=fj)up.b7q=undefined;

ED(up,"MMC",l46);
function l46(){return up.b7q;}
Wf(up,"MMC",BDs);
function BDs(nQ){up.b7q=nQ;}


if(up!=fj)up.JSd=undefined;

ED(up,"dI0",sDE);
function sDE(){return up.JSd;}

OZ(up,"spj",EzE);
function EzE(jN){
if(jN!=null){
var bC=jN.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var co=bC[Jo];

var nh=new njx();
nh.AIg=co;
up.JSd.Yb(nh);
}
}
return up.JSd;
}


if(up!=fj)up.od=undefined;

ED(up,"jD",lID);
function lID(){return up.od;}
Wf(up,"jD",ne2);
function ne2(nQ){up.od=nQ;}



if(up!=fj)up.TQx=undefined;

ED(up,"bmB",Pbv);
function Pbv(){return up.TQx;}
Wf(up,"bmB",F54);
function F54(nQ){up.TQx=nQ;}



if(up!=fj)up.LrE=undefined;

Wf(up,"qdG",nDk);
function nDk(nQ){up.LrE=nQ;}


if(up!=fj)up.pnf=undefined;

ED(up,"KdP",bLn);
function bLn(){return up.pnf;}
Wf(up,"KdP",Xw3);
function Xw3(nQ){up.pnf=nQ;}

function ju(){nv.call(up);
up.fm=srQ.Dzm;

up.b7q=0;
up.JSd=new Yw();
up.od=0;
up.TQx=0;
up.LrE=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var AyR=new RPD();

AyR.MMC=up.b7q;
AyR.bmB=up.TQx;

if(up.JSd!=null&&up.JSd.Bt>0){
AyR.dI0Gw(n4.z_(up.JSd.Bt));
for(var co=0;co<up.JSd.Bt;co++){
var nh=new njx();
nh.AIg=up.JSd.tc(co).AIg;
AyR.dI0XZ(n4.z_(co),nh);
}
}
AyR.KdP=up.pnf;
AyR.jD=up.od;

if(up.LrE!=null){
AyR.qdGiy(up.LrE);
}

AyR.ouW=up.Xop;






var EjT=up.PhyZ8();
EjT.fm=srQ.Dzm;
EjT.AyR=AyR;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "BitrateSwitchStartEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";swId="+up.Xop;
nI=nI+";dBr="+up.b7q;
if(up.JSd!=null&&up.JSd.Bt>0){
nI=nI+";"+up.FH4("cause",
up.JSd);
}
nI=nI+";qualitySwitchType="+up.pnf;
nI=nI+";encodedFps="+up.od;
nI=nI+";sBr="+up.TQx;
return nI;
}

LK(up,"FH4",ysw);
function ysw(L96,xBP){
var nI=L96+"=[";
var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+","+yw.AIg;
}
return nI+"]";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(aJS,"aJS");












function AJl(){
var up=this;


if(up!=fj)up.q8=undefined;

ED(up,"ca",Ul);
function Ul(){return up.q8;}
Wf(up,"ca",AOi);
function AOi(nQ){up.q8=nQ;}


if(up!=fj)up.zWQ=undefined;

ED(up,"BgX",kfw);
function kfw(){return up.zWQ;}
Wf(up,"BgX",mV0);
function mV0(nQ){up.zWQ=nQ;}


if(up!=fj)up.dV=undefined;

ED(up,"SeK",cVc);
function cVc(){return up.dV;}
Wf(up,"SeK",AoG);
function AoG(nQ){up.dV=nQ;}


if(up!=fj)up.wzl=undefined;

ED(up,"WR",big);
function big(){return up.wzl;}
Wf(up,"WR",BKP);
function BKP(nQ){up.wzl=nQ;}



if(up!=fj)up.t4_=undefined;

ED(up,"UM",o0M);
function o0M(){return up.t4_;}
Wf(up,"UM",eFx);
function eFx(nQ){up.t4_=nQ;}

function ju(){nv.call(up);
up.fm=srQ.E99;

up.q8=Ux.Lnh;
up.zWQ=0;
up.dV=0;
up.wzl=0;
up.t4_=0;
}

OZ(up,"yZ8",zDR);
function zDR(){

var J4I=new Ptl();
J4I.ca=up.q8;
J4I.BgX=up.zWQ;

if(up.dV>0){
J4I.SeK=up.dV;
}
if(up.wzl>0){
J4I.WR=up.wzl;
}
if(up.q8==Ux.CS){
J4I.UM=up.t4_;
}







var EjT=up.PhyZ8();
EjT.fm=srQ.E99;
EjT.J4I=J4I;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return true;}

OZ(up,"gyP",Qh6);
function Qh6(){return "BufEndEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";pl="+up.q8;
nI=nI+";numTransition="+up.zWQ;
nI=nI+";bufTime="+up.dV;
nI=nI+";plTime="+up.wzl;
if(up.q8==Ux.CS){
nI=nI+";lastPlTime="+up.t4_;
}

return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(AJl,"AJl");












function jcl(){
var up=this;



if(up!=fj)up.q8=undefined;

ED(up,"ca",Ul);
function Ul(){return up.q8;}
Wf(up,"ca",AOi);
function AOi(nQ){up.q8=nQ;}



if(up!=fj)up.iU=undefined;

ED(up,"NR",J5);
function J5(){return up.iU;}
Wf(up,"NR",D8w);
function D8w(nQ){up.iU=nQ;}



if(up!=fj)up.T92=undefined;

ED(up,"oFS",z3W);
function z3W(){return up.T92;}
Wf(up,"oFS",BSc);
function BSc(nQ){up.T92=nQ;}


if(up!=fj)up.Iyf=undefined;

ED(up,"lZd",Azi);
function Azi(){return up.Iyf;}
Wf(up,"lZd",uOe);
function uOe(nQ){up.Iyf=nQ;}


if(up!=fj)up.QPz=undefined;

ED(up,"Anr",Nwx);
function Nwx(){return up.QPz;}
Wf(up,"Anr",a9p);
function a9p(nQ){up.QPz=nQ;}


if(up!=fj)up.tyI=undefined;

ED(up,"h7b",tcZ);
function tcZ(){return up.tyI;}
Wf(up,"h7b",dQ1);
function dQ1(nQ){up.tyI=nQ;}


if(up!=fj)up.OBt=undefined;

ED(up,"y0L",xOL);
function xOL(){return up.OBt;}
Wf(up,"y0L",h6z);
function h6z(nQ){up.OBt=nQ;}


if(up!=fj)up.AdB=undefined;

ED(up,"LZy",glI);
function glI(){return up.AdB;}
Wf(up,"LZy",T7B);
function T7B(nQ){up.AdB=nQ;}




if(up!=fj)up.lIz=undefined;

ED(up,"vG",aUQ);
function aUQ(){return up.lIz;}
Wf(up,"vG",OAg);
function OAg(nQ){up.lIz=nQ;}




if(up!=fj)up.v4=undefined;

ED(up,"w0",Ta7);
function Ta7(){return up.v4;}
Wf(up,"w0",ttD);
function ttD(nQ){
up.v4=nQ;
if(up.v4>=0){
up.b88("minBufLen",up.v4);
}else{
up.PWx("minBufLen");
}
}




if(up!=fj)up.Kw=undefined;

ED(up,"lw",ydJ);
function ydJ(){return up.Kw;}
Wf(up,"lw",LBW);
function LBW(nQ){
up.Kw=nQ;
if(up.Kw>=0){
up.b88("maxBufLen",up.Kw);
}else{
up.PWx("maxBufLen");
}
}


if(up!=fj)up.ydo=undefined;

ED(up,"f_S",XWC);
function XWC(){return up.ydo;}
Wf(up,"f_S",n7P);
function n7P(nQ){up.ydo=nQ;}


if(up!=fj)up.N7I=undefined;

ED(up,"k9T",YVW);
function YVW(){return up.N7I;}
Wf(up,"k9T",N5C);
function N5C(nQ){up.N7I=nQ;}


if(up!=fj)up.Ezg=undefined;

ED(up,"dv",eJ);
function eJ(){return up.Ezg;}
Wf(up,"dv",nDE);
function nDE(nQ){up.Ezg=nQ;}


if(up!=fj)up.od=undefined;

ED(up,"jD",lID);
function lID(){return up.od;}
Wf(up,"jD",ne2);
function ne2(nQ){up.od=nQ;}


if(up!=fj)up.zR=undefined;

ED(up,"IC",DCR);
function DCR(){return up.zR;}
Wf(up,"IC",PS2);
function PS2(nQ){up.zR=nQ;}


if(up!=fj)up.o4=undefined;

ED(up,"sb",Fcu);
function Fcu(){return up.o4;}
Wf(up,"sb",APe);
function APe(nQ){up.o4=nQ;}


if(up!=fj)up.NGs=undefined;

ED(up,"Gii",tbM);
function tbM(){return up.NGs;}
Wf(up,"Gii",HTA);
function HTA(nQ){up.NGs=nQ;}


if(up!=fj)up.ui5=undefined;

ED(up,"zg",zBP);
function zBP(){return up.ui5;}
Wf(up,"zg",BGR);
function BGR(nQ){up.ui5=nQ;}




if(up!=fj)up.fR=undefined;

ED(up,"E8",_X);
function _X(){return up.fR;}
Wf(up,"E8",S55);
function S55(nQ){
up.fR=nQ;
if(up.fR>=0){
up.b88("joinBufT",up.fR);
}else{
up.PWx("joinBufT");
}
}


if(up!=fj)up.ter=undefined;

ED(up,"zc",PEG);
function PEG(){return up.ter;}
Wf(up,"zc",SVZ);
function SVZ(nQ){up.ter=nQ;}


if(up!=fj)up.Kbo=undefined;

ED(up,"LI",iz_);
function iz_(){return up.Kbo;}
Wf(up,"LI",kg1);
function kg1(nQ){up.Kbo=nQ;}



if(up!=fj)up.LSo=undefined;

ED(up,"DsV",c2W);
function c2W(){return up.LSo;}
Wf(up,"DsV",VhY);
function VhY(nQ){up.LSo=nQ;}



if(up!=fj)up.yOB=undefined;

ED(up,"oF",ZYH);
function ZYH(){return up.yOB;}
Wf(up,"oF",raG);
function raG(nQ){up.yOB=nQ;}


if(up!=fj)up.Hy7=undefined;

ED(up,"TU1",FVV);
function FVV(){return up.Hy7;}
Wf(up,"TU1",ns7);
function ns7(nQ){up.Hy7=nQ;}


if(up!=fj)up.YR1=undefined;

ED(up,"ap8",OHY);
function OHY(){return up.YR1;}
Wf(up,"ap8",Z39);
function Z39(nQ){up.YR1=nQ;}



if(up!=fj)up.kUy=undefined;

ED(up,"lz2",ZOO);
function ZOO(){return up.kUy;}
Wf(up,"lz2",tWv);
function tWv(nQ){up.kUy=nQ;}



if(up!=fj)up.mog=undefined;

ED(up,"Z1P",Y6m);
function Y6m(){return up.mog;}
Wf(up,"Z1P",dSM);
function dSM(nQ){up.mog=nQ;}


if(up!=fj)up.bvx=undefined;

ED(up,"uY0",eI4);
function eI4(){return up.bvx;}
Wf(up,"uY0",HwH);
function HwH(nQ){up.bvx=nQ;}


if(up!=fj)up.sd_=undefined;


OZ(up,"z9i",SYF);
function SYF(w6,Xt){
var FAs=new sXh();
if(w6!=null){
FAs.w6=new VI();
FAs.w6.tg(w6);
}

if(Xt>0){
FAs.Xt=Xt;
}
if(up.sd_==null){
up.sd_=new Yw();
}
up.sd_.Yb(FAs);
return up.sd_;
}

LK(up,"bg3",Nq_);
function Nq_(ZOc){
var sr="null";
if(ZOc.w6!=null){
sr=ZOc.w6.T3();
}
return "(rs:"+sr+", bytes:"+ZOc.Xt+")";
}



if(up!=fj)up._Dq=undefined;



OZ(up,"Ix_",JUv);
function JUv(Oo,rZ,Xt,dB3,HNJ){

var vw=new BZ3();
vw.w6=_U.vD(Oo,rZ);
if(Xt>=0)vw.DXb=Xt;
if(dB3>=0)vw.t4e=dB3;
if(HNJ>=0)vw.Dne=HNJ;

if(up._Dq==null){
up._Dq=new Yw();
}
up._Dq.Yb(vw);

return up._Dq;
}


LK(up,"W1S",b13);
function b13(vw){
var QOR="";
if(vw.w6.yWC6()){
QOR=vw.w6.C6.T3();
}else if(vw.w6.yWkn()&&vw.w6.kn!=0){
QOR=oL.fg(vw.w6.kn);
}

return "(rs:"+QOR+", bytes:"+vw.DXb+", playTime:"+
vw.t4e+", bufTime:"+vw.Dne
+")";
}


if(up!=fj)up.gBw=undefined;

OZ(up,"Ll2",Cy6);
function Cy6(Oo,kMN){
if(up.gBw==null){
up.gBw=new Yw();
}
var YEW=new dVm();

if(Oo!=null){
YEW.w6=new VI();
YEW.w6.tg(Oo);
}
YEW.zg=kMN;
up.gBw.Yb(YEW);

return up.gBw;
}


LK(up,"U4m",OsC);
function OsC(YEW){
var Oo="null";
if(YEW.w6!=null){
Oo=YEW.w6.T3();
}
var nI="(";
nI=nI+"rs="+Oo+",";
nI=nI+"totalPlayingTime="+oL.fg(YEW.zg);
nI=nI+")";
return nI;
}


if(up!=fj)up.ZOR=undefined;

OZ(up,"BmP",S5F);
function S5F(w6,YwT){
if(up.ZOR==null){
up.ZOR=new Yw();
}
var qLW=new ysh();

if(w6!=null){
qLW.w6=new VI();
qLW.w6.tg(w6);
}
qLW.mRKGw(n4.z_(YwT.Bt));
for(var co=0;co<YwT.Bt;co++){


var oL8=new RJ();
oL8.UE(YwT.tc(co));
qLW.mRKXZ(n4.z_(co),oL8);
}
up.ZOR.Yb(qLW);
return up.ZOR;
}


LK(up,"O7d",G44);
function G44(qLW){
var Oo="null";
if(qLW.w6!=null){
Oo=qLW.w6.T3();
}
var nI="(rs="+Oo;
for(var co=0;co<qLW.mRKXG();co++){
nI=nI+" <err="+qLW.mRKbh(n4.z_(co)).k3;
nI=nI+", cnt="+qLW.mRKbh(n4.z_(co)).Mf;
nI=nI+">,";
}
nI=nI+")";
return nI;
}


if(up!=fj)up.u7Y=undefined;

ED(up,"qsk",pb8);
function pb8(){return up.u7Y;}
Wf(up,"qsk",ThX);
function ThX(nQ){up.u7Y=nQ;}


if(up!=fj)up.CPx=undefined;

Wf(up,"Dy9",Ful);
function Ful(nQ){up.CPx=nQ;}



if(up!=fj)up.LrE=undefined;

Wf(up,"qdG",nDk);
function nDk(nQ){up.LrE=nQ;}



if(up!=fj)up.b5L=undefined;
if(up!=fj)up.VK1=undefined;

ED(up,"mSS",uS1);
function uS1(){return up.b5L;}
Wf(up,"mSS",Ygs);
function Ygs(nQ){
up.b5L=nQ;
up.VK1=true;
}



if(up!=fj)up.svd=undefined;
if(up!=fj)up.F4m=undefined;

ED(up,"TvW",BKi);
function BKi(){return up.svd;}
Wf(up,"TvW",Ay4);
function Ay4(nQ){
up.svd=nQ;
up.F4m=true;
}

if(up!=fj)up.eeh=undefined;

Wf(up,"XvR",BAn);
function BAn(nQ){up.eeh=nQ;}

if(up!=fj)up.S9x=undefined;

ED(up,"pKR",m2H);
function m2H(){
return up.S9x;
}
Wf(up,"pKR",kpi);
function kpi(nQ){
up.S9x=nQ;
}

function ju(){nv.call(up);
up.fm=srQ.XGF;

up.q8=Ux.Lnh;
up.iU=Ez.Lnh;
up.T92=null;
up.Iyf=null;
up.QPz=-1;
up.tyI=0;
up.OBt=null;
up.AdB=X6Z.X0O;
up.lIz=-1;
up.v4=-1;
up.Kw=-1;
up.ydo=-1;
up.N7I=-1;
up.Ezg=-1;
up.od=-1;
up.zR=-1;
up.o4=-1;
up.NGs=-1;
up.ui5=0;
up.ter=0;
up.fR=-1;
up.Kbo=-1;
up.LSo=-1;
up.yOB=-1;
up.Hy7=-1;
up.YR1=-1;
up.kUy=-1;
up.mog=-1;
up.bvx=M24.vn5;
up.sd_=null;
up._Dq=null;
up.gBw=null;
up.ZOR=null;
up.u7Y=EmX.Lnh;
up.CPx=OEK.iBj;
up.LrE=null;
up.F4m=false;
up.svd=null;
up.VK1=false;
up.b5L=0;
up.eeh=-1;
up.S9x=0;
}

OZ(up,"yZ8",zDR);
function zDR(){

var EPv=new FEH();

EPv.ca=up.q8;
EPv.NR=up.iU;

if(up.Iyf!=null){
EPv.lZd=new VI();
EPv.lZd.tg(up.Iyf);
}
EPv.Anr=up.QPz;

if(up.T92!=null){
EPv.oFS=new VI();
EPv.oFS.tg(up.T92);
}

if(up.tyI!=0){
EPv.h7b=up.tyI;
}

if(up.OBt!=null){
EPv.y0L=new VI();
EPv.y0L.tg(up.OBt);
}

EPv.LZy=up.AdB;

if(up.ydo>=0)
EPv.f_S=up.ydo;
if(up.N7I>=0)
EPv.k9T=up.N7I;

if(up.od>=0)
EPv.jD=up.od;
if(up.zR>=0)
EPv.IC=up.zR;
if(up.o4>=0)
EPv.sb=up.o4;
if(up.NGs>=0)
EPv.Gii=up.NGs;




if(up.Ezg>=0){
EPv.dv=up.Ezg;
}

if(up.lIz>0)
EPv.vG=up.lIz;
if(up.ui5>=0)
EPv.zg=up.ui5;
if(up.ter>=0)
EPv.zc=up.ter;
if(up.Kbo>0)
EPv.LI=up.Kbo;
if(up.LSo>0)
EPv.rp=up.LSo;
if(up.yOB>0)
EPv.oF=up.yOB;


if(up.Hy7>0)
EPv.TU1=up.Hy7;

if(up.YR1>0)
EPv.ap8=up.YR1;
if(up.kUy>0)
EPv.lz2=up.kUy;
if(up.mog>0){
EPv.Z1P=up.mog;
}

EPv.uY0=up.bvx;

var co=undefined;
if(up.sd_!=null&&up.sd_.Bt>0){
EPv.zjCGw(
n4.z_(up.sd_.Bt));
for(co=0;co<up.sd_.Bt;co++){
EPv.zjCXZ(n4.z_(co),
up.sd_.tc(co));
}
}

if(up._Dq!=null&&
up._Dq.Bt>0)
{
EPv._n3Gw(
n4.z_(up._Dq.Bt));
for(co=0;co<up._Dq.Bt;co++){
EPv._n3XZ(n4.z_(co),
up._Dq.tc(co));
}
}

if(up.gBw!=null&&up.gBw.Bt>0){
EPv.O49Gw(
n4.z_(up.gBw.Bt));
for(co=0;co<up.gBw.Bt;co++){
EPv.O49XZ(n4.z_(co),
up.gBw.tc(co));
}
}

if(up.ZOR!=null&&up.ZOR.Bt>0){
EPv.zirGw(
n4.z_(up.ZOR.Bt));
for(co=0;co<up.ZOR.Bt;co++){
EPv.zirXZ(n4.z_(co),
up.ZOR.tc(co));
}
}


if(up.u7Y==EmX.tpF){
EPv.qsk=EmX.tpF;
}

if(up.CPx!=OEK.iBj){
EPv.Dy9=up.CPx;
}

if(up.LrE!=null){
EPv.qdGiy(up.LrE);
}

if(up.VK1){
EPv.mSS=up.b5L;
}

if(up.F4m){
EPv.TvW=up.svd;
}

if(up.eeh>=0){
EPv.XvR=VW.z_(up.eeh);
}

if(up.S9x>=0){
EPv.pKR=up.S9x;
}







var EjT=up.PhyZ8();
EjT.fm=srQ.XGF;
EjT.EPv=EPv;
return EjT;
}


OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "CheckpointEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";pl="+up.q8;
nI=nI+";ses="+up.iU;
nI=nI+";rs="+(up.Iyf!=null?up.Iyf:"null");
nI=nI+";br="+up.QPz;

nI=nI+";ip="+up.qCQ(up.tyI);

nI=nI+";resurl="+(up.OBt!=null?up.OBt:"null");

nI=nI+";integrationType="+
((up.AdB==X6Z.KFJ)?"Full":
(up.AdB==X6Z.GZI?"Light":"Unknown"));

if(up.T92!=null){
nI=nI+";cdnName="+up.T92;
}

if(up.u7Y==EmX.tpF){
nI=nI+";damperSt=damping";
}

if(up.lIz>=0)
nI=nI+";bufLen="+up.lIz;

if(up.ydo>=0)
nI=nI+";maxDownloadBw="+up.ydo;
if(up.N7I>=0)
nI=nI+";minDownloadBw="+up.N7I;

if(up.Ezg>=0)
nI=nI+";joinTime="+up.Ezg;

if(up.od>=0)
nI=nI+";encodedFPS="+up.od;
if(up.zR>=0)
nI=nI+";aveFPS="+up.zR;
if(up.o4>=0)
nI=nI+";playingAvgFPS="+up.o4;

if(up.ui5>=0)
nI=nI+";totalPlayingTime="+up.ui5;
if(up.ter>=0)
nI=nI+";totalBufferingTime="+up.ter;
if(up.Kbo>=0)
nI=nI+";totalStoppedTime="+up.Kbo;
if(up.LSo>=0)
nI=nI+";totalPausedTime="+up.LSo;
if(up.yOB>=0)
nI=nI+";totalSleepTime="+up.yOB;

if(up.Hy7>=0)
nI=nI+";lifetimeAvgBr="+up.Hy7;
if(up.NGs>=0)
nI=nI+";lifetimePlayingAverageFps="+up.NGs;

if(up.YR1>=0)
nI=nI+";totalRsSw="+up.YR1;
if(up.kUy>=0)
nI=nI+";totalRsQuaSw="+up.kUy;
if(up.mog>=0)
nI=nI+";totalBufferingEvents="+up.mog;

nI=nI+";chkpType="+
((up.bvx==M24.vn5)?
"Periodic":"GracefulEnd");

if(up.sd_!=null&&up.sd_.Bt>0)
nI=nI+";"+up.dxy("perRsMeasure",
up.sd_,
up.bg3);

if(up._Dq!=null&&
up._Dq.Bt>0)
{
nI=nI+";"+up.N3v("chkpForRCC",
up._Dq,
up.W1S);
}

if(up.gBw!=null&&
up.gBw.Bt>0){
nI=nI+";"+up.Ucs("lifetimeRsMeasure",
up.gBw,
up.U4m);
}

if(up.ZOR!=null&&
up.ZOR.Bt>0){
nI=nI+";"+up.crf("joinRsMeasure",
up.ZOR,
up.O7d);
}

nI=nI+";avgBrState="+up.CPx;

if(up.F4m){
nI=nI+";swState=("+up.svd.ouW+")";
}

if(up.eeh>=0){
nI=nI+";adState="+up.eeh;
}

if(up.S9x>=0){
nI=nI+";serviceCfgVer = "+up.S9x;
}

return nI;
}

LK(up,"qCQ",B14);
function B14(QF5){
var k3I=0xFF;
var nI=oL.fg((QF5&k3I));
nI=oL.fg(((QF5>>8)&k3I))+"."+nI;
nI=oL.fg(((QF5>>16)&k3I))+"."+nI;
nI=oL.fg(((QF5>>24)&k3I))+"."+nI;
return nI;
}

LK(up,"dxy",Kme);
function Kme(L96,xBP,One){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+One(yw)+",";
}
return nI+"]";
}

LK(up,"N3v",neJ);
function neJ(L96,xBP,One){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+One(yw)+",";
}
return nI+"]";
}

LK(up,"Ucs",CfL);
function CfL(L96,xBP,One){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+One(yw)+",";
}
return nI+"]";
}

LK(up,"crf",MKd);
function MKd(L96,xBP,RKA){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+RKA(yw)+",";
}
return nI+"]";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(jcl,"jcl");










function Mhq(){
var up=this;

ED(up,"Ti0",J3I);
function J3I(){return up.EFJ.Ti0;}
Wf(up,"Ti0",GzR);
function GzR(nQ){up.EFJ.Ti0=nQ;}


ED(up,"ouW",Zid);
function Zid(){return up.EFJ.ouW;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.EFJ.ouW=nQ;}
function ju(){nv.call(up);
up.fm=srQ.UmY;
up.EFJ=new sTg();
}

OZ(up,"yZ8",zDR);
function zDR(){
var EjT=up.PhyZ8();
EjT.fm=srQ.UmY;
EjT.umu=up.EFJ;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
return false;
}

OZ(up,"gyP",Qh6);
function Qh6(){
return "ErrorEvent2";
}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+"; err="+up.Ti0+", swId="+up.ouW;
return nI;
}

if(up!=fj)up.EFJ=undefined;
if(up!=fj)ju.apply(up,arguments);
}
Bg(Mhq,"Mhq");











function t__(){
var up=this;

ED(up,"RED",KSe);
function KSe(){return up.O4m;}
Wf(up,"RED",fO3);
function fO3(nQ){up.O4m=nQ;}


ED(up,"H1",UPq);
function UPq(){return up.TrP;}
Wf(up,"H1",MzQ);
function MzQ(nQ){up.TrP=nQ;}
function ju(){nv.call(up);
up.fm=srQ.yku;
up.O4m="";
up.TrP="";
}

OZ(up,"yZ8",zDR);
function zDR(){
var rCk=new dM7();
rCk.RED=new VI();
rCk.RED.tg(up.O4m);
rCk.H1=new VI();
rCk.H1.tg(up.TrP);

var EjT=up.PhyZ8();
EjT.fm=srQ.yku;
EjT.wSB=rCk;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
return false;
}

OZ(up,"gyP",Qh6);
function Qh6(){
return "ErrorEventByUrl";
}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+"; err="+up.RED+", url="+up.H1;
return nI;
}

if(up!=fj)up.O4m=undefined;
if(up!=fj)up.TrP=undefined;
if(up!=fj)ju.apply(up,arguments);
}
Bg(t__,"t__");













function ddL(){
var up=this;


if(up!=fj)up.oGZ=undefined;

ED(up,"hk3",xSS);
function xSS(){return up.oGZ;}
Wf(up,"hk3",FPE);
function FPE(nQ){
if(nQ==null)return;
up.oGZ=new Yw();
if(up.oGZ!=null){
var bC=nQ.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var izu=bC[Jo];

var wmT=new Eav();
wmT.w6=izu.w6;
wmT.Od4=izu.Od4;
up.oGZ.Yb(wmT);
}
}
}



OZ(up,"Qm6",Fq7);
function Fq7(w6,oL8){

if(up.oGZ==null){
up.oGZ=new Yw();
}



var izu=new Eav();


if(w6!=null){
izu.w6=new VI();
izu.w6.tg(w6);
}
izu.Od4=oL8;


up.oGZ.Yb(izu);
}

LK(up,"Ey9",hmK);
function hmK(izu){
return "(rs="+(izu.yWw6()?izu.w6.T3():"current")
+", err="+izu.Od4.k3
+", cnt="+izu.Od4.Mf+")";
}

function ju(){nv.call(up);
up.fm=srQ.c9Y;

up.oGZ=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var lvu=new yGM();
if(up.oGZ!=null){
lvu.hk3Gw(n4.z_(up.oGZ.Bt));
for(var co=0;co<up.oGZ.Bt;co++){
lvu.hk3XZ(n4.z_(co),up.oGZ.tc(co));
}
}







var EjT=up.PhyZ8();
EjT.fm=srQ.c9Y;
EjT.lvu=lvu;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "ErrorEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

if(up.oGZ!=null&&up.oGZ.Bt>0){
nI=nI+";"+up.LWJ("rsErr",
up.oGZ,
up.Ey9);
}else{
nI=nI+"Error statistics has not been collected yet.";
}

return nI;
}

LK(up,"LWJ",gVz);
function gVz(L96,xBP,One){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+","+One(yw);
}
return nI+"]";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(ddL,"ddL");










function LQP(){
var up=this;

ED(up,"RED",KSe);
function KSe(){return up.O4m;}
Wf(up,"RED",fO3);
function fO3(nQ){up.O4m=nQ;}

function ju(){nv.call(up);
up.fm=srQ.RMn;
up.O4m="";
}

OZ(up,"yZ8",zDR);
function zDR(){
var xqS=new e3S();
xqS.RED=new VI();
xqS.RED.tg(up.O4m);

var EjT=up.PhyZ8();
EjT.fm=srQ.RMn;
EjT.BTK=xqS;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
return false;
}

OZ(up,"gyP",Qh6);
function Qh6(){
return "ErrorMessageEvent";
}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+"; err="+up.RED;
return nI;
}

if(up!=fj)up.O4m=undefined;
if(up!=fj)ju.apply(up,arguments);
}
Bg(LQP,"LQP");






























function G5J(){
var up=this;


if(up!=fj)up.iox=null;

ED(up,"kdV",RBw);
function RBw(){return up.iox;}


if(up!=fj)up.MC6=null;

ED(up,"JST",NUc);
function NUc(){return up.MC6;}



if(up!=fj)up.g7M=0;

function ju(){
up.iox=new Yw();
up.MC6=new Yw();
}

OZ(up,"Yb",hV);
function hV(nzH){
nzH.XM8=up.g7M;
up.g7M++;
up.iox.Yb(nzH);
}

OZ(up,"OlJ",wWS);
function wWS(nzH){
up.iox.gS(nzH);
}




LK(up,"q0F",VWD);
function VWD(gPo,BEb){
if(gPo.wii==BEb.wii){
return(gPo.XM8-BEb.XM8);
}else{
return(BEb.wii-gPo.wii);
}
}




LK(up,"dRN",ezW);
function ezW(gPo,BEb){
return(gPo.XM8-BEb.XM8);
}




OZ(up,"H_3",RRe);
function RRe(Oh7){
var z1=Lt.VB()/1000;
up.iox.HC(up.q0F);


var bC=up.iox.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var nzH=bC[Jo];


if(nzH.wii==jqN.yqJ){

up.MC6.Yb(nzH);
}else{

if(Oh7.kX(1,z1)==qC.IT){
Oh7.Sh(1,z1);
up.MC6.Yb(nzH);
}else{
break;
}
}
}
up.MC6.HC(up.dRN);
}


OZ(up,"m3",kG);
function kG(){

up.iox.m3();


up.MC6.m3();
}



ED(up,"ejQ",XH4);
function XH4(){
return up.iox.Bt-up.MC6.Bt;
}



ED(up,"RfG",zf1);
function zf1(){return up.iox.Bt;}


OZ(up,"uJQ",Vdk);
function Vdk(){
var M1N=up.iox.tc(0);
up.iox.DU(0);
return M1N;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(G5J,"G5J");


















function tm8(){
var up=this;


if(up!=fj)up.iox=null;

if(up!=fj)up.pV=0;


ED(up,"Bfq",_Cl);
function _Cl(){return up.iox;}

function ju(Fx){
up.iox=new Yw();
up.pV=Fx;
}




OZ(up,"Yb",hV);
function hV(nzH){

up.iox.Yb(nzH);
}


LK(up,"Ixf",ZU3);
function ZU3(gPo,BEb){
return(gPo.Nm-BEb.Nm);
}

LK(up,"uvA",vRC);
function vRC(hv){

if(hv.fm==srQ.XGF
||hv.fm==srQ.c9Y){
var F5Y=hR.SI(up.pV,Lt.VB());
var iSp=F5Y-hv.Ky;
return iSp<CO.eon;
}else{
return false;
}
}


OZ(up,"L4r",J2g);
function J2g(){
var z1=Lt.VB()/1000;

var wWf=new Yw();
var bC=up.iox.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var hv=bC[Jo];

if(up.uvA(hv)){
wWf.Yb(hv);
}
}



wWf.HC(up.Ixf);

var X1K=CO.PmJ;
var s44=(wWf.Bt>X1K?(wWf.Bt-X1K):0);
wWf.JI(0,s44);
return wWf;
}


OZ(up,"m3",kG);
function kG(){
up.iox.m3();
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(tm8,"tm8");












function FFu(){
var up=this;

if(up!=fj)up.go=undefined;

ED(up,"w6",dO);
function dO(){return up.go;}
Wf(up,"w6",pl3);
function pl3(nQ){up.go=nQ;}

if(up!=fj)up.cAx=undefined;

ED(up,"Q5",MVX);
function MVX(){return up.cAx;}
Wf(up,"Q5",DYl);
function DYl(nQ){up.cAx=nQ;}

if(up!=fj)up.QwO=undefined;

ED(up,"WHm",YYK);
function YYK(){return up.QwO;}
Wf(up,"WHm",RxY);
function RxY(nQ){up.QwO=nQ;}

function ju(){nv.call(up);
up.fm=srQ.Wjg;

up.go="";
up.cAx=0;
up.QwO=0;
}

OZ(up,"yZ8",zDR);
function zDR(){

var Vuh=new AFS();
Vuh.w6=new VI();
Vuh.w6.tg(up.go);
Vuh.Q5=up.cAx;
Vuh.WHm=up.QwO;






var EjT=up.PhyZ8();
EjT.fm=srQ.Wjg;
EjT.Vuh=Vuh;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "FirstByteRecvdEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";rs="+up.go;

nI=nI+";ip#="+up.cAx;

nI=nI+";ttf="+up.QwO;

return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(FFu,"FFu");












function J0C(){
var up=this;


if(up!=fj)up.pG=undefined;




ED(up,"Sj",eYv);
function eYv(){return up.pG;}
Wf(up,"Sj",igq);
function igq(nQ){
up.pG=nQ;

up.cLZ=jqN.yoi(up.pG);
}


OZ(up,"WbK",J07);
function J07(_j){
up.PhWbK(_j);
if(up.zK!=null)up.fey(up.zK);
if(up.iB!=null)up.fey(up.iB);
}


if(up!=fj)up.zK=undefined;

ED(up,"Ml",qdh);
function qdh(){return up.zK;}
Wf(up,"Ml",TYf);
function TYf(nQ){
if(nQ==null)return;

up.zK=new EW();


var bC=nQ.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

var Tj=uEP.Zw;
var vN=uEP.GU;
if(Tj==null)Tj="null";
if(vN==null)vN="null";
up.zK.Yb(Tj,vN);
}
}


if(up!=fj)up.iB=undefined;

ED(up,"kB",xat);
function xat(){return up.iB;}
Wf(up,"kB",HmS);
function HmS(nQ){
if(nQ==null)return;

up.iB=new EW();


var bC=nQ.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

var Tj=uEP.Zw;
var vN=uEP.GU;
if(Tj==null)Tj="null";
if(vN==null)vN="null";
up.iB.Yb(Tj,vN);
}
}


if(up!=fj)up.kU=undefined;

ED(up,"PV",yiq);
function yiq(){return up.kU;}
Wf(up,"PV",Hiw);
function Hiw(nQ){
if(nQ==null)return;

up.kU=new EW();


var bC=nQ.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

var Tj=uEP.Zw;
var vN=uEP.GU;
if(Tj==null)Tj="null";
up.kU.Yb(Tj,vN);
}
}

function ju(){nv.call(up);
up.fm=srQ.JGS;

up.pG=null;
up.zK=null;
up.iB=null;
up.kU=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var KRb=new k8L();

KRb.Sj=new VI();
KRb.Sj.tg(up.pG);

if(up.zK!=null&&up.zK.Bt>0){
var rs3=new dC();
rs3.eb(up.zK);
KRb.Ml=rs3;
}

if(up.iB!=null&&up.iB.Bt>0){
var rRr=new dC();
rRr.eb(up.iB);
KRb.kB=rRr;
}

if(up.kU!=null&&up.kU.Bt>0){
var FwV=new dC();
var TXx=up.QEh(up.kU);
FwV.eb(TXx);
KRb.PV=FwV;
}







var EjT=up.PhyZ8();
EjT.fm=srQ.JGS;
EjT.KRb=KRb;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
var xiQ=false;

xiQ=((up.zK!=null)&&(up.zK.Bt>0));

return(xiQ||up.Phy5v());
}

OZ(up,"gyP",Qh6);
function Qh6(){return "GenericEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+";evname="+up.pG;
if(up.zK!=null&&up.zK.Bt>0)
{
nI=nI+";"+up.iRZ("s",up.zK);
}
if(up.iB!=null&&up.iB.Bt>0)
{
nI=nI+";"+up.iRZ("a",up.iB);
}
if(up.kU!=null&&up.kU.Bt>0)
{
nI=nI+";"+up.iRZ("m",up.QEh(up.kU));
}
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(J0C,"J0C");












function Fun(){
var up=this;


if(up!=fj)up.QPz=undefined;

ED(up,"Anr",Nwx);
function Nwx(){return up.QPz;}
Wf(up,"Anr",a9p);
function a9p(nQ){up.QPz=nQ;}


if(up!=fj)up.CPx=undefined;

Wf(up,"Dy9",Ful);
function Ful(nQ){up.CPx=nQ;}

function ju(){nv.call(up);
up.fm=srQ.maU;

up.QPz=0;
up.CPx=OEK.iBj;
}

OZ(up,"yZ8",zDR);
function zDR(){


var Iur=new khJ();
Iur.Anr=up.QPz;
if(up.CPx!=OEK.iBj){
Iur.Dy9=up.CPx;
}






var EjT=up.PhyZ8();
EjT.fm=srQ.maU;
EjT.Iur=Iur;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "InitialBitrateEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";br="+up.QPz;
nI=nI+";avgBrState="+up.CPx;

return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(Fun,"Fun");












function tGb(){
var up=this;


if(up!=fj)up.Iyf=undefined;

ED(up,"lZd",Azi);
function Azi(){return up.Iyf;}
Wf(up,"lZd",uOe);
function uOe(nQ){up.Iyf=nQ;}




if(up!=fj)up.TrP=undefined;

ED(up,"H1",UPq);
function UPq(){return up.TrP;}
Wf(up,"H1",MzQ);
function MzQ(nQ){up.TrP=nQ;}



if(up!=fj)up.T92=undefined;

ED(up,"oFS",z3W);
function z3W(){return up.T92;}
Wf(up,"oFS",BSc);
function BSc(nQ){up.T92=nQ;}

if(up!=fj)up.Mgn=undefined;

ED(up,"bf0",DOE);
function DOE(){return up.Mgn;}
Wf(up,"bf0",JIj);
function JIj(nQ){up.Mgn=nQ;}

if(up!=fj)up.VUV=undefined;

ED(up,"CF2",U1Q);
function U1Q(){return up.VUV;}
Wf(up,"CF2",KBe);
function KBe(nQ){up.VUV=nQ;}

function ju(){nv.call(up);
up.fm=srQ.Dik;

up.Iyf="";
up.TrP=null;
up.T92=null;

up.Mgn=-1;
up.VUV=Q6O.tsU;
}

OZ(up,"yZ8",zDR);
function zDR(){


var mzE=new gdL();
mzE.lZd=new VI();
mzE.lZd.tg(up.Iyf);

if(up.TrP!=null){
mzE.H1=new VI();
mzE.H1.tg(up.TrP);
}

if(up.T92!=null){
mzE.oFS=new VI();
mzE.oFS.tg(up.T92);
}

mzE.bf0=up.Mgn;
mzE.CF2=up.VUV;







var EjT=up.PhyZ8();
EjT.fm=srQ.Dik;
EjT.mzE=mzE;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "InitialResourceEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";rs="+up.Iyf;
if(up.TrP!=null){
nI=nI+";url="+up.TrP;
}
if(up.T92!=null){
nI=nI+";cdnName="+up.T92;
}
nI=nI+";initSrIdx="+up.Mgn;
nI=nI+";initBrFrom="+up.VUV;
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(tGb,"tGb");












function fRx(){
var up=this;

if(up!=fj)up.Hfo=undefined;

ED(up,"rT",yZ);
function yZ(){return up.Hfo;}
Wf(up,"rT",eug);
function eug(nQ){up.Hfo=nQ;}


if(up!=fj)up.AdB=undefined;

ED(up,"LZy",glI);
function glI(){return up.AdB;}
Wf(up,"LZy",T7B);
function T7B(nQ){up.AdB=nQ;}


if(up!=fj)up.z1q=undefined;

ED(up,"co2",FJl);
function FJl(){return up.z1q;}
Wf(up,"co2",jYp);
function jYp(nQ){up.z1q=nQ;}


if(up!=fj)up.ubt=undefined;

ED(up,"QxU",iaC);
function iaC(){return up.ubt;}
Wf(up,"QxU",fmU);
function fmU(nQ){up.ubt=nQ;}


if(up!=fj)up.B9U=undefined;

ED(up,"MNx",CD6);
function CD6(){return up.B9U;}
Wf(up,"MNx",ODY);
function ODY(nQ){up.B9U=nQ;}


if(up!=fj)up.OsL=undefined;

ED(up,"S03",SlQ);
function SlQ(){return up.OsL;}
Wf(up,"S03",yxN);
function yxN(nQ){up.OsL=nQ;}


if(up!=fj)up.TIp=undefined;

ED(up,"cHG",ZYJ);
function ZYJ(){return up.TIp;}
Wf(up,"cHG",jmQ);
function jmQ(nQ){up.TIp=nQ;}

function ju(){nv.call(up);
up.fm=srQ.GRf;

up.Hfo=null;
up.AdB=X6Z.X0O;
up.z1q=null;
up.ubt=null;
up.B9U=X6Z.Ad7;
up.OsL=X6Z.qPU;
up.TIp=X6Z.JOP;
}

OZ(up,"yZ8",zDR);
function zDR(){

var zh3=
new xMA();
if(up.Hfo!=null){
zh3.rT=new VI();
zh3.rT.tg(up.Hfo);
}
zh3.LZy=up.AdB;
if(up.z1q!=null){
zh3.co2=new VI();
zh3.co2.tg(up.z1q);
}
if(up.ubt!=null){
zh3.QxU=new VI();
zh3.QxU.tg(up.ubt);
}
zh3.MNx=up.B9U;
zh3.S03=up.OsL;
zh3.cHG=up.TIp;







var EjT=up.PhyZ8();
EjT.fm=srQ.GRf;
EjT.zh3=zh3;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "IntegrationDetailsEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

if(up.Hfo!=null){
nI=nI+";swcVer="+up.Hfo;
}
if(up.z1q!=null){
nI=nI+";streamAbbr="+up.z1q;
}
if(up.ubt!=null){
nI=nI+";pageUrl="+up.ubt;
}
nI=nI+";"+up.IZg(VW.z_(up.B9U),"LiveOrVod");
nI=nI+";"+up.IZg(VW.z_(up.AdB),"IntegrationType");
nI=nI+";"+up.IZg(VW.z_(up.OsL),"DemsUsage");
nI=nI+";"+up.IZg(VW.z_(up.TIp),"BrSelAlg");

return nI;
}

LK(up,"IZg",czK);
function czK(v9,feP){
if(feP=="IntegrationType"){
if(v9==X6Z.GZI)return "light";
if(v9==X6Z.KFJ)return "full";
if(v9==X6Z.ft)return "unknownIntegrationType";
if(v9==X6Z.X0O)
return "uninitializedIntegrationType";
}

if(feP=="LiveOrVod"){
if(v9==X6Z.Jb0)return "live";
if(v9==X6Z.D2p)return "vod";
if(v9==X6Z.Ad7)
return "uninitializedLiveOrVod";
}

if(feP=="DemsUsage"){
if(v9==X6Z.dWl)return "noDems";
if(v9==X6Z.RFl)return "ems";
if(v9==X6Z.TiT)return "dms";
if(v9==X6Z.Xw5)return "dems";
if(v9==X6Z.qPU)
return "uninitializedDemsUsage";
}

if(feP=="BrSelAlg"){
if(v9==X6Z.O1m)return "defaultBrSelect";
if(v9==X6Z.WHL)return "historyBrSelect";
if(v9==X6Z.cGL)return "noBrSelect";
if(v9==X6Z.JOP)
return "uninitializedBrSelectionAlgorithm";
}

return "";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(fRx,"fRx");












function PEw(){
var up=this;




if(up!=fj)up.q8=undefined;

ED(up,"ca",Ul);
function Ul(){return up.q8;}
Wf(up,"ca",AOi);
function AOi(nQ){up.q8=nQ;}


if(up!=fj)up.Ezg=undefined;

ED(up,"dv",eJ);
function eJ(){return up.Ezg;}
Wf(up,"dv",nDE);
function nDE(nQ){up.Ezg=nQ;}


if(up!=fj)up.fR=undefined;

ED(up,"E8",_X);
function _X(){return up.fR;}
Wf(up,"E8",S55);
function S55(nQ){up.fR=nQ;}


if(up!=fj)up.LSo=undefined;

ED(up,"rp",r9J);
function r9J(){return up.LSo;}
Wf(up,"rp",ag8);
function ag8(nQ){up.LSo=nQ;}


if(up!=fj)up.Kbo=undefined;

ED(up,"LI",iz_);
function iz_(){return up.Kbo;}
Wf(up,"LI",kg1);
function kg1(nQ){up.Kbo=nQ;}



if(up!=fj)up.S07=undefined;

ED(up,"OJp",YtF);
function YtF(){return up.S07;}
Wf(up,"OJp",UAx);
function UAx(nQ){up.S07=nQ;}


if(up!=fj)up.ZOR=undefined;

OZ(up,"BmP",S5F);
function S5F(w6,YwT){
if(up.ZOR==null){
up.ZOR=new Yw();
}

var u3j=new ysh();


if(w6!=null){
u3j.w6=new VI();
u3j.w6.tg(w6);
}

u3j.mRKGw(n4.z_(YwT.Bt));
for(var co=0;co<YwT.Bt;co++){


var oL8=new RJ();
oL8.UE(YwT.tc(co));
u3j.mRKXZ(n4.z_(co),oL8);
}

up.ZOR.Yb(u3j);
return up.ZOR;
}


LK(up,"O7d",G44);
function G44(qLW){
var Oo="null";
if(qLW.w6!=null){
Oo=qLW.w6.T3();
}
var nI="(rs="+Oo;
for(var co=0;co<qLW.mRKXG();co++){
nI=nI+" <err="+qLW.mRKbh(n4.z_(co)).k3;
nI=nI+", cnt="+qLW.mRKbh(n4.z_(co)).Mf;
nI=nI+">,";
}
nI=nI+")";
return nI;
}

function ju(){nv.call(up);
up.fm=srQ.PmG;


up.q8=Ux.CS;
up.Ezg=0;
up.fR=0;
up.LSo=0;
up.Kbo=0;
up.S07=0;
up.ZOR=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var xij=new szi();

if(up.q8!=Ux.CS){
xij.ca=up.q8;
}
if(up.Ezg!=0){
xij.dv=up.Ezg;
}
if(up.fR!=0){
xij.E8=up.fR;
}
if(up.LSo!=0){
xij.rp=up.LSo;
}
if(up.Kbo!=0){
xij.LI=up.Kbo;
}
if(up.S07!=0){
xij.OJp=up.S07;
}
if(up.ZOR!=null&&up.ZOR.Bt>0){
xij.zirGw(n4.z_(up.ZOR.Bt));
for(var co=0;co<up.ZOR.Bt;co++){
xij.zirXZ(n4.z_(co),up.ZOR.tc(co));
}
}







var EjT=up.PhyZ8();
EjT.fm=srQ.PmG;
EjT.xij=xij;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return true;}

OZ(up,"gyP",Qh6);
function Qh6(){return "JoinEndEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";pl="+up.q8;
if(up.Ezg!=0){
nI=nI+";joinTime="+up.Ezg;
}
if(up.fR!=0){
nI=nI+";joinBufTime="+up.fR;
}
if(up.LSo!=0){
nI=nI+";totalPausedTime="+up.LSo;
}
if(up.Kbo!=0){
nI=nI+";totalStoppedTime="+up.Kbo;
}
if(up.S07!=0){
nI=nI+";rsSelectTime="+up.S07;
}
if(up.ZOR!=null&&
up.ZOR.Bt>0){
nI=nI+";"+up.crf("joinRsMeasure",
up.ZOR,
up.O7d);
}

return nI;
}

LK(up,"crf",MKd);
function MKd(L96,xBP,RKA){
var nI=L96+"=[";

var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+RKA(yw)+",";
}
return nI+"]";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(PEw,"PEw");












function YFf(){
var up=this;
function ju(){nv.call(up);
up.fm=srQ.vC7;
}

OZ(up,"yZ8",zDR);
function zDR(){

var EjT=up.PhyZ8();
EjT.fm=srQ.vC7;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "KeepAliveEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(YFf,"YFf");















function fS(){
var up=this;

if(up==fj)fS.Fe=null;





function ju(hy){_U.call(up,hy);
up.wu=_U.WM;

up.dK=new s8(hy.CXF,new EW(),up);
if(up.Gs9()){
fS.Fe=up;
}
}





dN(up,fS,"uY",nA);
function nA(Sj,Ml,kB,PV){
if(fS.Fe==null)return;
var RXG=new J0C();
RXG.Sj=Sj;
RXG.Ml=Ml;
RXG.kB=kB;
RXG.PV=PV;
fS.Fe.FR.UY(RXG);
}




dN(up,fS,"Rb",Bb);
function Bb(Sj,Hb){
if(fS.Fe==null)return;
var RXG=new J0C();
RXG.Sj=Sj;
RXG.kB=Hb;
fS.Fe.FR.UY(RXG);
}



















































if(up!=fj)ju.apply(up,arguments);
}
Bg(fS,"fS");








function fMf(){
var up=this;

if(up!=fj)up.q8=undefined;

ED(up,"ca",Ul);
function Ul(){return up.q8;}
Wf(up,"ca",AOi);
function AOi(nQ){up.q8=nQ;}

function ju(){nv.call(up);
up.ffO=srQ.siE;

up.q8=Ux.Lnh;
}

OZ(up,"yZ8",zDR);
function zDR(){

var x1g=
new vYD();

x1g.ca=up.q8;







var EjT=up.PhyZ8();
EjT.fm=srQ.siE;
EjT.x1g=x1g;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return true;}

OZ(up,"gyP",Qh6);
function Qh6(){return "OtherPlayerStateTransitionEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+";pl="+up.q8;
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(fMf,"fMf");












function fMf(){
var up=this;

if(up!=fj)up.q8=undefined;

ED(up,"ca",Ul);
function Ul(){return up.q8;}
Wf(up,"ca",AOi);
function AOi(nQ){up.q8=nQ;}


if(up!=fj)up.u7Y=undefined;

ED(up,"qsk",pb8);
function pb8(){return up.u7Y;}
Wf(up,"qsk",ThX);
function ThX(nQ){up.u7Y=nQ;}

function ju(){nv.call(up);
up.fm=srQ.siE;

up.q8=Ux.Lnh;
up.u7Y=EmX.Lnh;
}

OZ(up,"yZ8",zDR);
function zDR(){

var x1g=
new vYD();

x1g.ca=up.q8;


if(up.u7Y==EmX.tpF){
x1g.qsk=EmX.tpF;
}







var EjT=up.PhyZ8();
EjT.fm=srQ.siE;
EjT.x1g=x1g;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return true;}

OZ(up,"gyP",Qh6);
function Qh6(){return "OtherPlayerStateTransitionEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+";pl="+up.q8;
if(up.u7Y==EmX.tpF){
nI=nI+";damperSt=damping";
}
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(fMf,"fMf");












function VDv(){
var up=this;

if(up!=fj)up.Xop=undefined;

ED(up,"ouW",Zid);
function Zid(){return up.Xop;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.Xop=nQ;}


if(up!=fj)up.F4Y=undefined;

ED(up,"k3",DwL);
function DwL(){return up.F4Y;}
Wf(up,"k3",cCy);
function cCy(nQ){up.F4Y=nQ;}


if(up!=fj)up.Iyf=undefined;

ED(up,"lZd",Azi);
function Azi(){return up.Iyf;}
Wf(up,"lZd",uOe);
function uOe(nQ){up.Iyf=nQ;}



if(up!=fj)up.oyF=undefined;

ED(up,"szo",PwK);
function PwK(){return up.oyF;}
Wf(up,"szo",u7L);
function u7L(nQ){up.oyF=nQ;}


if(up!=fj)up.m5E=undefined;

ED(up,"D6",eMc);
function eMc(){return up.m5E;}
Wf(up,"D6",ajg);
function ajg(nQ){up.m5E=nQ;}




if(up!=fj)up.u0k=undefined;

ED(up,"xx",de9);
function de9(){return up.u0k;}
Wf(up,"xx",Ume);
function Ume(nQ){up.u0k=nQ;}




if(up!=fj)up.S6k=undefined;

ED(up,"cD",AGO);
function AGO(){return up.S6k;}
Wf(up,"cD",CAt);
function CAt(nQ){up.S6k=nQ;}




if(up!=fj)up.Gej=undefined;

ED(up,"v6K",Rm0);
function Rm0(){return up.Gej;}
Wf(up,"v6K",yBo);
function yBo(nQ){up.Gej=nQ;}


if(up!=fj)up.HSi=undefined;

ED(up,"oEO",uo3);
function uo3(){return up.HSi;}
Wf(up,"oEO",JEw);
function JEw(nQ){up.HSi=nQ;}




if(up!=fj)up.an_=undefined;

ED(up,"ZlP",v3q);
function v3q(){return up.an_;}
Wf(up,"ZlP",ZE8);
function ZE8(nQ){up.an_=nQ;}



if(up!=fj)up.LrE=undefined;

Wf(up,"qdG",nDk);
function nDk(nQ){up.LrE=nQ;}




if(up!=fj)up.QPz=undefined;

ED(up,"Anr",Nwx);
function Nwx(){return up.QPz;}
Wf(up,"Anr",a9p);
function a9p(nQ){up.QPz=nQ;}




if(up!=fj)up.b7q=undefined;

ED(up,"MMC",l46);
function l46(){return up.b7q;}
Wf(up,"MMC",BDs);
function BDs(nQ){up.b7q=nQ;}




if(up!=fj)up.TQx=undefined;

ED(up,"bmB",Pbv);
function Pbv(){return up.TQx;}
Wf(up,"bmB",F54);
function F54(nQ){up.TQx=nQ;}



if(up!=fj)up.TrP=undefined;

ED(up,"H1",UPq);
function UPq(){return up.TrP;}
Wf(up,"H1",MzQ);
function MzQ(nQ){up.TrP=nQ;}

function ju(){nv.call(up);
up.fm=srQ.rAU;

up.F4Y=ky.zx;
up.Iyf=null;
up.oyF=null;
up.m5E=-1;
up.u0k=-1;
up.S6k=-1;
up.Gej=-1;
up.HSi=null;
up.an_=null;
up.LrE=null;
up.QPz=0;
up.b7q=0;
up.TQx=0;
up.TrP=null;
}

OZ(up,"yZ8",zDR);
function zDR(){

var Mp1=new lEc();
Mp1.k3=up.F4Y;
if(up.Iyf!=null){
Mp1.lZd=new VI();
Mp1.lZd.tg(up.Iyf);
}
if(up.oyF!=null){
Mp1.szo=new VI();
Mp1.szo.tg(up.oyF);
}
if(up.an_!=null){
Mp1.ZlP=new VI();
Mp1.ZlP.tg(up.an_);
}
if(up.m5E>=0){
Mp1.D6=up.m5E;
}
if(up.u0k>=0){
Mp1.xx=up.u0k;
}
if(up.S6k>=0){
Mp1.cD=up.S6k;
}
if(up.Gej>=0){
Mp1.v6K=VW.z_(up.Gej);
}
if(up.HSi!=null){
Mp1.oEO=new VI();
Mp1.oEO.tg(up.HSi);
}
if(up.LrE!=null){
Mp1.qdGiy(up.LrE);
}
if(up.QPz>0){
Mp1.Anr=up.QPz;
}
if(up.b7q>0){
Mp1.MMC=up.b7q;
}
if(up.TQx>0){
Mp1.bmB=up.TQx;
}
if(up.TrP!=null){
Mp1.H1=new VI();
Mp1.H1.tg(up.TrP);
}

Mp1.ouW=up.Xop;





var EjT=up.PhyZ8();
EjT.fm=srQ.rAU;
EjT.Mp1=Mp1;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){
if(up.F4Y!=ky.I6)return false;
if(up.an_==up.Iyf)return false;
return true;
}

OZ(up,"gyP",Qh6);
function Qh6(){return "ResourceSwitchEndEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";swId="+up.Xop;
nI=nI+";"+up.J0m(up.F4Y);
if(up.Iyf!=null){
nI=nI+";dRs="+up.Iyf;
}
if(up.an_!=null){
nI=nI+";sRs="+up.an_;
}
if(up.m5E>=0){
nI=nI+";phtD="+up.m5E;
}
if(up.u0k>=0){
nI=nI+";pauseSec="+up.u0k;
}
if(up.Gej>=0){
nI=nI+";rccReason="+up.Gej;
}
if(up.S6k>=0){
nI=nI+";resumeSec="+up.S6k;
}
if(up.HSi!=null){
nI=nI+";switchTrace=("+up.HSi+")";
}
if(up.TrP!=null){
nI=nI+";url="+up.TrP;
}
return nI;
}

LK(up,"J0m",ArE);
function ArE(EU){
switch(EU){
case ky.I6:
return "success";
case ky.zx:
return "unfinished";
case ky.hO:
return "failed";
case ky.BS:
return "interrupted";
default:
return "";
}
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(VDv,"VDv");












function e7H(){
var up=this;

if(up!=fj)up.Xop=undefined;

ED(up,"ouW",Zid);
function Zid(){return up.Xop;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.Xop=nQ;}


if(up!=fj)up.oyF=undefined;

ED(up,"szo",PwK);
function PwK(){return up.oyF;}
Wf(up,"szo",u7L);
function u7L(nQ){up.oyF=nQ;}



if(up!=fj)up.Gej=undefined;

ED(up,"v6K",Rm0);
function Rm0(){return up.Gej;}
Wf(up,"v6K",yBo);
function yBo(nQ){up.Gej=nQ;}


if(up!=fj)up.pnf=undefined;

ED(up,"KdP",bLn);
function bLn(){return up.pnf;}
Wf(up,"KdP",Xw3);
function Xw3(nQ){up.pnf=nQ;}


if(up!=fj)up.JSd=undefined;

ED(up,"dI0",sDE);
function sDE(){return up.JSd;}

OZ(up,"spj",EzE);
function EzE(jN){
if(jN!=null){
var bC=jN.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var co=bC[Jo];

var nh=new njx();
nh.AIg=co;
up.JSd.Yb(nh);
}
}
return up.JSd;
}



if(up!=fj)up.an_=undefined;

ED(up,"ZlP",v3q);
function v3q(){return up.an_;}
Wf(up,"ZlP",ZE8);
function ZE8(nQ){up.an_=nQ;}


if(up!=fj)up.Ssq=undefined;

ED(up,"GOb",TXX);
function TXX(){return up.Ssq;}
Wf(up,"GOb",WFn);
function WFn(nQ){
up.Ssq=nQ;
if(up.Ssq!=-1){
up.b88("phtD",up.Ssq);
}else{
up.PWx("phtD");
}
}



if(up!=fj)up.LrE=undefined;

Wf(up,"qdG",nDk);
function nDk(nQ){up.LrE=nQ;}




if(up!=fj)up.b7q=undefined;

ED(up,"MMC",l46);
function l46(){return up.b7q;}
Wf(up,"MMC",BDs);
function BDs(nQ){up.b7q=nQ;}




if(up!=fj)up.TQx=undefined;

ED(up,"bmB",Pbv);
function Pbv(){return up.TQx;}
Wf(up,"bmB",F54);
function F54(nQ){up.TQx=nQ;}

function ju(){nv.call(up);
up.fm=srQ.Vz8;

up.oyF=null;
up.Gej=ky.Gg;
up.pnf=UN.FSb;
up.JSd=new Yw();
up.an_=null;
up.Ssq=-1;
up.LrE=null;
up.b7q=0;
up.TQx=0;
}

OZ(up,"yZ8",zDR);
function zDR(){

var rGb=
new bOB();

if(up.oyF!=null){
rGb.szo=new VI();
rGb.szo.tg(up.oyF);
}

if(up.an_!=null){
rGb.ZlP=new VI();
rGb.ZlP.tg(up.an_);
}

if(up.Gej>=0){
rGb.v6K=up.Gej;
}

if(up.LrE!=null){
rGb.qdGiy(up.LrE);
}

if(up.Gej==ky.Gg){
rGb.KdP=up.pnf;
if(up.JSd!=null&&up.JSd.Bt>0){
rGb.dI0Gw(n4.z_(up.JSd.Bt));
for(var co=0;co<up.JSd.Bt;co++){
var nh=new njx();
nh.AIg=up.JSd.tc(co).AIg;
rGb.dI0XZ(n4.z_(co),nh);
}
}
}

if(up.b7q>0){
rGb.MMC=up.b7q;
}
if(up.TQx>0){
rGb.bmB=up.TQx;
}

rGb.ouW=up.Xop;





var EjT=up.PhyZ8();
EjT.fm=srQ.Vz8;
EjT.rGb=rGb;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "ResourceSwitchStartEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";swId="+up.Xop;
nI=nI+";dRs="+up.oyF;
nI=nI+";sRs="+up.an_;
nI=nI+";rccReason="+up.Gej;
if(up.Gej==ky.Gg){
nI=nI+";type="+up.pnf;
if(up.JSd!=null&&up.JSd.Bt>0){
nI=nI+";"+up.FH4("cause",
up.JSd);
}
}
return nI;
}

LK(up,"FH4",ysw);
function ysw(L96,xBP){
var nI=L96+"=[";
var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yw=bC[Jo];


nI=nI+","+yw.AIg;
}
return nI+"]";
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(e7H,"e7H");












function nv(){
var up=this;

if(up==fj)nv.Za2="eUrlTrace";
if(up==fj)nv.nUJ="eConnTime";
if(up==fj)nv.mSE="eProtocol";
if(up==fj)nv.Xvl="ePort";
if(up==fj)nv.rEm="eBufTime";
if(up==fj)nv.zzV="sw.ak.succ";
if(up==fj)nv.qD1="sw.ak.fail";
if(up==fj)nv.Ou1="vResChanged";
if(up==fj)nv.z5f="vSizeChanged";
if(up==fj)nv.l4q="regressionDec";
if(up==fj)nv.h3o="c3.oldConfig";
if(up==fj)nv.DEW="eNetStreamInfoTimeout";
if(up==fj)nv.teo="eMetadataFps";
if(up==fj)nv.YUA="ePlayComplete";
if(up==fj)nv.uKJ="eInitTime";
if(up==fj)nv.FPA="slsi";
if(up==fj)nv.yFZ="slmi";
if(up==fj)nv.f7I="eLpCacheSt";

if(up==fj)nv.niT="eMetadataStreamerInfo";



if(up!=fj)up.kRu=undefined;

ED(up,"XM8",P6_);
function P6_(){return up.kRu;}
Wf(up,"XM8",e8E);
function e8E(nQ){
if(up.Rfi)return;
up.kRu=nQ;
}


if(up!=fj)up.Pm=undefined;

ED(up,"Nm",aMC);
function aMC(){return up.Pm;}
Wf(up,"Nm",pf3);
function pf3(nQ){
if(up.Rfi)return;
up.Pm=nQ;
}


if(up!=fj)up.cY=undefined;

ED(up,"cO",Klu);
function Klu(){return up.cY;}
Wf(up,"cO",Jgy);
function Jgy(nQ){
if(up.Rfi)return;
up.cY=nQ;
}




if(up!=fj)up.yC4=undefined;

ED(up,"Ky",g2o);
function g2o(){return up.yC4;}
Wf(up,"Ky",yoq);
function yoq(nQ){
if(up.Rfi)return;
up.yC4=nQ;
}


if(up!=fj)up.WqM=undefined;

ED(up,"iFM",kA8);
function kA8(){return up.WqM;}
Wf(up,"iFM",Gjk);
function Gjk(nQ){
if(up.Rfi)return;
up.WqM=nQ;
}


if(up!=fj)up.IJ=undefined;

ED(up,"OE",pR2);
function pR2(){return up.IJ;}
Wf(up,"OE",hkw);
function hkw(nQ){
if(up.Rfi)return;
up.IJ=nQ;
}





if(up!=fj)up.ffO=undefined;

ED(up,"fm",qOl);
function qOl(){return up.ffO;}
Wf(up,"fm",gbj);
function gbj(nQ){
if(up.Rfi)return;
up.ffO=nQ;


if(up.cLZ==jqN.omh){
up.cLZ=jqN.xRO(up.ffO);
}
}




if(up!=fj)up.cLZ=jqN.omh;

ED(up,"wii",DuO);
function DuO(){return up.cLZ;}
Wf(up,"wii",a7w);
function a7w(nQ){
if(up.Rfi)return;
up.cLZ=nQ;
}



if(up!=fj)up.Bkj=-1;

ED(up,"ubW",EFn);
function EFn(){return up.Bkj;}
Wf(up,"ubW",Y1X);
function Y1X(nQ){
if(up.Rfi)return;
up.Bkj=nQ;
}





if(up!=fj)up.Zqd=undefined;
OZ(up,"WbK",J07);
function J07(_j){
if(up.Rfi)return;
up.Zqd=_j;
if(up.EPZ!=null)
up.fey(up.EPZ);
if(up.l7o!=null)
up.fey(up.l7o);
}


OZ(up,"fey",Yrc);
function Yrc(aq){

var lr=new Yw();
var Tj=null;
var vN=null;



var bC=aq.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

Tj=uEP.Zw;
vN=uEP.GU;
if(vN.length>up.Zqd){
lr.Yb(Tj);
}
}


var HH=lr.YC;
for(var wt=0;wt<HH.length;wt++){
var G2=HH[wt];

vN=aq.tc(G2);
aq.a9(G2,oL.n0(vN,0,up.Zqd));
}
return aq;
}









if(up!=fj)up.EPZ=undefined;

ED(up,"sWk",_BZ);
function _BZ(){return up.EPZ;}
Wf(up,"sWk",EcD);
function EcD(nQ){
if(nQ==null||up.Rfi)return;
up.EPZ=new EW();
if(up.EPZ!=null){
var bC=nQ.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

var Tj=uEP.Zw;
var vN=uEP.GU;
if(Tj==null)Tj="null";
if(vN==null)vN="null";
up.EPZ.Yb(Tj,vN);
}
}
}


if(up!=fj)up.l7o=undefined;

ED(up,"E_B",trD);
function trD(){return up.l7o;}
Wf(up,"E_B",YuO);
function YuO(nQ){
if(nQ==null||up.Rfi)return;
up.l7o=new EW();
if(up.l7o!=null){
var bC=nQ.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

var Tj=uEP.Zw;
var vN=uEP.GU;
if(Tj==null)Tj="null";
if(vN==null)vN="null";
up.l7o.Yb(Tj,vN);
}
}
}


if(up!=fj)up.bGi=undefined;

OZ(up,"b88",uxQ);
function uxQ(Tj,nQ){
if(up.Rfi)return;
if(up.bGi==null){
up.bGi=new EW();
}
var O3T=((Tj!=null)?Tj:"null");
up.bGi.a9(O3T,nQ);
}

OZ(up,"PWx",ug2);
function ug2(Tj){
if(up.Rfi)return;
if(up.bGi==null){
return;
}
var O3T=((Tj!=null)?Tj:"null");
if(up.bGi.Wt(O3T)){
up.bGi.gS(O3T);
}
if(up.bGi.Bt==0){
up.bGi=null;
}
}


if(up!=fj)up.nWv=undefined;

ED(up,"bsD",HJp);
function HJp(){return up.nWv;}
Wf(up,"bsD",x96);
function x96(nQ){
if(up.Rfi)return;
up.nWv=nQ;
}




if(up!=fj)up.E5M=undefined;

ED(up,"Rfi",DRh);
function DRh(){return up.E5M;}
Wf(up,"Rfi",dCm);
function dCm(nQ){up.E5M=nQ;}






OZ(up,"UV6",Gg2);
function Gg2(Wv_){

O9.y8(up.Pm==Wv_.Nm,"exporting gatewayWallTimeMs to the right place");

if(oL.fFw(up.nWv)>=0){
Wv_.bsD=up.nWv;
}
}

function ju(){
up.Pm=-1;
up.cY=-1;
up.yC4=-1;
up.WqM=false;
up.IJ=-1;
up.Zqd=-1;
up.EPZ=null;
up.l7o=null;
up.bGi=null;
up.Bkj=-1;
up.nWv=L_.Ho(-1);
up.E5M=false;
}

OZ(up,"yZ8",zDR);
function zDR(){
var EjT=new sYs();

EjT.Nm=up.Pm;
EjT.cO=up.cY;
EjT.Ky=up.yC4;
EjT.iFM=up.WqM;
if(up.WqM&&up.Bkj>=0){
EjT.TU1=up.Bkj;
}
if(up.WqM&&up.IJ>=0){
EjT.OE=up.IJ;
}

if(up.EPZ!=null&&up.EPZ.Bt>0){
var rs3=new dC();
rs3.eb(up.EPZ);
EjT.sWk=rs3;
}
if(up.l7o!=null&&up.l7o.Bt>0){
var rRr=new dC();
rRr.eb(up.l7o);
EjT.E_B=rRr;
}
if(up.bGi!=null&&up.bGi.Bt>0){
var FwV=new dC();
var Fbv=up.QEh(up.bGi);
FwV.eb(Fbv);
EjT.zuh=FwV;
}

return EjT;
}




OZ(up,"QEh",mb0);
function mb0(wGW){
var nf5=new EW();
var bC=wGW.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

nf5.Yb(uEP.Zw,oL.fg(uEP.GU));
}
return nf5;
}






OZ(up,"y5v",Xnz);
function Xnz(){
return(up.EPZ!=null&&up.EPZ.Bt>0);
}


OZ(up,"gyP",Qh6);
function Qh6(){return "";}


OZ(up,"vo",Ua);
function Ua(){
var nI=up.gyP()+" ("+up.Pm+"/"+up.cY+") ";
if(up.Bkj>=0){
nI=nI+";avgBr="+up.Bkj;
}
if(up.EPZ!=null&&up.EPZ.Bt>0){
nI=nI+";"+up.iRZ("piggyStates",up.EPZ);
}
if(up.l7o!=null&&up.l7o.Bt>0){
nI=nI+";"+up.iRZ("piggyAttributes",up.l7o);
}
if(up.bGi!=null&&up.bGi.Bt>0){
nI=nI+";"+up.iRZ("piggyMeasurements",up.QEh(up.bGi));
}
return nI;
}



OZ(up,"iRZ",fvj);
function fvj(L96,aq){
var nI=L96+"=[";
var bC=aq.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var uEP=bC[Jo];

nI=nI+"("+uEP.Zw+"="+uEP.GU+")";
}
return nI+"]";
}



















if(up!=fj)ju.apply(up,arguments);
}
Bg(nv,"nv");





















function jqN(){
var up=this;
if(up==fj)jqN.omh=0;
if(up==fj)jqN.viv=1;
if(up==fj)jqN.Lp5=2;

if(up==fj)jqN.yqJ=3;


if(up==fj)jqN.Ijy=0.01;


if(up==fj)jqN.uZt=null;


if(up==fj)jqN.yil=null;




dN(up,jqN,"nr",kP);
function kP(){

jqN.uZt=new EW();


jqN.uZt.a9(srQ.DmE,jqN.yqJ);
jqN.uZt.a9(srQ.vC7,jqN.yqJ);
jqN.uZt.a9(srQ.wCS,jqN.yqJ);

jqN.uZt.a9(srQ.XGF,jqN.yqJ);


jqN.uZt.a9(srQ.Wjg,jqN.Lp5);
jqN.uZt.a9(srQ.maU,jqN.Lp5);
jqN.uZt.a9(srQ.Dik,jqN.Lp5);
jqN.uZt.a9(srQ.GRf,jqN.Lp5);
jqN.uZt.a9(srQ.PmG,jqN.Lp5);
jqN.uZt.a9(srQ.c9Y,jqN.Lp5);
jqN.uZt.a9(srQ.UmY,jqN.viv);
jqN.uZt.a9(srQ.yku,jqN.viv);


jqN.uZt.a9(srQ.Vz8,jqN.viv);
jqN.uZt.a9(srQ.rAU,jqN.viv);
jqN.uZt.a9(srQ.Dzm,jqN.viv);
jqN.uZt.a9(srQ.dlm,jqN.viv);
jqN.uZt.a9(srQ.E99,jqN.viv);
jqN.uZt.a9(srQ.siE,jqN.viv);
jqN.uZt.a9(srQ.sIo,jqN.viv);
jqN.uZt.a9(srQ._bg,jqN.viv);
jqN.uZt.a9(srQ.Fmw,jqN.viv);

jqN.uZt.a9(srQ.JGS,jqN.viv);


jqN.yil=new EW();
jqN.yil.a9(nv.uKJ,jqN.yqJ);
jqN.yil.a9(nv.FPA,jqN.yqJ);
jqN.yil.a9(nv.yFZ,jqN.yqJ);


jqN.yil.a9(nv.Za2,jqN.Lp5);
jqN.yil.a9(nv.f7I,jqN.Lp5);


jqN.yil.a9(nv.nUJ,jqN.viv);
jqN.yil.a9(nv.mSE,jqN.viv);
jqN.yil.a9(nv.Xvl,jqN.viv);
jqN.yil.a9(nv.rEm,jqN.viv);
jqN.yil.a9(nv.zzV,jqN.viv);
jqN.yil.a9(nv.qD1,jqN.viv);
jqN.yil.a9(nv.Ou1,jqN.viv);
jqN.yil.a9(nv.z5f,jqN.viv);
jqN.yil.a9(nv.l4q,jqN.viv);
jqN.yil.a9(nv.h3o,jqN.viv);
}


dN(up,jqN,"xRO",i9h);
function i9h(fm){
if(jqN.uZt==null)
{
jqN.nr();
}

if(jqN.uZt.Wt(fm)){
return jqN.uZt.tc(fm);
}else{

if(O9.rV()<jqN.Ijy){
SH.z2("priority of event type "+fm+" is not definied");
}
return jqN.omh;
}
}


dN(up,jqN,"yoi",Nbh);
function Nbh(Sp){
if(jqN.yil==null)
{
jqN.nr();
}
if(Sp!=null&&jqN.yil.Wt(Sp)){
return jqN.yil.tc(Sp);
}else{



return jqN.viv;
}
}





}
Bg(jqN,"jqN");












function _A(){
var up=this;


if(up!=fj)up.CI=null;
















if(up!=fj)up.Yt3=null;





if(up!=fj)up.wHf=false;







function ju(Sj,vX,KP){s8.call(up,Sj,vX,KP);
up.CI=KP;
up.Yt3=new tm8(up.pV);
up.wHf=false;
up.xi=true;
}

OZ(up,"wy",NQ);
function NQ(){
up.Phwy();
up.CI=null;
up.Yt3.m3();
up.wHf=false;
}

OZ(up,"yr",hT);
function hT(y_){
up.Phyr(y_);
up.wHf=true;
}

OZ(up,"UZN",KPF);
function KPF(){
if(up.CI==null||up.CI.R2==null){
return;
}

var hlD=new jcl();

up.CI.R2.gd(
M24.vn5,hlD);

up.UY(hlD);
}






OZ(up,"OE",F7);
function F7(){
if(up.CI==null){
return-1;
}
return VW.z_(up.CI.Af);
}





OZ(up,"mqI",rYp);
function rYp(){
if(up.CI!=null&&up.CI.R2!=null){
return(up.CI.R2.yir());
}else{
return false;
}
}





OZ(up,"x_L",cw4);
function cw4(){
if(up.mqI()){
var lvu=up.EtK();
if(lvu!=null){
up.UY(lvu);
return true;
}
}
return false;
}

OZ(up,"Ll",xG);
function xG(kIV,y4){


if(up.CI.R2.NR!=Ez.cz
&&(y4||kIV)){
return true;
}else{
return false;
}
}



LK(up,"EtK",vg0);
function vg0(){
if(up.CI!=null&&up.CI.R2!=null){
var lvu=new ddL();
up.CI.R2.Nce(lvu);
return lvu;
}else{
return null;
}
}





OZ(up,"MoD",bCU);
function bCU(){
if(up.CI!=null&&up.CI.R2!=null){
var dHu=up.jEO.Bt-1;
up.jEO.tc(dHu).ubW=up.CI.R2.aGW();
}
}












OZ(up,"ylf",XEr);
function XEr(){
var v76=false;
if(!up.wHf){
var bC=up.Yt3.L4r().YC;
for(var Jo=0;Jo<bC.length;Jo++){
var hv=bC[Jo];

ct.qF("SDM["+up.Pt.Bl+"]",
"Repeating unreceived SDM event \""+hv.gyP()+"\": ["+hv.vo()+"]");
up.UY(hv);
v76=true;
}
}
up.Yt3.m3();
return v76;
}





OZ(up,"HR7",WSR);
function WSR(T9Q){
up.Yt3.m3();
var bC=T9Q.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var hv=bC[Jo];

up.Yt3.Yb(hv);
}
return;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(_A,"_A");



















function s8(){
var up=this;


if(up!=fj)up.Pt=null;





if(up!=fj)up.xi=false;

if(up!=fj)up.XV=0;

if(up!=fj)up.Qi=0;

if(up!=fj)up.FJ=0;




if(up!=fj)up.jEO=null;





if(up!=fj)up.kHj=null;

if(up!=fj)up.Wo=null;


if(up!=fj)up.z4=undefined;

if(up!=fj)up.pG=undefined;



if(up!=fj)up.rP6=undefined;


if(up!=fj)up.M47=undefined;

if(up!=fj)up.ZE=undefined;

if(up!=fj)up.i2M=undefined;

if(up!=fj)up.Gnf=undefined;


if(up!=fj)up.vj=undefined;

if(up!=fj)up.jX=1/(oL.fFw(zY.Iw));

if(up!=fj)up.IG=oL.fFw(zY.CA);



if(up!=fj)up.sG=undefined;

if(up!=fj)up.bo=undefined;

if(up!=fj)up.Xz=undefined;

if(up!=fj)up.EV=undefined;

if(up!=fj)up.yq=undefined;


if(up!=fj)up.zf=0;
if(up!=fj)up.sd=0;
if(up!=fj)up.z5=0;
if(up!=fj)up.td=0;
if(up!=fj)up.bAR=0;
if(up!=fj)up.zT=0;
if(up!=fj)up.Y1=0;


if(up!=fj)up.uuB=false;




if(up!=fj)up.pV=0;



ED(up,"bL",a4);
function a4(){return up.pG;}



if(up!=fj)up.SxH=false;

if(up!=fj)up.D2N=undefined;

if(up!=fj)up.bi_=false;

if(up!=fj)up.w4p=null;


if(up!=fj)up.Sgh=null;







function ju(Sj,vX,KP){

up.pV=Lt.VB();
up.pG=Sj;
up.Pt=KP;
up.jEO=new Yw();
up.kHj=new G5J();
up.Wo=new EW();
up.xi=false;


if(vX!=null){
var bC=vX.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var T9=bC[Jo];

up.Wo.Yb(T9.Zw,T9.GU);
}
}



var z1=Lt.VB()/1000;
up.vj=new qC(up.jX,up.IG,z1);


up.rP6=0;
up.M47=0;
up.ZE=zY.g4M;
up.i2M=VW.z_(zY.H3P);
up.Gnf=VW.z_(zY.K1q);

up.Sgh=up.Hx;
CO.el().Zu(up.Sgh);
up.ze(true);
}


OZ(up,"wy",NQ);
function NQ(){
up.ta_();
up.kHj.m3();
if(up.Sgh!=null){
CO.el().fA(up.Sgh);
up.Sgh=null;
}
up.Pt=null;
}




OZ(up,"UY",QW);
function QW(nzH){
if(up.NLn(nzH)){
nzH.Ky=hR.SI(up.pV,Lt.VB());
nzH.bsD=L_.Ho(Tp.Flu());
nzH.OE=up.OE();

up.kHj.Yb(nzH);
}
}




OZ(up,"rRM",QxV);
function QxV(nzH){
up.kHj.OlJ(nzH);
}











OZ(up,"yr",hT);
function hT(y_){
return;
}


OZ(up,"NLn",SpC);
function SpC(nzH){
if(up.Pt.Gs9()&&
(nzH.fm==srQ.JGS)){
var RXG=nzH;

var Sj=RXG.Sj;
var Ml=RXG.Ml;
var kB=RXG.kB;
var PV=RXG.PV;

if(up.K3(Sj,Ml,kB,PV)==false){
return false;
}
}
return true;
}






OZ(up,"Ify",I1x);
function I1x(){
if(up.kHj==null){
return;
}


up.kHj.H_3(up.vj);

var bC=up.kHj.JST.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var hmt=bC[Jo];


up.PpL(hmt);
}

if(up.kHj.ejQ>0){
up.zf+=up.kHj.ejQ;
up.uuB=true;
}

up.kHj.m3();

if(up.uuB){
up.mHm();
}
}

OZ(up,"PpL",gw7);
function gw7(nzH){
up.QSX(nzH);

up.jEO.Yb(nzH);
ct.qF("SDM["+up.Pt.Bl+"]",
"Preparing to send SDM event \""+nzH.gyP()+"\": ["+nzH.vo()+"]");
}

LK(up,"QSX",wUf);
function wUf(nzH){



if(!nzH.Rfi){

++up.Qi;
nzH.Nm=up.Qi;


if(nzH.y5v()){
++up.FJ;
}
nzH.cO=up.FJ;


nzH.iFM=up.xi;


nzH.WbK(VW.z_(up.Xz));
}
}

OZ(up,"K3",pj);
function pj(Sj,Ml,kB,PV){

var bR=0;
var pR=0;
var hsM=false;
var cbn=false;
var an=false;
var tk=false;
var rB=0;
var Hf=0;
var Ii=true;
var _W=undefined;

if((Sj==null)||((Sj!=null)&&(Sj.length==0))){
bR++;
Ii=false;
}

if((Sj!=null)&&(Sj.length>up.sG)){
pR++;
Ii=false;
}

if(Ml!=null){
var bC=Ml.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var sp=bC[Jo];

_W=sp.Zw;
if((_W!=null)&&(_W.length>up.bo)){
hsM=true;
Ii=false;
}
_W=sp.GU;
if(_W!=null){
if(_W.length>up.Xz){



cbn=true;
Hf+=up.Xz;
}else{
Hf+=n4.z_(_W.length);
}
}
rB++;
}
}

if(kB!=null){
var HH=kB.GA;
for(var wt=0;wt<HH.length;wt++){
var sP=HH[wt];

_W=sP.Zw;
if((_W!=null)&&(_W.length>up.bo)){
hsM=true;
Ii=false;
}
_W=sP.GU;
if(_W!=null){
if(_W.length>up.Xz){



cbn=true;
Hf+=up.Xz;
}else{
Hf+=n4.z_(_W.length);
}
}
rB++;
}
}

if(PV!=null){
var jk=PV.GA;
for(var jB=0;jB<jk.length;jB++){
var Eb=jk[jB];

_W=Eb.Zw;
if((_W!=null)&&(_W.length>up.bo)){
hsM=true;
Ii=false;
}
rB++;
}
}

if(Hf>up.EV){
an=true;
Ii=false;
}

if(rB>up.yq){
tk=true;
Ii=false;
}

up.sd+=bR;
up.z5+=pR;


if(hsM==true){
up.td+=1;
}
if(cbn==true){
up.bAR+=1;
}
if(an==true){
up.zT+=1;
}
if(tk==true){
up.Y1+=1;
}

if(Ii==false){
up.uuB=true;
}

return Ii;
}

OZ(up,"Ll",xG);
function xG(kIV,y4){

return false;
}





OZ(up,"yJ",Cs);
function Cs(v9L,y4){
up.z4="";
var VN="";
var cN=undefined;




var tnc=up.bi_;
var yRV=up.rEd(tnc);
var t69=up.F18(tnc);




if(!tnc&&v9L&&!y4&&up.rP6<yRV){
++up.rP6;
return null;
}


up.rP6=0;

if(up.Ll(up.QvW(t69),y4)){

up.z4+="(active - send checkpoint)";
up.UZN();
up.M47=0;
}else{

if(!up.Pt.Gs9()){
++up.M47;
}
}



var vGF=up.x_L();


var sj1=up.ylf();




if(tnc&&up.M47!=0&&!vGF){
up.z4+="(active - keep alive)";
up.TwY();
}

cN=up.Mo(tnc,sj1);

if(cN!=null){

cN.oe=up.XV;
up.XV++;




up.HR7(up.jEO);

up.z4=((up.z4!="")?up.z4:"(active - send HB)");

VN=VN+"Creating SDM heartbeat #"+(up.XV)+" for session "+up.bL+" "+up.z4;

VN+=" (with events: ";
var bC=up.jEO.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var sU=bC[Jo];

VN+="["+sU.gyP()+" "+sU.vo()+"], ";
}
VN+=")";

ct.qF("SDM["+up.Pt.Bl+"]",VN);
up.jEO.m3();
}

return cN;
}

OZ(up,"UZN",KPF);
function KPF(){}




OZ(up,"mHm",ph6);
function ph6(){
var EU=false;
if(up.uuB==false){

return;
}

var eSR=new nT5();


eSR.Ky=hR.SI(up.pV,Lt.VB());
eSR.bsD=L_.Ho(Tp.Flu());
eSR.OE=up.OE();

if(up.zf>0){
eSR.R7p=up.zf;
up.zf=0;
EU=true;
}
if(up.sd>0){
eSR.BZA=VW.z_(up.sd);
up.sd=0;
EU=true;
}
if(up.z5>0){
eSR.fWb=VW.z_(up.z5);
up.z5=0;
EU=true;
}
if(up.td>0){
eSR.fK=VW.z_(up.td);
up.td=0;
EU=true;
}
if(up.bAR>0){
eSR.yTl=VW.z_(up.bAR);
up.bAR=0;
EU=true;
}
if(up.zT>0){
eSR.gAc=VW.z_(up.zT);
up.zT=0;
EU=true;
}
if(up.Y1>0){
eSR.ifs=VW.z_(up.Y1);
up.Y1=0;
EU=true;
}
if(EU){
up.PpL(eSR);
}
up.uuB=false;
}

LK(up,"Mo",gM);
function gM(tnc,B95){

up.Ify();


if(up.jEO==null||up.jEO.Bt==0)return null;


if(tnc){
up.MoD();
}

var KP=new QR();
KP.GD=L_.Ho(up.Pt.IW);
KP.j_=up.Pt.NT;

KP.YH2Gw(n4.z_(up.jEO.Bt));
for(var co=0;co<up.jEO.Bt;co++){
var sU=up.jEO.tc(co);
var Wv_=sU.yZ8();





if(co==0&&!B95){
sU.UV6(Wv_);
}

KP.YH2XZ(n4.z_(co),Wv_);



sU.Rfi=true;
}

return KP;
}



LK(up,"ta_",SiL);
function SiL(){
if(up.w4p!=null){
up.w4p.wy();
up.w4p=null;
}
up.bi_=false;
}

LK(up,"TwY",hEA);
function hEA(){
var ss_=new YFf();
up.UY(ss_);
}


LK(up,"VC",wR);
function wR(Ml){
if(Ml==null){
return;
}
var bC=Ml.GA;
for(var Jo=0;Jo<bC.length;Jo++){
var T9=bC[Jo];

if(!up.Wo.Wt(T9.Zw)){
up.Wo.Yb(T9.Zw,T9.GU);
}else{
up.Wo.a9(T9.Zw,T9.GU);
}
}
}


OZ(up,"MoD",bCU);
function bCU(){}






OZ(up,"OE",F7);
function F7(){
return-1;
}

LK(up,"Hx",aP);
function aP(){
up.ze(false);
}




LK(up,"ze",Qn);
function Qn(Ns){
if(up.Pt==null){
return;
}
var pn=CO.el();
var kz=Lt.VB()/1000;

up.ZE=pn.Yo;
up.i2M=VW.z_(pn.J7("sdmHbIntervalMs","value",zY.H3P));
up.Gnf=VW.z_(pn.J7("checkpointIntervalMs","value",zY.K1q));

if(!up.PHw(up.ZE,up.i2M,up.Gnf)){


up.i2M=VW.z_(zY.H3P);
up.Gnf=VW.z_(zY.K1q);


if(Ns){
up.Knk();
}
}


if(up.Pt.Gs9()){
up.jX=1/(oL.fFw(pn.J7("externalEventTokenBucketIntervalSec","value",zY.pI)));
up.IG=oL.fFw(pn.J7("externalEventTokenBucketDepth","value",zY.E3));


up.sG=pn.J7("externalEventNameMaxLen","value",zY.Cg);
up.bo=pn.J7("externalEventKeyMaxLen","value",zY.MQ);
up.Xz=pn.J7("externalEventValMaxLen","value",zY.Kv);
up.EV=pn.J7("externalEventTotalValLenMaxLen","value",zY._n);
up.yq=pn.J7("externalEventNumEntriesMaxCount","value",zY.Vy);
}else{
up.jX=1/(oL.fFw(pn.J7("internalEventTokenBucketIntervalSec","value",zY.Iw)));
up.IG=oL.fFw(pn.J7("internalEventTokenBucketDepth","value",zY.CA));


up.sG=pn.J7("internalEventNameMaxLen","value",zY.ZP);
up.bo=pn.J7("internalEventKeyMaxLen","value",zY.c8);
up.Xz=pn.J7("internalEventValMaxLen","value",zY.ck);
up.EV=pn.J7("internalEventTotalValLenMaxLen","value",zY.lI);
up.yq=pn.J7("internalEventNumEntriesMaxCount","value",zY.M1);
}


up.SxH=pn.mSk;
up.D2N=pn.ZVW;

if(Ns){

up.vj.nr(up.jX,up.IG,kz);



if(!up.Pt.Gs9()){

up.ta_();


if(up.SxH){
up.bi_=true;
up.w4p=new Lt(up.D2N*1000,up.ta_,"SDMTransport.stopKeepAliveEvent");
}
}

up.vSP();
}else{
up.vj.qv(up.jX,up.IG,kz);
}
}



LK(up,"rEd",Z18);
function Z18(fap){
var zb0=(fap?up.ZE:up.i2M);
return zb0/up.ZE-1;
}



LK(up,"F18",aNL);
function aNL(fap){
var zb0=(fap?up.ZE:up.i2M);
return up.Gnf/zb0-1;
}




LK(up,"vSP",CBJ);
function CBJ(){
var oGx=undefined;



oGx=Math.max(up.rEd(true),up.rEd(false));
up.rP6=oGx+1;


oGx=Math.max(up.F18(true),up.F18(false));
up.M47=oGx+1;
}



OZ(up,"ho_",At);
function At(){
up.vSP();
}



LK(up,"PHw",Ajd);
function Ajd(Bns,CA5,Av5){
if(Bns==0||CA5%Bns!=0)return false;
if(CA5==0||Av5%CA5!=0)return false;
return true;
}


LK(up,"Knk",xCF);
function xCF(){

var QxQ=O9.rV();

if(s8.g3j||(QxQ>=0.0&&QxQ<0.01)){
SH.z2("sdmHbIntervalMs or checkpointIntervalMs are incorrectly configured.");
s8.XcM=true;
}
}



OZ(up,"QvW",lxy);
function lxy(t69){
return(up.M47>=t69);
}





OZ(up,"mqI",rYp);
function rYp(){
return false;
}





OZ(up,"x_L",cw4);
function cw4(){return false;}




OZ(up,"ylf",XEr);
function XEr(){
return false;
}





OZ(up,"HR7",WSR);
function WSR(T9Q){
return;
}




if(up==fj)s8.XcM=false;
if(up==fj)s8.g3j=false;

OZ(up,"obV",Ems);
function Ems(){
return up.bi_;
}
if(up!=fj)up.btmXG=0;



OZ(up,"T3d",Tav);
function Tav(wii){
var nzH=new nv();
nzH.wii=wii;

var E_B=new EW();
E_B.Yb("origSeqNumber",oL.fg((up.btmXG)));
up.btmXG++;
E_B.Yb("priority",oL.fg(wii));
nzH.E_B=E_B;
up.UY(nzH);
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(s8,"s8");












function nT5(){
var up=this;

if(up!=fj)up.F0e=undefined;

ED(up,"R7p",H3s);
function H3s(){return up.F0e;}
Wf(up,"R7p",BAb);
function BAb(nQ){up.F0e=nQ;}


if(up!=fj)up.pEx=undefined;

ED(up,"fWb",Qgk);
function Qgk(){return up.pEx;}
Wf(up,"fWb",Pro);
function Pro(nQ){up.pEx=nQ;}


if(up!=fj)up.oIg=undefined;

ED(up,"BZA",nrf);
function nrf(){return up.oIg;}
Wf(up,"BZA",G6Q);
function G6Q(nQ){up.oIg=nQ;}


if(up!=fj)up.A1q=undefined;

ED(up,"fK",ESS);
function ESS(){return up.A1q;}
Wf(up,"fK",p88);
function p88(nQ){up.A1q=nQ;}


if(up!=fj)up.DLW=undefined;

ED(up,"yTl",CrO);
function CrO(){return up.DLW;}
Wf(up,"yTl",NhK);
function NhK(nQ){up.DLW=nQ;}


if(up!=fj)up.Sa9=undefined;

ED(up,"gAc",xtv);
function xtv(){return up.Sa9;}
Wf(up,"gAc",BUX);
function BUX(nQ){up.Sa9=nQ;}


if(up!=fj)up.U2r=undefined;

ED(up,"ifs",U41);
function U41(){return up.U2r;}
Wf(up,"ifs",lmh);
function lmh(nQ){up.U2r=nQ;}

function ju(){nv.call(up);
up.fm=srQ.DmE;

up.F0e=0;
up.pEx=0;
up.oIg=0;
up.A1q=0;
up.DLW=0;
up.Sa9=0;
up.U2r=0;
}

OZ(up,"yZ8",zDR);
function zDR(){

var Ams=new sqT();
Ams.R7p=up.F0e;
Ams.fWb=up.pEx;
Ams.BZA=up.oIg;
Ams.fK=up.A1q;
Ams.yTl=up.DLW;
Ams.gAc=up.Sa9;
Ams.ifs=up.U2r;







var EjT=up.PhyZ8();
EjT.fm=srQ.DmE;
EjT.Ams=Ams;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "SdmApiErrorEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

if(up.F0e>0){
nI=nI+";nEvExCnt="+up.F0e;
}
if(up.pEx>0){
nI=nI+";longNameCnt="+up.pEx;
}
if(up.oIg>0){
nI=nI+";noNameCnt="+up.oIg;
}
if(up.A1q>0){
nI=nI+";longKeyCnt="+up.A1q;
}
if(up.DLW>0){
nI=nI+";longValCnt="+up.DLW;
}
if(up.Sa9>0){
nI=nI+";longAllValCnt="+up.Sa9;
}
if(up.U2r>0){
nI=nI+";EntExCnt="+up.U2r;
}

return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(nT5,"nT5");












function n8y(){
var up=this;

if(up!=fj)up.wtq=undefined;

ED(up,"TZX",HQ4);
function HQ4(){return up.wtq;}
Wf(up,"TZX",u4P);
function u4P(nQ){up.wtq=nQ;}


if(up!=fj)up.wqm=undefined;

ED(up,"TpH",GuY);
function GuY(){return up.wqm;}
Wf(up,"TpH",ZbE);
function ZbE(nQ){up.wqm=nQ;}

function ju(){nv.call(up);
up.fm=srQ.Fmw;

up.wtq=Rmb.Lnh;
up.wqm=-1;
}

OZ(up,"yZ8",zDR);
function zDR(){

var fhe=new yVL();
fhe.TZX=up.wtq;
if(up.wqm>=0){
fhe.TpH=up.wqm;
}







var EjT=up.PhyZ8();
EjT.fm=srQ.Fmw;
EjT.fhe=fhe;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "SeekEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";seek "+up.PNS(up.wtq);
nI=nI+";pos="+up.wqm;

return nI;
}

LK(up,"PNS",hn7);
function hn7(fm){
switch(fm){
case Rmb.Le:
return "start";
case Rmb.I6:
return "success";
case Rmb.hO:
return "failed";
case Rmb.m6b:
return "invalid";
case Rmb.Lnh:
return "uninitialized";
default:
return "";
}
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(n8y,"n8y");












function XiV(){
var up=this;


if(up!=fj)up.iU=undefined;

ED(up,"NR",J5);
function J5(){return up.iU;}
Wf(up,"NR",D8w);
function D8w(nQ){up.iU=nQ;}

function ju(){nv.call(up);
up.fm=srQ.sIo;

up.iU=Ez.Lnh;
}

OZ(up,"yZ8",zDR);
function zDR(){

var r_0=
new ILo();
r_0.NR=up.iU;







var EjT=up.PhyZ8();
EjT.fm=srQ.sIo;
EjT.r_0=r_0;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return true;}

OZ(up,"gyP",Qh6);
function Qh6(){return "SessionStateTransitionEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();
nI=nI+";sess="+up.iU;
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(XiV,"XiV");












function t31(){
var up=this;

if(up!=fj)up.tyI=undefined;

ED(up,"h7b",tcZ);
function tcZ(){return up.tyI;}
Wf(up,"h7b",dQ1);
function dQ1(nQ){up.tyI=nQ;}


if(up!=fj)up.go=undefined;

ED(up,"w6",dO);
function dO(){return up.go;}
Wf(up,"w6",pl3);
function pl3(nQ){up.go=nQ;}

if(up!=fj)up.Xop=undefined;

ED(up,"ouW",Zid);
function Zid(){return up.Xop;}
Wf(up,"ouW",fuM);
function fuM(nQ){up.Xop=nQ;}

function ju(){nv.call(up);
up.fm=srQ._bg;

up.tyI=0;
up.go="";
}

OZ(up,"yZ8",zDR);
function zDR(){

var daO=new wdT();
daO.h7b=up.tyI;
daO.w6=new VI();
daO.w6.tg(up.go);
daO.ouW=up.Xop;







var EjT=up.PhyZ8();
EjT.fm=srQ._bg;
EjT.daO=daO;
return EjT;
}

OZ(up,"y5v",Xnz);
function Xnz(){return false;}

OZ(up,"gyP",Qh6);
function Qh6(){return "StreamingServerIpEvent";}

OZ(up,"vo",Ua);
function Ua(){
var nI=up.Phvo();

nI=nI+";ip#="+up.tyI;

nI=nI+";ipStr="+up.qCQ(up.tyI);

nI=nI+";rs="+up.go;

nI=nI+";swId="+up.Xop;
return nI;
}

LK(up,"qCQ",B14);
function B14(QF5){
var k3I=0xFF;
var nI=oL.fg((QF5&k3I));
nI=oL.fg(((QF5>>8)&k3I))+"."+nI;
nI=oL.fg(((QF5>>16)&k3I))+"."+nI;
nI=oL.fg(((QF5>>24)&k3I))+"."+nI;
return nI;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(t31,"t31");














function qC(){
var up=this;


if(up==fj)qC.IT=0;

if(up==fj)qC.RU=1;

if(up==fj)qC.aV=2;

if(up!=fj)up.me=undefined;

if(up!=fj)up.To=undefined;

if(up!=fj)up.Go=undefined;

if(up!=fj)up.mx=undefined;





function ju(le,Up,kz){
up.me=le;
up.To=Up;
up.Go=Up;
up.mx=kz;
}




OZ(up,"Sh",az);
function az(wU,kz){



var HO=up.kX(wU,kz);


if(HO!=qC.IT){
return HO;
}
up.Go=up.Go-wU;
return qC.IT;
}






OZ(up,"Ql",vq);
function vq(wU,kz){

var HO=up.gh(kz);


if(HO!=qC.IT){
return HO;
}
up.Go=up.Go-wU;
return qC.IT;
}







OZ(up,"Ti3",WPx);
function WPx(wU,kz){

var HO=up.gh(kz);


if(HO!=qC.IT){
return HO;
}
up.Go=0;
return qC.IT;
}




OZ(up,"kX",tN);
function tN(wU,kz){

var HO=up.gh(kz);


if(HO!=qC.IT){
return HO;
}

if(wU>up.Go){
return qC.aV;
}else{
return qC.IT;
}
}

OZ(up,"gh",ZO);
function ZO(kz){
if(kz<up.mx){
return qC.RU;
}


up.Go=up.Go+up.me*(kz-up.mx);
if(up.Go>up.To){
up.Go=up.To;
}
up.mx=kz;

return qC.IT;
}







OZ(up,"nr",kP);
function kP(le,Up,kz){
up.me=le;
up.To=Up;
up.Go=Up;
up.mx=kz;
}







OZ(up,"qv",pP);
function pP(le,Up,kz){
var iv=up.gh(kz);

up.me=le;
up.To=Up;

return iv;
}



if(up!=fj)ju.apply(up,arguments);
}
Bg(qC,"qC");


















function HkZ(){
var up=this;

if(up==fj)HkZ.uFp=null;







dN(up,HkZ,"el",aY);
function aY(){
return HkZ.uFp;
}

dN(up,HkZ,"aq3",h59);
function h59(G_,KP){
var sD=HkZ.D4(G_);
if(sD==null){
return G_;
}
if(HkZ.gQA(G_)){


HkZ.uFp=G_;

return HkZ.uFp;
}
if(oL.Pe(sD,"DummyStreamer")){
HkZ.uFp=new GnC(G_,KP.Bl);
return HkZ.uFp;
}



return G_;
}

dN(up,HkZ,"gQA",tQs);
function tQs(I8P){






return Dh.xI("GetTotalLoadedBytes",I8P)
&&Dh.xI("SetMonitoringNotifier",I8P);
}

dN(up,HkZ,"J1E",Fuv);
function Fuv(X9e){


return Dh.xI("GetTotalLoadedBytes",X9e)
&&Dh.xI("SetPlayingStateChangeCallback",X9e)
&&!Dh.xI("Ylo",X9e)
&&!Dh.xI("SetMonitoringNotifier",X9e);
}

dN(up,HkZ,"D4",y6);
function y6(G_){

var sD=null;
if(Dh.xI("HS",G_)){
return "DummyStreamer";
}
if(G_.GetPluginStatus!=undefined){
return "QTElement";
}
if(G_.networkState!=undefined&&G_.readyState!=undefined){
return "HTMLVideoElement";
}
if(HkZ.gQA(G_)){

return "ConvivaStreamerProxy";
}
return null;
}
}
Bg(HkZ,"HkZ");
























function g6(){
var up=this;



if(up==fj)g6.NB=1000;

if(up!=fj)up.Pt=null;


if(up!=fj)up.O5=undefined;

if(up!=fj)up.od9=undefined;

if(up!=fj)up.mog=0;


function ju(nI){
up.Pt=nI;
up.O5=new Yw();
up.od9=null;
}

OZ(up,"wy",NQ);
function NQ(){
up.Pt=null;
up.O5.m3();
up.O5=null;
up._PY();
}







OZ(up,"ZvL",koC);
function koC(){
up.O5=new Yw();
}





OZ(up,"Ra9",_14);
function _14(){
up._PY();
up.od9=up.O5;
}

OZ(up,"v_8",R0l);
function R0l(){
up.O5=up.od9;
up.od9=new Yw();
}

LK(up,"_PY",z5w);
function z5w(){
if(up.od9!=null){
up.od9.m3();
up.od9=null;
}
}











OZ(up,"MT",es);
function es(eY,R7){
if(g6.NB==0){
up.DE(eY);
return;
}


if(eY!=Ux.CS&&
eY!=Ux.DV){
up.Rz(eY,R7);
return;
}

var Wp=up.O5.Bt;
if(Wp==0){


if(eY==Ux.DV){
up.O5.Yb(new qo(eY,R7));
}
up.DE(eY);
return;
}


var Ox=up.O5.tc(Wp-1);
if(Ox.eY==eY){
return;
}



if(eY==Ux.CS){
up.O5.Yb(new qo(eY,R7));
}else{
up.VZ(R7);
up.O5.Yb(new qo(eY,R7));
if(up.O5.Bt==1){
up.DE(eY);
}
}
}

OZ(up,"VZ",Xh);
function Xh(R7){


var Wp=up.O5.Bt;
if(Wp>1){
var Ox=up.O5.tc(Wp-1);


if(Ox.eY==Ux.CS&&
R7-Ox.R7>=g6.NB){
up.Rz(Ox.eY,R7);
}
}
}


OZ(up,"ipT",m_y);
function m_y(){
return(up.O5!=null)&&(up.O5.Bt>0);
}

OZ(up,"UcS",wB4);
function wB4(){
return up.mog;
}







LK(up,"Rz",RW);
function RW(eY,R7){
var BM=0;
var Nz=0;
var UM=0;

var Wp=up.O5.Bt;
if(Wp==0){
up.DE(eY);
return;
}


var nx=0;
for(var co=0;co<Wp;co++){
if(co>0){
nx=hR.SI(up.O5.tc(co-1).R7,up.O5.tc(co).R7);
}
if(co%2==0){
O9.y8(
up.O5.tc(co).eY==Ux.DV,
"state "+co+" should not be "+up.O5.tc(co).eY);
if(co!=0){
UM=nx;
Nz+=UM;
}
}else{
O9.y8(
up.O5.tc(co).eY==Ux.CS,
"state "+co+" should not be "+up.O5.tc(co).eY);
UM=0;
BM+=nx;
}
}


var Ox=up.O5.tc(Wp-1);

nx=Math.max(0,hR.SI(Ox.R7,R7));
if(Ox.eY==Ux.CS){
UM=nx;
Nz+=nx;
}else{
UM=0;
BM+=nx;
}

var HTO=new AJl();
HTO.ca=VW.z_(eY);
HTO.BgX=up.O5.Bt-1;
HTO.SeK=VW.z_(BM);
HTO.WR=VW.z_(Nz);
HTO.UM=VW.z_(UM);

if(up.Pt!=null&&up.Pt.FR!=null){
up.Pt.FR.UY(HTO);
}

up.gWA=HTO;

up.O5.m3();
}

OZ(up,"DE",p4);
function p4(eY){
var ho0=new fMf();

ho0.ca=VW.z_(eY);

if(up.ipT()){
ho0.qsk=EmX.tpF;
}

up.Pt.FR.UY(ho0);

if(eY==Ux.DV){
up.mog++;
}
}





dN(up,g6,"GQ",qh);
function qh(){
g6.NB=0;
}

dN(up,g6,"oLe",MKf);
function MKf(){
g6.NB=1000;
}

dN(up,g6,"RCw",WCX);
function WCX(EqC){
g6.NB=EqC;
}

if(up!=fj)up.gWA=undefined;
OZ(up,"m_i",sTH);
function sTH(){return up.gWA;}
if(up!=fj)ju.apply(up,arguments);
}
Bg(g6,"g6");


function qo(){
var up=this;
if(up!=fj)up.eY=undefined;
if(up!=fj)up.R7=undefined;
function ju(nI,yw){
up.eY=nI;
up.R7=yw;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(qo,"qo");












function GY(){
var up=this;





if(up==fj)GY.n8u=1;
if(up==fj)GY.f7m=2;
if(up==fj)GY.CkO=3;
if(up==fj)GY.gWD=4;


if(up==fj)GY.JRP=0;







if(up==fj)GY.wp=120*1000;


if(up==fj)GY.CF=3*1000;


if(up==fj)GY.Pw=600*1000;


if(up==fj)GY.Wc=200;


if(up==fj)GY._k=1600/GY.Wc;


if(up==fj)GY.eM=800/GY.Wc;


if(up==fj)GY.AO1=1;


if(up==fj)GY.wPO=0;


if(up==fj)GY.f0k=0.25;


if(up==fj)GY.Qp=1;


if(up==fj)GY.xM=25000;



if(up==fj)GY.lD=15000;




if(up==fj)GY.MFm=10*1000;


if(up==fj)GY.JuH=4;



if(up!=fj)up.qVe=1;

if(up!=fj)up.BZ=undefined;


if(up!=fj)up.UJ=undefined;


if(up!=fj)up.CI=undefined;


if(up!=fj)up.bs=undefined;


if(up!=fj)up.ww=undefined;


if(up!=fj)up.pV=0;






if(up!=fj)up.On=true;


if(up!=fj)up.q8=undefined;


if(up!=fj)up.P3=undefined;



if(up!=fj)up.zs=undefined;


if(up!=fj)up.fR=0;


if(up!=fj)up.iP=0;


if(up!=fj)up.JW7=0;



if(up==fj)GY.Tr=32767;


if(up!=fj)up.Lm=undefined;



if(up!=fj)up.Zs=undefined;

if(up!=fj)up.LXV=undefined;


if(up!=fj)up.Mw=undefined;







if(up!=fj)up.QO=undefined;
if(up!=fj)up.gR=0;
if(up!=fj)up.xK=0;



if(up!=fj)up.GL=undefined;
if(up!=fj)up.MH=undefined;

if(up!=fj)up.vv=undefined;

if(up!=fj)up.Kw=undefined;
if(up!=fj)up.v4=undefined;

if(up!=fj)up.vy=undefined;
if(up!=fj)up.QX=undefined;
if(up!=fj)up.XK=undefined;
if(up!=fj)up.ig=undefined;

if(up!=fj)up.ra=undefined;
if(up!=fj)up.FG=undefined;


if(up!=fj)up.QI=undefined;


if(up!=fj)up.Lr=undefined;





if(up!=fj)up.KL=undefined;



if(up!=fj)up.Jq=0;


if(up!=fj)up.Nk=0;









if(up!=fj)up.Mv="12";


if(up!=fj)up.pF=null;


if(up!=fj)up.CfI=null;


if(up!=fj)up.Wa=null;


if(up!=fj)up.Es=false;


















if(up!=fj)up.LUA=null;


if(up!=fj)up.go=null;


if(up!=fj)up.Rf=undefined;


if(up!=fj)up.M9o=undefined;


if(up!=fj)up.n4k=undefined;


if(up!=fj)up.VxS=undefined;


if(up!=fj)up.hek=undefined;


if(up!=fj)up.bnz=undefined;


if(up!=fj)up.V8=undefined;


if(up!=fj)up.L7=undefined;


if(up!=fj)up.Ah=undefined;


if(up!=fj)up.DP=600000;


if(up!=fj)up.iU=undefined;

if(up!=fj)up.Ui=undefined;


if(up!=fj)up.w7E=undefined;


if(up!=fj)up.baQ=null;
if(up!=fj)up.KZ=0;


if(up!=fj)up.Rg=0;


if(up!=fj)up.re=0;




if(up!=fj)up.amr=false;


if(up!=fj)up.od=0;

if(up!=fj)up.zR=0;

if(up!=fj)up.o4=0;

if(up!=fj)up.ORV=-1;

if(up!=fj)up.mqo=-1;

if(up!=fj)up.JWl=null;


if(up!=fj)up.FX=undefined;



if(up!=fj)up.AUd=undefined;


if(up!=fj)up.dXf=undefined;


if(up!=fj)up.akz=false;


if(up!=fj)up.Ex9=0;


if(up!=fj)up.ZAW=false;





if(up!=fj)up.Qw9=null;
if(up!=fj)up.HcZ=false;




if(up!=fj)up.CPx=OEK.Bh0;


if(up!=fj)up.UdT=-1;

if(up!=fj)up.NwE=-1;

if(up!=fj)up.Kyd=0;

if(up!=fj)up.oqP=0;


function ju(KP){
O9.y8(KP!=null,"Monitor's session can not be null");
up.CI=KP;
up.UJ=null;
up.Ui=new g6(KP);
up.w7E=null;
up.baQ=null;

up.bs=KP.Bl;
up.ww="Mon["+up.bs+"]";
up.pV=Lt.VB();

up.zs=new EW();
up.P3=up.pV;
up.Zs=-1;
up.LXV=-1;
up.Lm=0;
up.Jq=0;
up.pF=null;
up.CfI=new SPf();

up.JWl=null;

up.HcZ=false;
up.Qw9=new Mcb();
up.Qw9.ouW=0;
up.Qw9.n_B=0;
up.Qw9.dxR=null;

up.Rf=new EW();
up.M9o=true;

up.n4k=new EW();
up.VxS=new EW();
up.hek=new EW();
up.bnz=new EW();
up.V8=null;
up.L7=new EW();
up.Ah=-1;
up.Es=false;
up.Kw=-1;
up.v4=-1;
up.vy=-1;
up.QX=-1;
up.XK=-1;
up.ig=-1;
up.QI=-1;

up.Lr=-1;

up.ra=0;
up.FG=0;

up.FX=new EW();

up.Mw=up.pV;
up.UdT=-1;
up.NwE=-1;
up.Kyd=0;
up.oqP=0;

up.iU=Ez.Le;
up.BZ=null;
up.q8=Ux.nw;

var ho0=new fMf();
ho0.ca=VW.z_(up.q8);
up.FR.UY(ho0);

var yWi=new XiV();
yWi.NR=VW.z_(up.iU);
up.FR.UY(yWi);


up.dXf=new ffH(GY.JuH);
}




OZ(up,"lQ",E4);
function E4(G_){
up.On=true;

O9.y8(up.UJ==null,"AttachStreamer");

up.bV();
up.KL=new Lt(GY.Wc,up.TJ,"Monitor.PollStreamer");
up.AUd=new Lt(GY.MFm,up.v2x,"Monitor.SampleStreamer");



up.cg(Ux.cz);


up.GL=new FQ(GY.wp,
GY.wp/20);
up.MH=new FQ(GY.wp,
GY.wp/20);
up.vv=new FQ(GY.CF,
GY.CF/5);
up.Lr=-1;

up.KZ=0;

var dwB=null;
dwB=HkZ.aq3(G_,up.CI);


up.UJ=Pz.Z9(up,dwB);


up.BQ(true,up.M9o);
up.M9o=false;
}


OZ(up,"vY",t9);
function t9(){
if(up.UJ==null)return;

up.TJ();

if(up.KL!=null){
up.KL.wy();
up.KL=null;
}


if(up.V8!=null){
up.V8.lE();
}
if(up.Ah>0){
up.Qv();
}

up.cg(Ux.nw);

up.UJ.wy();
up.UJ=null;
up.KZ=0;


if(up.AUd!=null){
up.AUd.wy();
up.AUd=null;
}
}

OZ(up,"wy",NQ);
function NQ(){
if(up.UJ==null)return;
up.vY();
up.CI=null;

up.Ui.wy();
up.Ui=null;

up.w7E=null;
if(up.baQ!=null){
WP.cRZ(up.baQ);
up.baQ=null;
}

var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xk=bC[Jo];

xk.wy();
}
var HH=up.n4k.YC;
for(var wt=0;wt<HH.length;wt++){
var ELb=HH[wt];

ELb.m3();
}
if(up.GL!=null){
up.GL.wy();
up.GL=null;
}
if(up.MH!=null){
up.MH.wy();
up.MH=null;
}
if(up.vv!=null){
up.vv.wy();
up.vv=null;
}
up.Qw9=null;
up.Rf=null;
up.n4k=null;
up.VxS=null;
up.hek=null;
up.bnz=null;
up.V8=null;
var jk=up.L7.YC;
for(var jB=0;jB<jk.length;jB++){
var sL=jk[jB];

sL.wy();
}
up.L7=null;
up.Ah=-1;
up.JWl=null;

up.FX=null;


up.S2g();
}

LK(up,"S2g",lI4);
function lI4(){
if(up.dXf!=null){
up.dXf.wy();
up.dXf=null;
}
}

LK(up,"bV",AH);
function AH(){
up.QO=new Yw();
up.gR=-1;
up.xK=0;
}

OZ(up,"gd",sK);
function sK(jN0,hlD){



var na=Lt.VB();


if(up.CI.V7==true){
hlD.LZy=X6Z.GZI;
}else{
if(up.CI.V7==false){
hlD.LZy=X6Z.KFJ;
}else{
hlD.LZy=X6Z.ft;
}
}


if(jN0==M24.nrH){
hlD.uY0=M24.nrH;
}else{
hlD.uY0=M24.vn5;
}


hlD.ca=VW.z_(up.ca);
hlD.NR=VW.z_(up.NR);

hlD.lZd=up.w6;
hlD.Anr=up.Ah;

if(up.LUA!=null){
hlD.oFS=up.LUA;
}






if(up.UJ!=null){
hlD.qdG=up.kjH();
}

var vG=up.ML();
if(vG>=0){
hlD.vG=vG;
}
var w0=up.izU();
if(w0>=0){
hlD.w0=w0;
}
var lw=up.Ww2();
if(lw>=0){
hlD.lw=lw;
}
var fuP=VW.z_(up.Mqk());
if(fuP>=0){
hlD.k9T=fuP;
}
var gqs=VW.z_(up.EkW());
if(gqs>=0){
hlD.f_S=gqs;
}

var wui=up.aGW();
if(wui>=0){
hlD.TU1=wui;
}



hlD.Dy9=VW.z_(up.CPx);





var zc=undefined;
var E8=undefined;

var LI=VW.z_(up.mN(Ux.cz,na));
var zg=VW.z_(up.mN(Ux.CS,na));
var rp=VW.z_(up.mN(Ux.Qh,na));
var oF=VW.z_(na-up.pV-up.FM8(na));
if(up.dv>=0){
zc=VW.z_(up.mN(Ux.DV,na))-VW.z_(up.fR);
E8=VW.z_(up.fR);
}else{
zc=0;
E8=VW.z_(up.mN(Ux.DV,na));
}
if(up.Zs>=0){
hlD.dv=VW.z_(up.Zs);
}
if(E8>=0){
hlD.E8=E8;
}
if(zc>=0){
hlD.zc=zc;
}
if(zg>=0){
hlD.zg=zg;
}
if(LI>=0){
hlD.LI=LI;
}
if(rp>=0){
hlD.DsV=rp;
}
if(oF>=0){
hlD.oF=oF;
}


up.AC();

hlD.IC=VW.z_(up.zR);

hlD.sb=VW.z_(up.o4);

hlD.jD=VW.z_(up.K0H());








hlD.Gii=VW.z_(up.neG());

if(up.UJ!=null){
up.GL.mkP();
up.MH.mkP();
}

hlD.ap8=VW.z_(up.Gi);
hlD.lz2=VW.z_(up.Jc);
hlD.Z1P=VW.z_(up.Ui.UcS());

if(up.e2E()!=oR.oH){
hlD.h7b=up.e2E();
}

if(up.ArX()!=null){
hlD.y0L=up.ArX();
}

var sr=undefined;
var bC=up.Rf.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

sr=null;
var rZ=up.Rf.tc(Tj).rZ;


if(up.Rf.tc(Tj)!=up.V8)
sr=up.Rf.tc(Tj).w6;

var XtA=
VW.z_(up.Pfm(up.Rf.tc(Tj),up.VxS));
var kFA=
VW.z_(up.Pfm(up.Rf.tc(Tj),up.hek));
var Adw=
VW.z_(up.Pfm(up.Rf.tc(Tj),up.bnz));


if(XtA!=0){
hlD.z9i(sr,XtA);
hlD.Ix_(sr,rZ,XtA,
kFA,Adw);
}


var kMN=VW.z_(up.Rf.tc(Tj).Wr8);
hlD.Ll2(sr,kMN);
}



if(up.n4k.Bt==0){
var HH=up.Rf.GA;
for(var wt=0;wt<HH.length;wt++){
var JsJ=HH[wt];

sr=null;

if(JsJ.Zw!=up.w6){
sr=JsJ.Zw;
}



hlD.BmP(sr,JsJ.GU.uJp);
}
}else{
var jk=up.n4k.GA;
for(var jB=0;jB<jk.length;jB++){
var gwH=jk[jB];

sr=null;

if(gwH.Zw!=up.w6){
sr=gwH.Zw;
}
hlD.BmP(sr,gwH.GU);
}
}


if(up.Ui.ipT()){
hlD.qsk=EmX.tpF;
}


if(up.HcZ){
hlD.TvW=up.Qw9;
}

if(up.Zs<0&&up.oqP>0){

hlD.XvR=_g7.EQT;
}
hlD.pKR=CO.z4C;
}











LK(up,"Pfm",x2y);
function x2y(uT,aq){
var sr=uT.w6;
var eN4=0.0;
var KtZ=0.0;


if(aq==up.VxS){
KtZ=uT.KCU;
}else if(aq==up.hek){
KtZ=uT.Wr8;
}else if(aq==up.bnz){
KtZ=uT.SeK;
}


if(!aq.Wt(sr)){
aq.Yb(sr,KtZ);
}else{
eN4=aq.tc(sr);
}


aq.a9(sr,KtZ);
return KtZ-eN4;
}


ED(up,"id",d4);
function d4(){return up.bs;}

ED(up,"V7",e9);
function e9(){return up.CI.V7;}

ED(up,"Fx",Qd);
function Qd(){return up.pV;}

ED(up,"ca",Ul);
function Ul(){return up.q8;}

ED(up,"yN",RY);
function RY(){return up.On;}


ED(up,"M9",Ic);
function Ic(){return up.Jq;}

ED(up,"Iv",M2);
function M2(){return up.iP;}

ED(up,"M0P",N8H);
function N8H(){return up.JW7;}

ED(up,"dv",eJ);
function eJ(){return up.Zs;}

ED(up,"kws",AYv);
function AYv(){return up.Zs>=0;}


ED(up,"E8",_X);
function _X(){return up.fR;}


ED(up,"Jv_",oDr);
function oDr(){return up.ORV;}

ED(up,"ceG",vks);
function vks(){return up.mqo;}


ED(up,"Jc",Q7);
function Q7(){return up.ra;}


ED(up,"Gi",FA);
function FA(){return up.FG;}


ED(up,"uU",TD);
function TD(){return up.Rg;}
Wf(up,"uU",C4);
function C4(nQ){up.Rg=nQ;}


ED(up,"af",Lk);
function Lk(){return up.re;}
Wf(up,"af",dA);
function dA(nQ){up.re=nQ;}



ED(up,"sa",G3);
function G3(){
if(up.V8==null)return-1;
return up.V8.rZ;
}


ED(up,"Wg",DO);
function DO(){return up.DP;}
Wf(up,"Wg",YH);
function YH(nQ){up.DP=nQ;}


ED(up,"NR",J5);
function J5(){return up.iU;}


ED(up,"w6",dO);
function dO(){return up.go;}


ED(up,"Qk",UI);
function UI(){return up.Ah;}


ED(up,"FR",tU);
function tU(){return up.CI.FR;}


ED(up,"Jh7",ccY);
function ccY(){return up.HcZ;}
Wf(up,"Jh7",VAX);
function VAX(nQ){up.HcZ=nQ;}


ED(up,"Jdf",v6V);
function v6V(){return up.Qw9;}
Wf(up,"Jdf",oVz);
function oVz(nQ){up.Qw9=nQ;}


OZ(up,"Gc",Bm);
function Bm(){
up.QI=0;
}
OZ(up,"h2",NL);
function NL(){
if(up.QI==-1)
up.QI=0;
up.QI++;
}












Wf(up,"_fK",j6i);
function j6i(nQ){up.LUA=nQ;}
ED(up,"_fK",VUf);
function VUf(){return up.LUA;}







OZ(up,"AC",iH);
function iH(){
var cw=undefined;
if(up.UJ!=null){
cw=up.GL.nG();

if(cw.Mf>0){
up.zR=VW.z_(Math.floor(0.5+cw.PS));
}else{
up.zR=-1;
}
if(up.Lr>-1&&up.Lr<up.zR){
up.Lr=up.zR;
}
cw=up.MH.nG();
if(cw.Mf>0){
up.o4=VW.z_(Math.floor(0.5+cw.PS));
}else{
up.o4=-1;
}
if(up.Lr>-1&&up.Lr<up.o4){
up.Lr=up.o4;
}
}else{
up.zR=0;
up.o4=0;
}

up.od=VW.z_(Math.floor(0.5+up.Lr));

}

OZ(up,"Nd",Fu);
function Fu(ym){
if(ym==null)return;
try{
if(ym.Wt("joinStartTime")){


var pC=oL.iGL(ym.tc("joinStartTime"));

up.Mw=pC+Lt.VB()-Lt.fp();
}
}catch(fe){
}
try{
if(ym.Wt("passedJoinTime")){
up.LXV=oL.iGL(ym.tc("passedJoinTime"));
}
}catch(fe){
}
up.Jq=0;
try{
if(ym.Wt("bitrateKbps")){
up.Nk=n4.tn(ym.tc("bitrateKbps"));
if(up.Zkr(up.Nk)){
up.Jq=up.Nk;
up.pF="2";
up.VpZ(VW.z_(up.Jq));
}else{
up.pF="-1";
}
}
}catch(fe){
}
try{
if(ym.Wt("bitrateEstimators")){
up.Mv=ym.tc("bitrateEstimators");
}
}catch(fe){
}
try{
if(ym.Wt("playFailedAfterNSecondsBuffering")){
up.Rg=VW.tn(ym.tc("playFailedAfterNSecondsBuffering"));
}
}catch(fe){
}
try{
if(ym.Wt("playFailedAfterNSecondsJoining")){
up.re=VW.tn(ym.tc("playFailedAfterNSecondsJoining"));
}
}catch(fe){
}
try{

if(ym.Wt("contentDuration")){
var cX=oL.iGL(ym.tc("contentDuration"));
if(cX<0)cX=0;
up.CI.KC.cX=up.CfI.qrn(GY.CkO,VW.z_(cX));
}
}catch(fe){
}
try{
if(ym.Wt(ConvivaContentInfo.uf3)){
up.amr=(ym.tc(ConvivaContentInfo.uf3)=="true");
}





up.amr=up.amr||CO.el().xz0;
}catch(fe){
}
}







OZ(up,"ld",_g);
function _g(ma,HP){
if(ma==null||up.go==ma)return;

if(up.V8!=null){
up.V8.lE();
}
up.go=ma;
up.V8=up.qW(ma,
HP);





up.BQ(true,up.M9o);


up.TJ();

if(up.CI.V7&&!up.akz){
up.FVQ(ma);
}
}




OZ(up,"ZOd",ry1);
function ry1(qSY,HP){
up.ld(qSY,HP);
if(up.akz==false){
up.FVQ(qSY);
}
}




LK(up,"QY2",HLt);
function HLt(JM5,vTf){
if(vTf==null)return;
O9.y8(up.go!=null,"Monitor.OnResourceSwitchStart(): Current resource is null.");

up.tjM(up.Ah,JM5,up.go,vTf);
}





LK(up,"SAj",kI1);
function kI1(JM5,vTf,LMx,k3){
if(vTf==null)return;
O9.y8(up.go!=null,"Monitor.OnResourceSwitchEndLight(): Current resource is null.");

up.NUl(up.Ah,JM5,up.go,vTf,k3);

if(k3==ky.I6){

up._fK=null;

up.ld(vTf,LMx);
up.oz(JM5);
}
}

OZ(up,"PX9",XYs);
function XYs(M9,sr,rZ,k3){
up.QY2(M9,sr);
up.SAj(M9,sr,rZ,k3);
}






LK(up,"FVQ",ZiH);
function ZiH(pR6){
var hv=new tGb();
hv.lZd=pR6;


if(up.V7&&up.LUA!=null){
hv.oFS=up.LUA;
}
up.FR.UY(hv);

up.akz=true;
}





LK(up,"tjM",mAC);
function mAC(k0M,n_B,ZlP,dxR){
up.HcZ=true;

up.Qw9.ouW++;
if(up.Qw9.ouW>=65536-10){
up.Qw9.ouW=0;
SH.z2("sendResourceSwitchStartEventLight, too many switches ="+up.Qw9.ouW);
}
up.Qw9.n_B=n_B;
up.Qw9.dxR=new VI();
up.Qw9.dxR.tg(dxR);

var hv=new e7H();
hv.ouW=up.Qw9.ouW;
hv.szo=dxR;
hv.ZlP=ZlP;
if(k0M!=n_B&&k0M>0&&n_B>0){
hv.bmB=k0M;
hv.MMC=n_B;
}

hv.v6K=-1;
up.FR.UY(hv);
}





LK(up,"NUl",n0T);
function n0T(k0M,n_B,ZlP,dxR,k3){
up.HcZ=false;
var hv=new VDv();
hv.ouW=up.Qw9.ouW;
hv.k3=k3;

if(k3==ky.I6){
hv.lZd=dxR;
}else{
hv.szo=dxR;
}
hv.ZlP=ZlP;

if(k0M!=n_B&&k0M>0&&n_B>0){
hv.bmB=k0M;
if(k3==ky.I6){
hv.Anr=n_B;
}else{
hv.MMC=n_B;
}
}

hv.v6K=-1;
up.FR.UY(hv);
}

OZ(up,"lf",Ee);
function Ee(sr,rZ){
var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var uT=bC[Jo];

if(uT.w6==sr){
uT.rZ=rZ;
}
}
}



















OZ(up,"VpZ",urm);
function urm(Bg8){
Bg8=GY.YaM(Bg8);
if(!up.Zkr(Bg8))return;

up.Ex9=n4.z_(Bg8);
up.oz(Bg8);
}




OZ(up,"oz",eZ);
function eZ(Bg8){
Bg8=GY.YaM(Bg8);
if(!up.Zkr(Bg8)||
Bg8==up.Ah){
return;
}

ct.qF(up.ww,"SetCurrentBitrate "+Bg8);



up.BQ(false,up.M9o);

up.Qv();

if(!up.L7.Wt(Bg8)){
up.L7.a9(Bg8,new UV(up,VW.z_(Bg8)));
}
up.Ah=Bg8;
if(up.V8!=null){
up.V8.Qk(Bg8);
}
up.L7.tc(Bg8).ee();






if((!up.CI.V7||up.Ex9>0)&&!up.ZAW){


up.CPx=OEK.giS;
up.vaD(Bg8);
}
}




LK(up,"iSf",H_F);
function H_F(n_B){
n_B=GY.YaM(n_B);
if(!up.Zkr(n_B)||
n_B==up.Ah){
return;
}

var i1P=new Yw();
i1P.Yb(UN.ft);

up.HcZ=true;
up.Qw9.ouW++;
if(up.Qw9.ouW>=65536-10){
up.Qw9.ouW=0;
SH.z2("onBitrateSwitchStartEventLight, too many switches ="+up.Qw9.ouW);
}
up.Qw9.n_B=n_B;

up.aE6(n_B,up.Ah,UN.FSb,
i1P);
}





LK(up,"fdE",R6G);
function R6G(n_B,k3){
n_B=GY.YaM(n_B);
if(!up.Zkr(n_B)||
n_B==up.Ah){
return;
}

up.HcZ=false;
up.Qnv(n_B,up.Ah,k3,null,null,up.Qw9.ouW);

if(k3==WT0.I6){
up.oz(n_B);
}
}




LK(up,"vaD",cEA);
function cEA(Su){
var Q9z=new Fun();
Q9z.Anr=Su;
Q9z.Dy9=VW.z_(up.CPx);
up.FR.UY(Q9z);


up.ZAW=true;
}





OZ(up,"NVn",cdP);
function cdP(M9,k3){
if(up.amr&&!up.ZAW){


up.VpZ(M9);
}else{
up.iSf(M9);
up.fdE(M9,k3);
}
}




OZ(up,"aE6",pZV);
function pZV(Fkd,lkB,E1N,i1P){
var fwK=new aJS();
fwK.ouW=up.Qw9.ouW;
fwK.MMC=Fkd;
fwK.bmB=lkB;
fwK.jD=VW.z_(up.K0H());
fwK.spj(i1P);
fwK.KdP=E1N;
fwK.qdG=up.kjH();
up.FR.UY(fwK);
}




OZ(up,"Qnv",qG2);
function qG2(Fkd,lkB,k3,oEO,H1,ouW){
up.HcZ=false;
var LDj=new mtl();
LDj.ouW=ouW;
LDj.k3=k3;

LDj.bmB=lkB;


if(k3==WT0.I6&&Fkd!=lkB){
LDj.Anr=Fkd;
}else{
LDj.MMC=Fkd;
}
if(oEO!=""){
LDj.oEO=oEO;
}
LDj.qdG=up.kjH();
up.FR.UY(LDj);
}




LK(up,"Qv",Z_);
function Z_(){
if(up.Ah>0){
var sL=up.L7.tc(up.Ah);
if(sL!=null){
sL.Qv();
}
}
}

OZ(up,"ou",HA);
function HA(Uo,pM,w6,rZ){
var uT=null;
if(w6==""){
uT=up.V8;
}else{
uT=up.qW(w6,rZ);
}
if(uT!=null){
uT.ou(up.tCg(w6,w6==""),uT==up.V8,Uo,pM);
}
}






LK(up,"qW",Xd);
function Xd(w6,apN){
if(!up.Rf.Wt(w6)){
var id=up.jFg(w6,apN);
ct.qF(up.ww,"getResourceUsage(): Creating a new resource usage for resource \""+w6+"\" with ID "+id+".");
up.Rf.a9(w6,new dk(up,w6,id));
}
return up.Rf.tc(w6);
}






LK(up,"jFg",o90);
function o90(w6,VpR){
if(VpR!=GY.JRP){
return VpR;
}else{
return up.CI.Gcn(w6);
}
}

OZ(up,"i2",rX);
function rX(){
if(up.V8!=null&&up.UJ!=null){
up.V8.Jc++;
up.ra++;
}

}

OZ(up,"Ig",gr);
function gr(){
if(up.V8!=null&&up.UJ!=null){
up.V8.Gi++;
up.FG++;
}
}







OZ(up,"uo",Id);
function Id(vw,vV5){
O9.MU("GetMonitorState");
var na=Lt.VB();
var mo=0.0;




if(vV5){

}else if(up.UJ==null||
up.q8==Ux.Qh||
up.q8==Ux.cz){

var F8=CO.el().Mi;


if(up.KZ>0&&

hR.SI(up.KZ,na)<F8-200&&
up.P3<=up.KZ){
ct.qF(up.ww,"Postpone MonitorStats for paused/stopped/not monitored session");
return null;
}
}

if(up.UJ!=null){
up.TJ();
if(up.V8!=null){
up.V8.lE();
}
if(up.Ah>0){
up.Qv();
}
}
O9.MU("bytesDelta");
var uX=new Yw();
var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xk=bC[Jo];

var uT=xk.fC(up.Lm);
if(uT!=null){
uX.Yb(uT);
mo+=oL.fFw(uT.Xt);
}
}


if(up.xV()){

return null;
}

up.KZ=na;

O9.MU("usages");
var OM=new oR();
OM.uXiy(uX.jR());

OM.Nm=up.Lm;
up.Lm++;

OM.dv=VW.z_(up.Zs);

if(up.UJ!=null){
OM.EA=VW.z_(up.dD());
OM.vG=up.dz();
}
OM.lw=up.Kw;up.Kw=-1;
OM.w0=up.v4;up.v4=-1;
OM.LM=up.QI;

O9.MU("times");
OM.zg=up.mN(Ux.CS,na);

if(OM.dv>=0){
OM.zc=up.mN(Ux.DV,na)-VW.z_(up.fR);
OM.E8=VW.z_(up.fR);
}else{
OM.zc=0;
OM.E8=up.mN(Ux.DV,na);
}
OM.rp=up.mN(Ux.Qh,na);
OM.LI=up.mN(Ux.cz,na);
OM.ZL=up.mN(Ux.nw,na);
OM.Ky=up.FM8(na);
OM.oF=VW.z_(na-up.pV-OM.Ky);

OM.fF=VW.z_(up.q8);


up.AC();
OM.IC=VW.z_(up.zR);
OM.sb=VW.z_(up.o4);
OM.jD=VW.z_(up.od);

O9.MU("selres");
OM._f=-1;
OM.ps=-1;
var eU=up.CI.eU;
O9.MU("fps");
var cw=undefined;

if(eU!=null){
cw=eU.nG();
if(cw.Mf>0){
OM._f=VW.z_(cw.PS);
}
if(eU.oE()>0){
OM.ps=VW.z_(eU.DN());
}
}
O9.MU("bitusage");
if(up.L7.Bt>0){
var _7=new Yw();
var HH=up.L7.VO;
for(var wt=0;wt<HH.length;wt++){
var Su=HH[wt];

var sL=up.L7.tc(Su);
var CN=sL.I2();
if(CN!=null){
_7.Yb(CN);
}
}
OM._7iy(_7.jR());
}
OM.Gu=VW.z_(up.iU);
O9.MU("bw");



if(up.iP/10>GY.Tr){
OM.vi=VW.z_(GY.Tr);
}else if(up.iP>0){
OM.vi=VW.z_(up.iP/10);
}
O9.MU("serverip");
OM.Q5=up.e2E();
up.Wa=OM;
ct.qF(up.ww,XO.k8(OM,vw));
O9.MU("GetMonitorState.end");
return OM;
}




LK(up,"xV",Aa);
function Aa(){
var na=Lt.VB();
if(up.iU==Ez.Le||up.iU==Ez.Io){

var Ml=
Yw.oIy(Ux.Qh,
Ux.DV,
Ux.cz,
Ux.QG,
Ux.nw);

var tT=
Yw.oIy(CO.dy,
CO.E6,
CO.fN,
CO.xn,
CO.n_);
for(var co=0;co<Ml.Bt;co++){
if(up.q8==Ml.tc(co)){
if(hR.SI(up.P3,na)>tT.tc(co)){
ct.qF(up.ww,"Suspend current session for time in "+GY.Ak(up.q8)+" > "+
tT.tc(co)+"ms");
up.Xo(Ez.it);
}
}
}
return false;
}else if(up.iU==Ez.it){
if(up.q8==Ux.CS){
ct.qF(up.ww,"Resume current session");
up.Xo(Ez.Io);

up.FR.ho_();
}else{
ct.qF(up.ww,"Skip (in SUSPEND state)");
return true;
}
}else{
return false;
}
return false;
}

dN(up,GY,"Ak",pr);
function pr(nI){
switch(nI){
case Ux.DV:
return "buffering";
case Ux.CS:
return "playing";
case Ux.cz:
return "stopped";
case Ux.Qh:
return "paused";
case Ux.QG:
return "error";
case Ux.nw:
return "notMonitored";
case Ux.ft:
return "unknown";
default:
return oL.fg(nI);
}
}




OZ(up,"TJ",SG);
function SG(){



if(up.UJ==null)return;

if(up.Ui!=null){
up.Ui.VZ(Lt.VB());
}

var kz=Lt.VB();
if(up.q8==Ux.CS||
up.q8==Ux.DV||
up.q8==Ux.Qh){
up.BQ(false,false);
}
if(up.kws){

var R4=up.Ef();
if(up.q8==Ux.CS){


if(R4>=0.2){
up.GL.yS(R4);
up.MH.yS(R4);
up.vv.yS(R4);
}
}else if(up.q8==Ux.DV||up.q8==Ux.QG){
up.GL.yS(0);
}

if(up.vv.V9()>=GY.CF-1000){
var aI=up.vv.dW();
if(aI>up.Lr){
up.Lr=VW.z_(aI);
}
}

}


var V_=up.dD();
if(up.xK>0&&kz>up.xK){

up.QO.gX(0,
(oL.fFw(V_-up.gR))/(kz-up.xK));
}
up.xK=kz;
up.gR=oL.fFw(V_);


if(up.QO.Bt>Math.max(GY._k,
GY.eM)){

up.QO.DU(up.QO.Bt-1);
}
up.YT1(kz);

if(up.tCg("",true)>up.UJ.WIj()){
up.QuZ(Lt.VB());
}
up.dz();

up.iP=up.TzN();
up.JW7=up.FCy();
up.hD();
up.kk();

}







LK(up,"YT1",VBt);
function VBt(kz){

















var qlX=up.Ef();
if(qlX>0
&&CO.G1r
&&!up.kws){
ct.qF(up.ww,"change state to playing since framerate is positive");
up.cg(Ux.CS);
return;
}









if(up.CDY()==false){
return;
}




if(up.UJ.nj()=="html5"&&up.UJ.Ymu){
var SZx=up.QO.Bt;
if(SZx>=Math.min(GY.eM,GY._k)){
var qZE=0.0;
var bC=up.QO.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var ok=bC[Jo];

qZE+=ok;
}
qZE/=SZx;

if(up.q8!=Ux.CS
&&SZx>=GY.eM
&&Math.abs(qZE-GY.AO1)<GY.f0k){
ct.qF(up.ww,"change state to playing since PHT is moving (HTML5 Android)");
up.cg(Ux.CS);
return;
}
if(up.q8==Ux.CS
&&up.kws
&&SZx>=GY._k
&&qZE==GY.wPO){


var _q=true;


if(up.UJ&&up.UJ.Du){
_q=!up.UJ.Du.kXn;
}
if(_q){
ct.qF(up.ww,"change state to buffering since PHT stopped moving (HTML5 Android)");
up.h2();
up.cg(Ux.DV);
}else{
ct.qF(up.ww,"change state to paused since PHT stopped moving (HTML5 Android)");
up.cg(Ux.Qh);
}
}
}

return;
}

var zG=0;
var u5=0;


var HH=up.QO.YC;
for(var wt=0;wt<HH.length;wt++){
var ok=HH[wt];

if(ok==0){
if(u5>0){
break;
}
zG++;
}else{
if(zG>0){
break;
}

if(ok>=0.80&&ok<=1.20){
u5++;
}else{
if(up.q8!=Ux.CS){



}

break;
}
}
}

if(u5>=GY.eM&&
up.q8!=Ux.CS&&
up.UJ!=null){

ct.qF(up.ww,"change state to playing since PHT is moving");
up.cg(Ux.CS);
return;
}

if(zG>=GY._k){

if(up.q8==Ux.CS&&
up.P3<kz-1000){



var _q=false;

if(up.UJ.nj()=="qt"){
_q=(up.ML()<=1000&&up.ML()>=-1000)&&(up.dD()!=0);
}else if(up.UJ.nj()=="html5"){


_q=true;

if(up.UJ&&up.UJ.Du){
_q=!up.UJ.Du.kXn;
}
}
if(_q){
ct.qF(up.ww,"change state to buffering since PHT stopped moving and buffer is empty");
up.h2();
up.cg(Ux.DV);
}else{
ct.qF(up.ww,"change state to paused since PHT stopped moving");
up.cg(Ux.Qh);
}
}
return;
}
}

LK(up,"dz",Dc);
function Dc(){
var m7=up.ML();
if(up.Kw<0||m7>up.Kw)up.Kw=m7;
if(up.v4<0||m7<up.v4)up.v4=m7;
return m7;
}

LK(up,"hD",sl);
function sl(){
var m7=up.ML();
if((up.vy<0)||(m7>up.vy)){
up.vy=m7;
}
if((up.QX<0)||((m7>0)&&(m7<up.QX))){
up.QX=m7;
}
}

LK(up,"kk",A7);
function A7(){
var Iv=VW.z_(up.iP);
if((up.XK<0)||(Iv>up.XK)){
up.XK=Iv;
}
if((up.ig<0)||((Iv<up.ig)&&(Iv>0))){
up.ig=Iv;
}
}
















LK(up,"BQ",Wm);
function Wm(vB8,rZU){
if(up.V8==null){




return;
}
var Xt=up.wFZ();
O9.y8(Xt.Bt>0,"Monitor.UpdateBytesLoaded(): GetTotalLoadedBytes() is empty.");




var qR1=false;
var bC=Xt.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var w6=bC[Jo];

var Mt4=false;
if(w6==up.go||w6==ConvivaContentInfo._6t){
O9.y8(!qR1,"Monitor.UpdateBytesLoaded(): Encountered both the current resource and NO_RESOURCE.");
qR1=true;
Mt4=true;
}
var uT=null;
if(w6==ConvivaContentInfo._6t){
uT=up.V8;
}else{


uT=up.qW(w6,GY.JRP);
}



if(vB8){
uT.T1(Xt.tc(w6),Mt4,rZU,up.Ah);
}else{
uT.BQ(Xt.tc(w6),Mt4);
}
}
}


OZ(up,"LO",_l);
function _l(){
up.bV();


if(up.V7){
ct.qF(up.ww,"SeekNotify pht = "+up.dD());
var fhe=new n8y();
fhe.TZX=Rmb.I6;
fhe.TpH=VW.z_(up.dD()/1000);
up.FR.UY(fhe);
}
}



Wf(up,"Ce",xj);
function xj(nQ){
up.Es=nQ;
}

LK(up,"tCg",Jor);
function Jor(w6,P0O){
var sv2=up.wFZ();
if(P0O){
if(up.go!=null&&sv2.Wt(up.go)){
return sv2.tc(up.go);
}else if(sv2.Wt(ConvivaContentInfo._6t)){
return sv2.tc(ConvivaContentInfo._6t);
}else{
ct.qF(up.ww,"Warning. GetBytesLoadedOnResource(): No current resource found in GetTotalBytesLoaded().");
return 0;
}
}else{
if(sv2.Wt(w6)){
return sv2.tc(w6);
}else{
ct.qF(up.ww,"Warning. GetBytesLoadedOnResource(): No resource named \""+w6+"\" found in GetTotalBytesLoaded().");
return 0;
}
}
}

LK(up,"wFZ",Ss1);
function Ss1(){
if(up.UJ==null){
var wTT=new EW();
wTT.a9(ConvivaContentInfo._6t,0);
return wTT;
}
return up.UJ.wFZ();
}


OZ(up,"ML",zp);
function zp(){
if(up.UJ==null)return-1;
return up.UJ.ML();
}


OZ(up,"sm",YG);
function YG(){
if(up.UJ==null)return-1;
return up.UJ.sm();
}


OZ(up,"dD",CC);
function CC(){
if(up.UJ==null)return 0;
var fce=up.UJ.dD();
if(fce<0)return 0;
return n4.z_(fce);
}


OZ(up,"Ef",We);
function We(){
if(up.UJ==null)return-1.0;
return up.UJ.Ef();
}


LK(up,"K0H",hT1);
function hT1(){
return Math.max(up.od,Math.max(up.ORV,up.mqo));
}



LK(up,"CDY",zEv);
function zEv(){
if(up.UJ==null)return false;
return up.UJ.CDY();
}












OZ(up,"neG",CwH);
function CwH(){
if(up.MH==null)return 0.0;
return up.MH.N3p();
}





OZ(up,"a1",jn);
function jn(){
if(up.UJ==null)return-1;
return up.UJ.a1();
}



OZ(up,"izU",o94);
function o94(){
var Sk=up.QX;
up.QX=-1;
return Sk;
}


OZ(up,"Ww2",ErY);
function ErY(){
var Sk=up.vy;
up.vy=-1;
return Sk;
}






LK(up,"TzN",Cav);
function Cav(){
if(up.UJ==null)return 0;
var M_e=up.UJ.TzN();
var xUZ=0;
var bC=M_e.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var FBf=bC[Jo];

xUZ=Math.max(xUZ,FBf);
}
return xUZ;
}




LK(up,"FCy",Gg1);
function Gg1(){
return up.CI.zuz();
}


OZ(up,"Mqk",N2I);
function N2I(){
var Sk=up.ig;
up.ig=-1;
return Sk;
}


OZ(up,"EkW",Z0q);
function Z0q(){
var Sk=up.XK;
up.XK=-1;
return Sk;
}




LK(up,"e2E",VD2);
function VD2(){

if(up.CI!=null
&&up.CI.XRr()!=oR.oH){
return up.CI.XRr();
}

if(up.UJ==null){
return oR.oH;
}
var obD=up.UJ.bvd();



if(obD==null){
return oR.oH;
}else{
return iV.OGk(obD);
}
}



LK(up,"ArX",mbi);
function mbi(){
return up.CI.ArX();
}


OZ(up,"aGW",pdl);
function pdl(){
var epR=0.0;
var RL_=0;


if(up.CPx==OEK.Bh0){
var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xk=bC[Jo];

epR+=xk.KCU*8;
RL_+=VW.z_(xk.Wr8);
}



var vG=up.ML();
if(vG>=0){
RL_+=vG;
}
}else{
var HH=up.L7.VO;
for(var wt=0;wt<HH.length;wt++){
var sL=HH[wt];

var CN=up.L7.tc(sL).I2();
if(CN!=null){
epR+=oL.fFw(CN.M9)*CN.WR;
RL_+=CN.WR;
}
}
}
if(RL_==0){
return 0;
}else{

return VW.z_(epR/RL_);
}
}




OZ(up,"ls",Zz);
function Zz(eY){
return up.mN(eY,0.0);
}
OZ(up,"mN",Hi);
function Hi(eY,na){
if(!up.zs.Wt(eY)){
up.zs.a9(eY,0);
}
var S5=VW.z_(up.zs.tc(eY));
if(na==0){
na=Lt.VB();
}

if(up.q8==eY){
S5+=hR.SI(up.P3,na);
}
if(S5<0)return 0;
return S5;
}





OZ(up,"ea",tR);
function tR(aq,Tj){
return up.tX0(aq,Tj,0);
}





OZ(up,"tX0",bYS);
function bYS(aq,Tj,nkF){
var S5=nkF;
if(aq.Wt(Tj)){
try{
S5=oL.iGL(aq.tc(Tj));
}catch(fe){
}
}
return S5;
}









OZ(up,"O0",Vu);
function Vu(DM){
if(DM==null)return;
var o0="onMetaData: ";
var bC=DM.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var G2=bC[Jo];

o0+=G2+" : "+DM.tc(G2)+", ";
}
ct.qF(up.ww,o0);

if(up.JWl==null){
up.JWl=new EW();
}

var HH=up.JWl.VO;
for(var wt=0;wt<HH.length;wt++){
var ogX=HH[wt];

if(!DM.Wt(ogX)){
DM.a9(ogX,up.JWl.tc(ogX));
}
}

up.I55(DM,up.JWl);
up.JWl=DM;
}


LK(up,"I55",JMg);
function JMg(DM,Y8z){



var o6=up.ea(DM,"videodatarate");
var cP=up.ea(DM,"audiodatarate");
var Tt=up.ea(DM,"filesize");
var ER=up.ea(DM,"videosize");
var B9=up.ea(DM,"audiosize");
var zz=up.ea(DM,"datasize");
var vz=up.ea(DM,"duration");


var KB=VW.z_(up.ea(DM,"width"));
var zi=VW.z_(up.ea(DM,"height"));
var I9=VW.z_(up.ea(DM,"avcprofile"));


var Jv_=VW.z_(up.tX0(DM,"framerate",-1));
var ceG=VW.z_(up.tX0(DM,"videoframerate",-1));
up.m95(Jv_,ceG);





if(o6>GY.xM){
o6/=1000;
}
if(cP>GY.xM){
cP/=1000;
}

if(Tt==0){
Tt=ER+B9+zz;
}
var ff_=(vz!=0?
Tt*8/1024/vz
:0);





if(up.CI!=null&&up.CI.KC!=null){
if(o6+cP>0){
up.CI.KC.ZT=VW.z_(o6+cP);
}


if(vz>0){
var uXC=VW.z_(vz+0.5);
up.CI.KC.cX=up.CfI.qrn(GY.f7m,uXC);
}
}


if(KB!=VW.z_(up.ea(Y8z,"width"))
||zi!=VW.z_(up.ea(Y8z,"height"))
||I9!=VW.z_(up.ea(Y8z,"avcprofile"))){
up.WH(KB,zi,I9);
}



var lv=
jh.oIy(o6+cP,
up.Nk,
ff_);

if(up.pF!=null){
try{

var G4=VW.tn(up.pF)-1;
if(up.Jq>0&&lv.tc(G4)==0){
lv.a9(G4,up.Jq);
}
}catch(fe){

}
}

var otB=false;
var bC=oL.mT(up.Mv);
for(var Jo=0;Jo<bC.length;Jo++){
var JU=bC[Jo];

try{
var tM=oL.fg(JU);
var LV=lv.tc(VW.tn(tM)-1);

if(!otB&&up.zA(LV)){



otB=true;
up.Jq=n4.z_(LV);
up.pF=tM;
ct.qF(up.ww,"Setting bitrate estimation to "+oL.fg(up.Jq)+" using estimator "+up.pF);
if(up.Ah<0){
up.VpZ(VW.z_(up.Jq));
}
}
}catch(fe){
SH.z2("invalid character(s) found in bitrateEstimators: "+JU);
}
}

if(GY.g56(DM,"streamerVersion","unk")!=GY.g56(Y8z,"streamerVersion","unk"))
{

var hv=new J0C();
hv.Sj=nv.niT;
var kB=new EW();

kB.a9("cachePresent",GY.g56(DM,"cachePresent","unk"));;
kB.a9("streamerVersion",GY.g56(DM,"streamerVersion","unk"));
kB.a9("streamSource",GY.g56(DM,"streamSource","unk"));
kB.a9("isDrmPresent",GY.g56(DM,"isDrmPresent","unk"));
hv.kB=kB;
up.FR.UY(hv);

}

}


dN(up,GY,"g56",l7y);
function l7y(aq,JDY,lF){
if(!aq.Wt(JDY))
{
return lF;
}
return aq.tc(JDY);
}


OZ(up,"FN",oA);
function oA(cX,wii){
if(up.CI!=null&&
up.CI.KC!=null){
up.CI.KC.cX=up.CfI.qrn(wii,cX);
ct.qF(up.ww,"Setting session contentLengthSec to "+up.CI.KC.cX);
}
}

LK(up,"m95",kcW);
function kcW(Jv_,ceG){
var kKB=false;
if(up.ORV!=Jv_&&Jv_>-1){
kKB=true;
up.ORV=Jv_;
}
if(up.mqo!=ceG&&ceG>-1){
kKB=true;
up.mqo=ceG;
}
if(kKB){
up.r9x();
}
}







LK(up,"r9x",HWv);
function HWv(){
var hv=new J0C();
hv.Sj=nv.teo;
var PV=new EW();
PV.a9("fps",up.ORV);
PV.a9("videoFps",up.mqo);
hv.PV=PV;
up.FR.UY(hv);
}









OZ(up,"IE",XA);
function XA(k3,w6,ouW){
if(w6==null){
if(up.V8!=null){
up.V8.FW(k3);
}
}else{
if(up.Rf!=null){
var xk=up.qW(w6,GY.JRP);
if(xk!=null){
xk.FW(k3);
}
}
}

up.b7r(VW.z_(k3),ouW);
up.Wlg(k3);
}

OZ(up,"hXN",Ek4);
function Ek4(b8){
up.e54(b8);
up.Wlg(-1);
}

LK(up,"Wlg",JV6);
function JV6(k3){

if(!up.kws){

if(k3!=12&&k3!=70){
ct.qF(up.ww,"Scheduling urgent heartbeat to report pre-join error.");
}
WP.rF(CO.el().bD);
}
}

OZ(up,"b7r",kW1);
function kW1(k3,ouW){
var LQe=new Mhq();
LQe.Ti0=k3;
LQe.ouW=ouW;
up.FR.UY(LQe);
}

OZ(up,"NId",ZWl);
function ZWl(QxR,H1){
var Y0x=new t__();
Y0x.RED=QxR;
Y0x.H1=H1;
up.FR.UY(Y0x);
}

OZ(up,"e54",G24);
function G24(QxR){
var qBt=new LQP();
qBt.RED=QxR;
up.FR.UY(qBt);
}

LK(up,"zA",ax);
function ax(LV){
return(LV>=GY.Qp)&&(LV<=GY.xM);
}

LK(up,"Zkr",aWV);
function aWV(LV){
var p7V=up.zA(LV);
if(!p7V){
ct.Error(up.ww,"Bitrate "+LV+" is not valid (MIN: "+GY.Qp+"; MAX: "+GY.xM+")");
}
return p7V;
}




OZ(up,"Xo",rh);
function rh(jJ){
if(up.iU!=jJ){
up.iU=jJ;

if(jJ==Ez.cz){
var hlD=new jcl();
up.gd(
M24.nrH,hlD);
up.FR.UY(hlD);
}else{
var yWi=
new XiV();
yWi.NR=VW.z_(jJ);
up.FR.UY(yWi);
}
}
}



OZ(up,"WH",Y6);
function Y6(KB,zi,I9){
if(KB!=0&&zi!=0&&up.CI!=null&&up.FR!=null){
var PV=new EW();
PV.a9("vHSize",zi);
PV.a9("vWSize",KB);
PV.a9("avcProf",I9);

var RXG=new J0C();
RXG.Sj=nv.Ou1;
RXG.PV=PV;
up.FR.UY(RXG);

ct.qF(up.ww,"Video Resolution Changed Event "+oL.fg(KB)+":"+oL.fg(zi)+":"+oL.fg(I9));
}
}




OZ(up,"QuZ",eLe);
function eLe(na){
}







OZ(up,"cg",g0);
function g0(jJ){






var kz=Lt.VB();



ct.qF(up.ww,"Player changed state to "+GY.Ak(jJ)+"("+jJ+")");

var Vhn=false;


if(!up.kws&&up.q8==Ux.DV){
up.fR+=hR.SI(up.P3,kz);
}

if(jJ==Ux.CS&&!up.kws){



if(up.V8!=null){
up.V8.lE();
}

up.AmN();

if(up.LXV>=0){
up.Zs=up.LXV;
}else{
if(kz>up.Mw){
up.Zs=hR.SI(up.Mw,kz);
}else{
up.Zs=0;
}
}

up.Zs=Math.max(up.Zs-oL.fFw(up.Kyd),0.0);

up.klM();
up.ti(jJ);
Vhn=true;

var g7=CO.el();
if((up.CI.V7&&g7.hJ<g7.W1)||
(!up.CI.V7&&g7.hJ<g7.Yo)){
up.baQ=WP.rF(g7.hJ);
}
}

if(!up.zs.Wt(up.q8)){
up.zs.a9(up.q8,0);
}
up.zs.a9(up.q8,up.zs.tc(up.q8)+
hR.SI(up.P3,kz));



if(up.q8==Ux.CS&&jJ!=Ux.CS&&
up.zs.tc(Ux.CS)<up.qVe){
if(up.baQ!=null){
WP.cRZ(up.baQ);
up.baQ=null;
}
up.Zs=-1;
up.n4k.m3();
if(up.w7E!=null){
up.FR.rRM(up.w7E);
up.w7E=null;
}

up.Ui.v_8();
}

if(up.q8!=jJ){
if(up.q8!=Ux.nw||jJ!=Ux.cz){

up.On=false;
}

up.bV();

if(Vhn){



up.Ui.Ra9();
up.Ui.ZvL();
}else{

up.Ui.MT(jJ,Lt.VB());
}
}

up.q8=jJ;
up.P3=kz;
}


OZ(up,"xB",U4);
function U4(jJ){
up.cg(jJ);
up.On=false;
}

OZ(up,"ti",_5);
function _5(XDk){
up.w7E=new PEw();


O9.y8(XDk==Ux.CS,"new state after join is not ePlaying");
up.w7E.ca=VW.z_(XDk);

if(up.Zs>=0){
up.w7E.dv=VW.z_(up.Zs);
}

if(up.fR>=0){
up.w7E.E8=VW.z_(up.fR);
}


var wPT=up.ls(Ux.Qh);
if(wPT>0){
up.w7E.rp=wPT;
}


var Teh=up.ls(Ux.cz);
if(Teh>0){
up.w7E.LI=Teh;
}


if(up.n4k!=null&&up.n4k.Bt>0){
var bC=up.n4k.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

var S5=null;

if(Tj!=up.w6){
S5=Tj;
}

up.w7E.BmP(S5,up.n4k.tc(Tj));
}
}

up.FR.UY(up.w7E);
}
OZ(up,"Hz",l9);
function l9(){
}



OZ(up,"TO",am);
function am(Ck){

}


OZ(up,"YY",Os);
function Os(IO,jQ){
O9.MU("GatherStats");
var PD="Mon["+oL.fg(up.bs)+"].";
if(up.Wa==null){
IO.a9(PD,"no stats sent so far");
return;
}
O9.MU("cinfo");
IO.a9(PD+"objId",jQ.jz.T3());
IO.a9(PD+"tags",jQ.hA.T3());
O9.MU("seq");
IO.a9(PD+"seq",oL.fg(up.Wa.Nm));
if(up.Es){
IO.a9(PD+"est",oL.fg(up.Es));
}
O9.MU("times");
IO.a9(PD+"currentState",oL.fg(up.Wa.fF));
IO.a9(PD+"playheadTimeMs",oL.fg(up.Wa.EA));
IO.a9(PD+"joinTimeMs",oL.fg(up.Wa.dv));
IO.a9(PD+"totalPlayingTime",oL.fg(up.Wa.zg));
IO.a9(PD+"totalBufferingTime",oL.fg(up.Wa.zc));
O9.MU("resusage");
if(up.Wa.uXxz().ug==0){
IO.a9(PD+"resid[?].bytes","No resource found");
IO.a9(PD+"resid[?].bytesSLR","No resource found");
}else{
var bC=up.Wa.uXxz().YC;
for(var Jo=0;Jo<bC.length;Jo++){
var yo=bC[Jo];

var os=PD;
if(yo.w6.wf){
os+="resid[\""+yo.w6.C6.T3()+"\"]";
}else{
os+="resid["+yo.w6.kn+"]";
}
os+=".";
IO.a9(os+"bytes",oL.fg(yo.Xt));
}
}
O9.MU("bitusage");
if(up.L7.Bt==0){
IO.a9(PD+"bitrate[?]","No bitrate found");
}else{
var HH=up.L7.VO;
for(var wt=0;wt<HH.length;wt++){
var sL=HH[wt];

var CN=up.L7.tc(sL).I2();
if(CN!=null){
IO.a9(PD+"bitrate["+oL.fg(sL)+"].time[playing]",oL.fg(CN.WR));
}
}
}
O9.MU("GatherStats.done");
}

OZ(up,"v2x",xhw);
function xhw(){
if(up.dXf==null){
return;
}
var na=Lt.VB();
var vG=up.ML();
var M_6=VW.z_(up.iP);
var bJq=VW.z_(up.JW7);





var u4o=up.a1();
var qt=-1;
if(u4o>=0){
if(u4o/10>O9.ZLd){
qt=VW.z_(O9.ZLd);
}else{
qt=VW.z_(u4o/10);
}
}
if(vG>=0||M_6>=0||qt>=0){
var EVT=new hl1();
EVT.Ky=up.FM8(na);
if(vG>=0){
EVT.vG=vG;
}
if(M_6>=0){
EVT.M_6=M_6;
}
if(bJq>=0){
EVT.bJq=bJq;
}
if(qt>=0){
EVT.qt=qt;
}
up.dXf.i6Y(EVT);
}
}





OZ(up,"nj",i4);
function i4(){
if(up.UJ==null)return "none";
return up.UJ.nj();
}

OZ(up,"FM8",A7s);
function A7s(na){
return hR.SI(up.pV,na);
}




OZ(up,"yir",IAY);
function IAY(){
var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var GuT=bC[Jo];

if(GuT.vtV!=null&&GuT.vtV.Bt>0)
return true;
}
return false;
}





OZ(up,"Nce",kjQ);
function kjQ(cNZ){
var bC=up.Rf.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var GuT=bC[Jo];

var sr=null;

if(GuT!=up.V8){
sr=GuT.w6;
}

var HH=GuT.vtV.YC;
for(var wt=0;wt<HH.length;wt++){
var gKl=HH[wt];

cNZ.Qm6(sr,gKl);
}


GuT.Ybu();
}
}





LK(up,"klM",Bmw);
function Bmw(){
var bC=up.Rf.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

var Fkm=new Yw();



var HH=up.Rf.tc(Tj).uJp.YC;
for(var wt=0;wt<HH.length;wt++){
var YwT=HH[wt];

var Od4=new RJ();
Od4.UE(YwT);
Fkm.Yb(Od4);
}
up.n4k.Yb(Tj,Fkm);
}
}

OZ(up,"kjH",U6u);
function U6u(){
if(up.dXf!=null&&up.dXf.ug>0){

var wPp=new jh(up.dXf.ug);
for(var co=up.dXf.ug-1;co>=0;co--){
wPp.a9(up.dXf.ug-1-co,up.dXf.VAx(co));
}
return wPp;
}
return null;
}

OZ(up,"gxz",Jqk);
function Jqk(){
if(up.Zs<0){
up.f8s();
}else{

}
}

OZ(up,"KSn",Awm);
function Awm(){
if(up.Zs<0){
up.JUY();
}else{

}
}

LK(up,"f8s",nPh);
function nPh(){
if(up.oqP==0){
up.UdT=Lt.VB();
up.pP_(_g7.EQT,Ux.CS);

ct.qF(up.ww,"adStart(): adState changed to 'playing'");
}
up.oqP++;

up.On=false;
}

LK(up,"JUY",pBk);
function pBk(){
if(up.oqP>0){
up.oqP--;
if(up.oqP==0){
up.NwE=Lt.VB();
up.Kyd+=hR.SI(up.UdT,up.NwE);
up.pP_(_g7.EQT,Ux.cz);

ct.qF(up.ww,"adEnd(): adState changed to 'stopped'. adDuration: "+oL.fg(up.Kyd));
}
}
}

LK(up,"AmN",ed3);
function ed3(){
O9.y8(up.Zs<0,"Force pre-roll end after join.");
while(up.oqP>0){
up.JUY();
}
}

LK(up,"pP_",Bm6);
function Bm6(OlI,XvR){
var ZCf=new JHM(OlI,XvR);
up.FR.UY(ZCf);
}


dN(up,GY,"YaM",IKT);
function IKT(Su){
if(Su>GY.xM){
Su=Su/1000;
}
return Su;
}




if(up!=fj)up.SZ=false;
if(up!=fj)up.M7=false;
OZ(up,"c07",SBX);
function SBX(){return up.pF;}
OZ(up,"Zc1",Pp6);
function Pp6(){return up.Jq;}
OZ(up,"k5w",PNo);
function PNo(){return up.Ui;}
OZ(up,"A9",qYB);
function qYB(){return up.UJ;}
OZ(up,"s8t",qLG);
function qLG(nI){up.Xo(nI);}
OZ(up,"cmF",lSu);
function lSu(nI){up.cg(nI);}
OZ(up,"Y8n",leO);
function leO(fe,eq,hwT){
if(!up.Rf.Wt(eq)){
up.Rf.Yb(eq,new dk(up,eq,fe));
}
up.IE(VW.z_(fe),eq,hwT);
}
OZ(up,"tsM",Nzn);
function Nzn(oGx){up.qVe=oGx;}




















if(up!=fj)ju.apply(up,arguments);
}
Bg(GY,"GY");










function UV(){
var up=this;

if(up!=fj)up.q7=undefined;


if(up!=fj)up.CG=undefined;


if(up!=fj)up.lK=undefined;





if(up!=fj)up.Jq=undefined;


if(up!=fj)up.ei=0;


if(up!=fj)up.OK=0;


if(up!=fj)up.bZ=0;

function ju(pq,M9){
up.q7=pq;
up.Jq=M9;
up.CG=new EW();
up.CG.a9(Ux.CS,0);
up.CG.a9(Ux.DV,0);
up.lK=0;
up.ee();
}

OZ(up,"wy",NQ);
function NQ(){
if(up.q7==null)return;
up.q7=null;
up.CG=null;
}







LK(up,"Hr",n6);
function n6(eY,OM){
if(!up.CG.Wt(eY)){
up.CG.a9(eY,0);
}
up.CG.a9(eY,OM+up.CG.tc(eY));
}




OZ(up,"ee",mW);
function mW(){
if(up.q7==null)return;
up.ei=up.q7.mN(Ux.CS,0);
up.OK=up.q7.mN(Ux.DV,0);
var EK=up.q7.a1();
if(EK>=0){
up.bZ=EK;
}else{
up.bZ=0;
}
}






OZ(up,"Qv",Z_);
function Z_(){
if(up.q7==null)return;
var eV=up.q7.mN(Ux.CS,0);
up.Hr(Ux.CS,VW.z_(eV-up.ei));
up.ei=eV;

var fu=up.q7.mN(Ux.DV,0);
up.Hr(Ux.DV,VW.z_(fu-up.OK));
up.OK=fu;

var Ec=up.q7.a1();
if(Ec>=0){
up.lK+=VW.z_(Ec-up.bZ);
up.bZ=Ec;
}
}





OZ(up,"I2",Bq);
function Bq(){
var Wl=new aj();
Wl.M9=n4.z_(up.Jq);
Wl.WR=up.CG.tc(Ux.CS);
Wl.B0=up.CG.tc(Ux.DV);
if(up.lK>=0){
Wl.qt=up.lK;
}
return Wl;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(UV,"UV");






























function GyG(){
var up=this;



if(up!=fj)up.C4q=ConvivaContentInfo._6t;




if(up!=fj)up.Xti=-1;




if(up!=fj)up.Idf=-1;

function ju(pq,nYK){Pz.call(up,pq,nYK);
up.LWw=new EW();
up.XNs=null;

O9.y8(HkZ.gQA(up.Du),
"MonitorConvivaStreamerProxy(): streamerProxy is a "+up.BZ
+", which is not a type of ConvivaStreamerProxy.");
ct.qF(up.zSS(),"Starting monitoring for a proxy of type "+up.BZ);




Dh.YB("SetMonitoringNotifier",up.Du,
up.S5u);

}


OZ(up,"wy",NQ);
function NQ(){
if(up.Du!=null){
try{
Dh.YB("Cleanup",up.Du);
}catch(fe){
oL.fg(fe);
up.U7n("Cleanup() not found on streamer",GyG.PIu,null);
}
}
up.LWw=null;

up.Phwy();
}

LK(up,"bKY",ye0);
function ye0(f1){
var fm=f1.fm;

if(f1.stream!=null&&f1.stream.fm==StreamInfo.yhl&&up.aN.w6==null){

up.aN.ZOd(f1.stream.w6,GY.JRP);
}

if(f1.eY==nN7.Gi2)return;

var vXZ=((f1.stream.fm==StreamInfo.ct3)?up.Idf:((f1.stream.fm==StreamInfo.qme)?up.Xti:-1));
var mFB=(f1.stream.fm==StreamInfo.ct3)||(f1.stream.fm==StreamInfo.qme);

if((mFB)&&(f1.eY==nN7.bN5)){

if(up.C4q!=f1.stream.w6){

up.aN.PX9(f1.stream.M9,f1.stream.w6,GY.JRP,ky.hO);

up.Ia7(StreamerError.VR0("Chunk Download Error:",StreamerError.y4_,f1.stream));
}

if(vXZ!=f1.stream.M9){

up.aN.NVn(f1.stream.M9,WT0.hO);

up.Ia7(StreamerError.qM6("Chunk Download Error:",StreamerError.y4_,f1.stream,f1.z1Y));
}else{

up.Ia7(StreamerError.qM6("Chunk Download Error:",StreamerError.y4_,f1.stream,f1.z1Y));
}
}

if(f1.stream.fm==StreamInfo.ct3){
up.Idf=f1.stream.M9;
up.C4q=f1.stream.w6;
}else if(f1.stream.fm==StreamInfo.qme){
up.Xti=f1.stream.M9;
up.C4q=f1.stream.w6;
}
}




LK(up,"S5u",bVw);
function bVw(RoH,SVh){

O9.Yv(
function(){
switch(RoH){
case ConvivaStreamerProxy.yeD:
up.Ziw(SVh,false);
break;
case ConvivaStreamerProxy.xUm:
up.DNq(SVh);
break;
case ConvivaStreamerProxy.vHz:
if(SVh!=null){
up.kim(SVh);
}
break;
case ConvivaStreamerProxy.GMW:
var XA5=oL.PX(SVh);
if(XA5!=null){
up.aN.O0(XA5);
}
break;
case ConvivaStreamerProxy.x1x:
var laB=oL.fg(SVh);
ct.qF(up.zSS(),laB);
break;

case ConvivaStreamerProxy.kTl:
up.bKY((SVh));
break;
}
},"notificationFromConvivaStreamerProxy");
}






OZ(up,"wFZ",Ss1);
function Ss1(){
var C5r=null;
if(Dh.xI("GetTotalLoadedBytes",up.Du)){
var S5=Dh.YB("GetTotalLoadedBytes",up.Du);
C5r=up.Wux(S5,null,GyG.s5j,true);
}else{
up.U7n("GetTotalLoadedBytes() not found on streamer",GyG.s5j,null);
}

if(C5r==null){


C5r=new EW();
C5r.a9(ConvivaContentInfo._6t,0);
}
if(!up.kSi(C5r,up.XNs)){
up.LJ4("total bytes loaded decreased",GyG.s5j,null);
}
up.XNs=C5r;
return C5r;
}


OZ(up,"ML",zp);
function zp(){
O9.y8(up.aN!=null,"GetBufferLengthMs");
if(Dh.xI("GetBufferLengthMs",up.Du)){
var S5=Dh.YB("GetBufferLengthMs",up.Du);
return up.aC(S5,-1,GyG.O4X);
}else{
up.U7n("GetBufferLengthMs() not found on streamer",GyG.O4X,null);
return-1;
}
}



OZ(up,"sm",YG);
function YG(){

return up.Phsm();
}


OZ(up,"dD",CC);
function CC(){
O9.y8(up.aN!=null,"GetPlayheadTimeMs");
if(Dh.xI("GetPlayheadTimeMs",up.Du)){
var S5=Dh.YB("GetPlayheadTimeMs",up.Du);


return VW.z_(up.aC(S5,0,GyG.ZgI));
}else{
up.U7n("GetPlayheadTimeMs() not found on streamer",GyG.ZgI,null);
return 0;
}
}



OZ(up,"Ef",We);
function We(){
O9.y8(up.aN!=null,"GetFrameRate");
if(Dh.xI("GetRenderedFrameRate",up.Du)){
var S5=Dh.YB("GetRenderedFrameRate",up.Du);
return up.RG(S5,0,GyG.bTm);
}else{
up.U7n("GetRenderedFrameRate() not found on streamer",GyG.bTm,null);
return 0;
}
}


OZ(up,"a1",jn);
function jn(){
O9.y8(up.aN!=null,"GetDroppedFrames");
if(Dh.xI("GetDroppedFrames",up.Du)){
var S5=Dh.YB("GetDroppedFrames",up.Du);
return up.aC(S5,0,GyG.j8C);
}else{
up.U7n("GetDroppedFrames() not found on streamer",GyG.j8C,null);
return 0;
}
}


OZ(up,"TzN",Cav);
function Cav(){
O9.y8(up.aN!=null,"GetCapacityKbps");
var Vw4=new EW();

if(Dh.xI("GetCapacityKbps",up.Du)){
var oU8=Dh.YB("GetResource",up.Du);
var wW3=up.ZE9(oU8,ConvivaContentInfo._6t,GyG.RLD);
var AvO=Dh.YB("GetCapacityKbps",up.Du,wW3);
var FBf=up.aC(AvO,-1,GyG.RLD);
if(FBf>=0){
Vw4.a9(wW3,FBf);
}
}else{
up.U7n("GetCapacityKbps() not found on streamer",GyG.RLD,null);
}
if(Vw4.Bt==0){


Vw4.a9(ConvivaContentInfo._6t,0);
}
return Vw4;
}


OZ(up,"bvd",kLC);
function kLC(){
O9.y8(up.aN!=null,"GetServerAddress");
if(Dh.xI("GetServerAddress",up.Du)){
var Xo8=Dh.YB("GetServerAddress",up.Du);
return up.ZE9(Xo8,null,GyG._8_);
}else{
up.U7n("GetServerAddress() not found on streamer",GyG._8_,null);
return null;
}
}





OZ(up,"CDY",zEv);
function zEv(){
O9.y8(up.aN!=null,"IsPHTAccurate");
if(Dh.xI("GetIsPHTAccurate",up.Du)){
var NbJ=Dh.YB("GetIsPHTAccurate",up.Du);
return up.Trb(NbJ,true,GyG.Yhj);
}
return true;
}







LK(up,"Ziw",TKY);
function TKY(hb2,QFN){
var yKu=up.ZE9(hb2,ConvivaStreamerProxy.dHj,GyG.CmY);
var Uy=IcH.NXs(yKu);
if(SbG.xQ5(up.HS_())){
up.dGj(Uy,yKu,QFN);
}else{
up.wvV("playing state changed to "+Uy+" (\""+yKu+"\")",GyG.CmY,null);
if(QFN){
up.aN.xB(Uy);
}else{
up.aN.cg(Uy);
}
}
}





LK(up,"dGj",E8n);
function E8n(Uy,yKu,QFN){

if(up.aN.kws){
up.wvV("playing state changed to "+Uy+" (\""+yKu+"\")",GyG.CmY,null);
if(QFN){
up.aN.xB(Uy);
}else{
up.aN.cg(Uy);
}
}else{
up.LJ4("playing state reported as "+Uy+" (\""+yKu+"\"), "
+"but this will be ignored because state detection is incorrect before joining",
GyG.CmY,null);
return;
}
}





LK(up,"DNq",ymR);
function ymR(gBr){
var UFB=StreamInfo.QKZ(gBr);

if(UFB.w6!=null&&UFB.w6!=ConvivaContentInfo._6t&&up.aN.w6!=UFB.w6){

up.wvV("playing resource changed to "+UFB.w6,GyG.lON,null);
if(up.aN.w6==null){

up.aN.ZOd(UFB.w6,GY.JRP);

}else{
up.aN.PX9(UFB.M9,UFB.w6,GY.JRP,ky.I6);
return;
}
}
if(UFB.M9>0&&up.aN.Qk!=UFB.M9){
up.wvV("playing bitrate changed to "+UFB.M9,GyG.Ri3,null);
if(up.aN.Qk==-1){
up.aN.VpZ(UFB.M9);
}else{
up.aN.NVn(UFB.M9,WT0.I6);
}
}
}

LK(up,"Ia7",f4T);
function f4T(s_m){
var x_=StreamerError.QKZ(s_m);

up.aN.NId(x_.vo(),x_.stream.w6);

}

LK(up,"kim",Mtp);
function Mtp(s_m){
var x_=StreamerError.QKZ(s_m);
var S_L=up.FSf(x_.k3,RJ.Sz,GyG.JlQ);
var mes=null;
if(x_.stream!=null){
mes=up.QaG(x_.stream.w6,null,GyG.JlQ);
}
up.aN.IE(S_L,mes,up.aN.Jdf.ouW);
}


LK(up,"un_",yrD);
function yrD(Sk,U6,C2d){
var Su=up.aC(Sk,-1,C2d);
if(Su<=0){
up.LJ4("received a nonpositive bitrate",C2d,"bitrate: "+Su);
return U6;
}else{
return Su;
}
}

LK(up,"QaG",jCS);
function jCS(iW4,U6,C2d){
var sr=up.ZE9(iW4,null,C2d);
if(sr==null){
return U6;
}else if(sr==ConvivaContentInfo._6t){
up.LJ4("received the NO_RESOURCE resource",C2d,null);
return U6;
}else{
return sr;
}
}

LK(up,"ZE9",Jrd);
function Jrd(Sk,U6,C2d){
if(Sk==null){
up.LJ4("received an invalid string",C2d,"value was null");
return U6;
}
if(typeof(Sk)=='string')return Sk;
up.U7n("received an invalid string",C2d,"value was "+oL.fg(Sk)+" (expected a string)");
return U6;
}

LK(up,"aC",cI);
function cI(Sk,U6,C2d){
return up.RG(Sk,U6,C2d);
}

LK(up,"RG",hl);
function hl(Sk,U6,C2d){
if(Sk==parseFloat(Sk))return Sk;
up.LJ4("received an invalid double",C2d,"value was "+(Sk!=null?oL.fg(Sk):"null"));
return U6;
}

LK(up,"Trb",_2d);
function _2d(Sk,U6,C2d){
if(typeof Sk==="boolean")return Sk;
up.LJ4("received an invalid boolean",C2d,"value was "+(Sk!=null?oL.fg(Sk):"null"));
return U6;
}






LK(up,"Wux",C4K);
function C4K(Sk,U6,C2d,J_Y){
if(Sk==null){
up.LJ4("received an invalid dictionary",C2d,"value was null");
return U6;
}
var HO=oL.PX(Sk);
if(HO!=null){
if(J_Y){
var bC=HO.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

var gAS=up.ZE9(Tj,null,C2d);
if(gAS==null){
return U6;
}
}
}
return HO;
}else{
up.LJ4("received an invalid dictionary",C2d,"value was not of a recognized Dictionary type");
return U6;
}
}




OZ(up,"FSf",N1v);
function N1v(lNq,U6,C2d){
var vIG=up.ZE9(lNq,null,C2d);
if(vIG==null){

return U6;
}


if(SbG.zNM(vIG)){
return VW.z_(SbG.Xkm(vIG));
}











var KU=up.YTZ(vIG);
if(KU!=RJ.Sz)return VW.z_(KU);
up.U7n("unrecognized error \""+vIG+"\"",C2d,null);
return U6;
}

LK(up,"YTZ",yAI);
function yAI(Voi){
switch(Voi){

case "Error loading media: File not found":
return RJ.MUM;
case "Error loading media: File could not be played":
return RJ.DtU;
case "Error loading YouTube: Video ID is invalid":
return RJ.fq_;
case "Error loading YouTube: Video removed or private":
return RJ.Jxt;
case "Error loading YouTube: Embedding not allowed":
return RJ.eos;
case "Error loading YouTube: API connection error":
return RJ.PSL;
case "Error loading stream: Could not connect to server":
return RJ.jkg;
case "Error loading stream: ID not found on server":
return RJ.dFq;
case "Error loading stream: Manifest not found or invalid":
return RJ.R2Z;
case "Error loading playlist: Playlist not found or invalid":
return RJ.Kc7;
case "Cannot load M3U8: crossdomain access denied":
return RJ.UfL;
case "Cannot load M3U8: 404 not found":
return RJ.iQf;
case "AES decryption not supported in Premium edition":
return RJ.xKt;
case "Cannot load M3U8: No levels to play":
return RJ.Esp;
case "Other JWPlayer errors":
return RJ.Y8v;

default:
return RJ.Sz;
}
}


LK(up,"HS_",IJz);
function IJz(){
O9.y8(up.aN!=null,"GetStreamerType");
if(Dh.xI("GetStreamerType",up.Du)){
var q1b=Dh.YB("GetStreamerType",up.Du);
return up.ZE9(q1b,null,GyG.el0);
}else{
up.LJ4("GetStreamerType() not found on streamer",GyG.el0,null);
return null;
}
}












if(up!=fj)up.LWw=undefined;



if(up!=fj)up.XNs=undefined;


if(up==fj)GyG.CmY="playing state";
if(up==fj)GyG.Ri3="bitrate state";
if(up==fj)GyG.lON="resource state";
if(up==fj)GyG.A9e="switching state";
if(up==fj)GyG.JlQ="error reporting";
if(up==fj)GyG.So_="metadata tracking";
if(up==fj)GyG.RLD="downloading capacity";
if(up==fj)GyG.j8C="dropped frames";
if(up==fj)GyG.bTm="frame rate";
if(up==fj)GyG.ZgI="playhead time";
if(up==fj)GyG.O4X="buffer length";
if(up==fj)GyG.s5j="bytes loaded";
if(up==fj)GyG._8_="server address";
if(up==fj)GyG.el0="streamer type";
if(up==fj)GyG.Yhj="is PHT accurate";
if(up==fj)GyG.PIu="cleanup";

LK(up,"zSS",sh3);
function sh3(){
return "M["+up.aN.id+"]: MonitorConvivaStreamerProxy";
}

LK(up,"kSi",aU9);
function aU9(CGr,Bsn){
if(Bsn==null){
return true;
}else if(CGr==null){
return false;
}
var bC=Bsn.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

if(!CGr.Wt(Tj)){
return false;
}else if(CGr.tc(Tj)<Bsn.tc(Tj)){
return false;
}
}
return true;
}



LK(up,"ocW",acM);
function acM(rU,C2d){
if(up.LWw==null){
return false;
}
if(up.LWw.Wt(C2d)
&&up.LWw.tc(C2d)==rU){
return false;
}else{
up.LWw.a9(C2d,rU);
return true;
}
}

LK(up,"U7n",gsn);
function gsn(rU,C2d,gp){
if(up.ocW(rU,C2d)){
var lXM=(gp!=null?" ("+gp+")":"");
O9.Ep("Bad input for the "+C2d+" component: "
+rU
+lXM
+".",
true);
}
}

LK(up,"LJ4",Z1b);
function Z1b(rU,C2d,gp){
if(up.ocW(rU,C2d)){
ct.qF(up.zSS(),"Warning: Suspicious input for the "+C2d+" component: "
+rU+
(gp!=null?" ("+gp+")":"")
+".");
}
}

LK(up,"wvV",Vrt);
function Vrt(rU,C2d,gp){
if(up.ocW(rU,C2d)){
ct.qF(up.zSS(),"Input for the "+C2d+" component: "
+rU+
(gp!=null?" ("+gp+")":"")
+".");
}
}
















if(up!=fj)ju.apply(up,arguments);
}
Bg(GyG,"GyG");









function to(){
var up=this;
if(up!=fj)up.vV=false;


if(up!=fj)up.Ymu=iV.KVT().match(/Android/)!=null;


if(up!=fj)up.zE4=undefined;

function ju(pq,G_){
Pz.call(up,pq,G_);

up.vV=false;


if(up.aN&&up.aN.CI&&up.aN.CI.Ay
&&!up.aN.CI.Ay.xQh){
if(up.Du&&up.Du.src){
up.aN.CI.Ay.xQh=up.Du.src;
}
}


ZI7("loadstart",function(){
});

ZI7("loadeddata",function(){
});
ZI7("ended",function(){
U2("stopped","ended event");
});
ZI7("pause",function(){

U2("paused","pause event");
});
ZI7("seeking",function(){




});
ZI7("playing",function(){
ij("playing");
U2("playing","playing event");
});
ZI7("emptied",function(){
U2("buffering","emptied event");
});
ZI7("stalled",function(){
if(!up.Du)return;
if(up.Du.paused){
PF("ignore stalled event: streamer is paused");
return;
}
U2("buffering","stalled event");
});
ZI7("waiting",function(){
if(!up.Du)return;
if(!up.Du.seeking){

U2("buffering","waiting event");
}else{
PF("ignore waiting event");
}
});
ZI7("error",function(){
if(!up.Du)return true;
if(up.Du){


if(up.Du.error){
var KU=up.Du.error.code;
up.aN.IE(Hs(KU),null);
up.aN.cg(Ux.QG);
}
}
return true;
});
ZI7("loadedmetadata",Jz);


Ngd();


up.zE4=up.Du.M19;

{
if(up.Du.readyState==0){

U2("stopped","have nothing");
}else if(up.Du.ended){
U2("stopped","init ended");
}else if(up.Du.paused||up.Du.seeking){
U2("paused","init paused or seeking");
}else{
ij("playing");
U2("playing","init have data and network");
}

if(up.Du.readyState>=up.Du.HAVE_METADATA){
Jz();
}
}

}


function Ngd(){
if(typeof(up.Du.children)!=="undefined"){
up.Du.d7A=up.Du.children;
for(var co=0;co<up.Du.d7A.length;co++){
var bWS=up.Du.d7A[co];
if(bWS.tagName=="SOURCE"){
nD.nL(bWS,"error",function(){


PF("caught non-specific error from <source> element, reporting eHTML5ErrUnknown");
up.aN.IE(Hs(5),null);
up.aN.cg(Ux.QG);
});
}
}
}
}

function PF(rU){
ct.qF("MonitorHTMLElement",rU);
}



if(up!=fj)up.SN0=[];

function ZI7(Sp,YM){
up.SN0.push([Sp,YM]);
nD.nL(up.Du,Sp,YM);
}

OZ(up,"wy",NQ);
function NQ(){

var co;
for(co=0;co<up.SN0.length;co++){
var VkW=up.SN0[co];
nD.Pi5(up.Du,VkW[0],VkW[1]);
}
up.SN0=[];

up.Phwy();
}


OZ(up,"dD",CC);
function CC(){
if(!up.Du)return 0;




if(iV.pD=="Firefox"){

var zE4=up.zE4;


up.zE4=up.Du.readyState;
if(!up.Du.seeking&&
!up.Du.paused&&
!up.Du.ended){
if(up.Du.readyState==up.Du.HAVE_CURRENT_DATA&&
zE4>=up.Du.HAVE_FUTURE_DATA){
U2("buffering","transition from HAVE_FUTURE_DATA to HAVE_CURRENT_DATA");
}




}
}
return n4.z_(1000*up.Du.currentTime);
}


OZ(up,"ML",zp);
function zp(){
if(!up.Du)return-1;
var Bp=up.Du.currentTime;
var buffered=up.Du.buffered;
if(buffered==undefined){

return-1;
}
var S5=0;
for(var co=0;co<buffered.length;co++){
var start=buffered.start(co);
var end=buffered.end(co);
if(start<=Bp&&Bp<end){
S5+=end-Bp;
}
}
return VW.z_(1000*S5);
}


function ij(Sp){
if(!up.vV){
PF("Initial start due to event "+Sp);
up.vV=true;
up.aN.IE(RJ.G8,null);
}
}





function uB2(){


return up.Ymu;
}

function LIh(){
return(up.aN==null||!up.aN.kws);
}

function U2(eY,aK){
if(!up.Du)return;



if(eY=="playing"&&LIh()&&uB2()){
PF("StateChange: (HTML5 Android) IGNORED "+eY+": "+aK);
return;
}
PF("StateChange: "+eY+": "+aK);
up.aN.cg(to.pu(eY));
}

dN(up,to,"pu",mj8);
function mj8(eY){
switch(eY){
case "playing":return Ux.CS;
case "buffering":return Ux.DV;
case "stopped":return Ux.cz;
case "paused":return Ux.Qh;
default:
SH.z2("Unrecognized HTML5 state: "+eY);
return Ux.ft;
}
}

function Hs(KU){


switch(KU){
case 1:
return RJ.kI;
case 2:
return RJ.bj;
case 3:
return RJ.AF;
case 4:
return RJ.ks;
default:
return RJ.m8;
}
}

function Jz(){
if(up.Du==null)return;
ij("loadedmetadata");
var E7=new EW();
var duration=up.Du.duration;
if(duration!=undefined&&duration!=NaN&&duration!=Infinity){
E7.a9("duration",duration.toString());
}
if(E7.Bt>0){
up.aN.O0(E7);
}
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(to,"to");









function e_W(){
var up=this;
if(up!=fj)up.vV=false;


if(up!=fj)up.zE4=undefined;

function ju(pq,G_){
Pz.call(up,pq,G_);

up.vV=false;


ZI7("qt_load",function(){
});
ZI7("qt_ended",function(){
U2("stopped","ended event");
});
ZI7("qt_pause",function(){
U2("paused","playing event");











});
ZI7("qt_play",function(){
ij("playing");
U2("playing","playing event");
});
ZI7("qt_stalled",function(){
U2("buffering","stalled event");
});
ZI7("qt_waiting",function(){
if(!up.Du)return;
if(!up.Du.GetPluginStatus()=="Waiting"){

U2("buffering","waiting event");
}else{
PF("ignore waiting event");
}
});
ZI7("qt_error",function(){
if(!up.Du)return true;
if(up.Du){
var KU=up.Du.GetPluginStatus();


up.aN.IE(Hs(100),null);
up.aN.cg(Ux.QG);
}
return true;
});
ZI7("qt_loadedmetadata",Jz);


up.zE4=up.Du.M19;

{
if(up.Du.GetDuration()==0){

U2("stopped","have nothing");
}else if(up.Du.GetRate()==0&&up.Du.GetTime()==0){
U2("stopped","init ended");
}else if(up.Du.GetRate()==0){
U2("paused","init paused or seeking");
}else{
ij("playing");
U2("playing","init have data and network");
}
}

}

function PF(rU){
ct.qF("MonitorQTElement",rU);
}



if(up!=fj)up.SN0=[];

function ZI7(Sp,YM){
up.SN0.push([Sp,YM]);
nD.nL(up.Du,Sp,YM);
}

OZ(up,"wy",NQ);
function NQ(){

var co;
for(co=0;co<up.SN0.length;co++){
var VkW=up.SN0[co];
nD.Pi5(up.Du,VkW[0],VkW[1]);
}
up.SN0=[];

up.Phwy();
}


OZ(up,"dD",CC);
function CC(){
if(!up.Du)return 0;


return n4.z_(1000*up.Du.GetTime()/up.Du.GetTimeScale());
}


OZ(up,"ML",zp);
function zp(){
if(up.Du.GetMaxTimeLoaded()>=up.Du.GetTime()){
return n4.z_(1000*(up.Du.GetMaxTimeLoaded()-up.Du.GetTime())/up.Du.GetTimeScale());
}else{
return-1;
}
}


function ij(Sp){
if(!up.vV){
PF("Initial start due to event "+Sp);
up.vV=true;
up.aN.IE(RJ.G8,null);
}
}


function U2(eY,aK){
if(!up.Du)return;
PF("StateChange: "+eY+": "+aK);
up.aN.cg(e_W.pu(eY));
}

dN(up,e_W,"pu",mj8);
function mj8(eY){
switch(eY){
case "playing":return Ux.CS;
case "buffering":return Ux.DV;
case "stopped":return Ux.cz;
case "paused":return Ux.Qh;
default:
SH.z2("Unrecognized HTML5 state: "+eY);
return Ux.ft;
}
}

function Hs(KU){


switch(KU){
case 1:
return RJ.kI;
case 2:
return RJ.bj;
case 3:
return RJ.AF;
case 4:
return RJ.ks;
default:
return RJ.m8;
}
}

function Jz(){
if(up.Du==null)return;
ij("loadedmetadata");
var E7=new EW();
var duration=up.Du.duration;
if(duration!=undefined&&duration!=NaN&&duration!=Infinity){
E7.a9("duration",duration.toString());
}
if(E7.Bt>0){
up.aN.O0(E7);
}
}

if(up!=fj)ju.apply(up,arguments);
}
Bg(e_W,"e_W");








function dk(){
var up=this;


if(up!=fj)up.go=undefined;
if(up!=fj)up.bl=undefined;


if(up!=fj)up.q7=undefined;









if(up!=fj)up.mQ=undefined;

if(up!=fj)up.yg=0;
if(up!=fj)up.Xm=0;


if(up!=fj)up.Jc=0;

if(up!=fj)up.Gi=0;







if(up!=fj)up.GMe=undefined;

if(up!=fj)up.yXr=undefined;


if(up!=fj)up.lG=0;


if(up!=fj)up.dV=0;


if(up!=fj)up.mI=0;


if(up!=fj)up.Ah=-1;


if(up!=fj)up.jY=0;


if(up!=fj)up.Gb=0;


if(up!=fj)up.M5=0;


if(up!=fj)up.la=0;
if(up!=fj)up.xw=0;

function ju(pq,w6,rZ){
up.go=w6;
up.bl=rZ;

up.q7=pq;

up.Jc=0;
up.Gi=0;
up.mQ=0;
up.yg=0;
up.Xm=0;
up.GMe=new Yw();
up.yXr=new Yw();
}

OZ(up,"wy",NQ);
function NQ(){
up.go="";
up.q7=null;
up.mQ=0;
up.yg=0;
up.Xm=0;
up.lG=0;
up.dV=0;
up.mI=0;
if(up.GMe!=null){
up.GMe.m3();
up.GMe=null;
}
if(up.yXr!=null){
up.yXr.m3();
up.yXr=null;
}
}











OZ(up,"BQ",Wm);
function Wm(qfr,MB8){
if(up.q7.ca==Ux.nw)return;
var kz=Lt.VB();



var LD=up.q7.mN(Ux.CS,kz);
var vG=up.q7.ML();
var uG=up.q7.sm();
if(vG>0){
vG=Math.min(vG,Math.max(uG*2,up.q7.Wg));
LD+=vG;
}
if((qfr>0&&!up.q7.M7)||up.q7.SZ){

if(qfr>=up.yg){

up.mQ+=(qfr-up.yg);
}else{



if(qfr+oL.fFw(n4.Je)+1-up.yg<10000000){



up.mQ+=(qfr+oL.fFw(n4.Je)+1-up.yg);
}
}
up.mQ+=up.la;
up.q7.Ce=false;
up.yg=qfr;
}else if(MB8){








var lS=LD-up.Xm+up.xw;



if(lS>0&&up.q7.Qk>0){

up.mQ+=(lS*oL.fFw(up.q7.Qk)/8);

up.mQ=Math.floor(up.mQ+0.5);
}

if(up.mQ>0){
up.q7.Ce=true;
}
}
up.Xm=LD;
}

OZ(up,"ou",HA);
function HA(OJP,MB8,Uo,pM){
up.la+=Uo;
up.xw+=pM;
up.BQ(OJP,MB8);
up.la=0;
up.xw=0;
}





















OZ(up,"T1",ej);
function ej(bEj,MB8,ok7,Qk){
var kb=up.mQ;
up.BQ(bEj,MB8);
if(!ok7){


up.mQ=kb;
}
up.Gb=up.q7.mN(Ux.CS,0);
up.M5=up.q7.mN(Ux.DV,0);
if(Qk>0){
up.Ah=Qk;
up.jY=up.Gb;
}
}




OZ(up,"lE",KX);
function KX(){
if(up.Gb>=0){
var ny=up.q7.mN(Ux.CS,0);
up.lG+=(ny-up.Gb);
up.Gb=ny;
if(up.Ah>0){
up.mI+=
(ny-up.jY)*up.Ah/1000;
up.jY=ny;
}
}
if(up.M5>=0){
var cK=up.q7.mN(Ux.DV,0);

if(up.q7.dv>=0){
up.dV+=(cK-up.M5);
}
up.M5=cK;
}
}




OZ(up,"FW",w2);
function w2(k3){

up.L7P(k3,up.GMe);

up.L7P(k3,up.yXr);
}








LK(up,"L7P",ygL);
function ygL(k3,V4){

var bC=V4.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var EU=bC[Jo];

if(EU.k3==k3){
EU.Mf++;
return;
}
}

var xv=new RJ();
xv.Mf=1;
xv.k3=VW.z_(k3);
V4.Yb(xv);
}

OZ(up,"Ybu",Rvf);
function Rvf(){
up.yXr.m3();
up.yXr=new Yw();
}




OZ(up,"fC",s6);
function s6(oe){
var uT=new PL();

uT.Xt=L_.Ho(up.mQ);


uT.ws=0;


uT.Jc=up.Jc;
uT.Gi=up.Gi;
uT.w6=_U.vD(up.go,up.bl);


uT.V4iy(up.GMe.jR());
uT.WR=VW.z_(up.lG);
uT.B0=VW.z_(up.dV);
uT.iO=VW.z_(up.mI);
return uT;
}


OZ(up,"TO",am);
function am(Ck){

}

OZ(up,"Qk",Sy);
function Sy(M9){
if(M9!=up.Ah){
up.lE();
up.Ah=M9;
up.jY=
up.q7.mN(Ux.CS,0);
}
}



ED(up,"rZ",d_);
function d_(){return up.bl;}
Wf(up,"rZ",qw);
function qw(nQ){up.bl=nQ;}

ED(up,"w6",dO);
function dO(){return up.go;}

ED(up,"uJp",FYF);
function FYF(){return up.GMe;}

ED(up,"vtV",bh3);
function bh3(){return up.yXr;}

ED(up,"Wr8",ibB);
function ibB(){return up.lG;}

ED(up,"SeK",cVc);
function cVc(){return up.dV;}

ED(up,"KCU",i4q);
function i4q(){return up.mQ;}
if(up!=fj)ju.apply(up,arguments);
}
Bg(dk,"dk");





function UO(){
var up=this;
if(up!=fj)up.oe=undefined;
if(up!=fj)up.Xt=undefined;
function ju(s9,Au){
up.oe=s9;
up.Xt=Au;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(UO,"UO");















function Pz(){
var up=this;



if(up!=fj)up.Du=undefined;

if(up!=fj)up.BZ=undefined;

if(up!=fj)up.aN=undefined;


function ju(pq,G_){
up.aN=pq;
up.BZ=HkZ.D4(G_);
up.Du=G_;
}





OZ(up,"nj",i4);
function i4(){
var Na=null;
switch(up.BZ){
case "HTMLVideoElement":
Na="html5";
break;
case "QTElement":
Na="qt";
break;
}
if(Na==null){
if(HkZ.gQA(up.Du)){
Na="csp";
}else{
Na=up.BZ;
}
}
return Na;
}


dN(up,Pz,"Z9",qg);
function qg(pq,G_){
var sD=HkZ.D4(G_);
var OM=null;
if(HkZ.gQA(G_)){
return new GyG(pq,G_);
}
if(sD&&oL.Pe(sD,"HTMLVideoElement")){
OM=new to(pq,G_);
}else if(sD&&oL.Pe(sD,"QTElement")){
OM=new e_W(pq,G_);
}

if(OM==null){
if(sD==null){
sD="null";
}



if(O9.rV()<0.01){
O9.FW("Unrecognized streamer object "+sD);
}else{
ct.Error("MonitorStreamer","Unrecognized streamer object "+sD);
}
}
return OM;
}


OZ(up,"wy",NQ);
function NQ(){
if(up.Du==null)return;
up.aN=null;
up.Du=null;
}


ED(up,"Rj",AI);
function AI(){return up.Du;}












OZ(up,"T2",wH);
function wH(){
return 0;
}













OZ(up,"wFZ",Ss1);
function Ss1(){


var lb=new EW();
lb.a9(ConvivaContentInfo._6t,up.T2());
return lb;
}







OZ(up,"WIj",Eim);
function Eim(){
return 0;
}


OZ(up,"ML",zp);
function zp(){
return-1;
}


OZ(up,"sm",YG);
function YG(){
return-1;
}


OZ(up,"dD",CC);
function CC(){
return-1;
}


OZ(up,"Ef",We);
function We(){
return-1.0;
}






OZ(up,"a1",jn);
function jn(){
return-1;
}












OZ(up,"Q1",zt);
function zt(){
return 0;
}














OZ(up,"TzN",Cav);
function Cav(){


var lb=new EW();
lb.a9(ConvivaContentInfo._6t,up.Q1());
return lb;
}



OZ(up,"zqG",f36);
function f36(){
return-1;
}




OZ(up,"bvd",kLC);
function kLC(){
return null;
}






OZ(up,"CDY",zEv);
function zEv(){
return true;
}


if(up!=fj)up.SZ=false;
if(up!=fj)up.M7=false;
if(up!=fj)ju.apply(up,arguments);
}
Bg(Pz,"Pz");













function SbG(){
var up=this;



if(up==fj)SbG.Wny="c3.";


function ju(){
O9.FW("MonitorUtils: is a singleton");
}











dN(up,SbG,"Zi7",lt1);
function lt1(Od4){
return SbG.Wny+Od4;
}

dN(up,SbG,"zNM",YN2);
function YN2(u2Q){
if(oL.w_(u2Q,SbG.Wny)!=0){
return false;
}
var S5=true;
try{
var gFZ=parseInt(oL.n0(u2Q,SbG.Wny.length));
if(isNaN(gFZ)){
return false;
}
}catch(fe){
oL.fg(fe);
S5=false;
}
return S5;
}






dN(up,SbG,"Xkm",tit);
function tit(Voi){
var lb=-1;
try{
var IHm=parseInt(oL.n0(Voi,SbG.Wny.length),10);
if(isNaN(IHm)){
return-1;
}else{
lb=VW.z_(IHm);
}
}catch(fe){
oL.fg(fe);
ct.Error("MonitorUtils.ErrorStringToErrorElement()",Voi+" cannot be converted to an error code.");
lb=-1;
}
return lb;
}











dN(up,SbG,"ost",QZI);
function QZI(){
return "dD";
}
dN(up,SbG,"EvG",X4I);
function X4I(){
return "ML";
}
dN(up,SbG,"UrV",b0b);
function b0b(){
return "a1";
}
dN(up,SbG,"wwL",nYu);
function nYu(){
return "TzN";
}
dN(up,SbG,"xTy",ghn);
function ghn(){
return "wFZ";
}
dN(up,SbG,"rHY",KFY);
function KFY(){
return "bvd";
}
dN(up,SbG,"m7M",Y0X);
function Y0X(){
return "HS_";
}

dN(up,SbG,"xQ5",BUm);
function BUm(q1b){
if(q1b==SbG.mGZ){
return true;
}



return false;
}
if(up==fj)SbG.mGZ="c3.xboxStreamerType";



if(up!=fj)ju.apply(up,arguments);
}
Bg(SbG,"SbG");





















function GnC(){
var up=this;


if(up!=fj)up.GjQ=null;

function ju(G_,Bii){ConvivaStreamerProxy.call(up);
up.GjQ=G_;

Dh.HM("SU",up.GjQ,up._M1);
Dh.HM("by",up.GjQ,up.RS);
var mEM=
function(Oo,rZ){up.Yg2(Oo);};
Dh.HM("IV",up.GjQ,mEM);
Dh.HM("lYM",up.GjQ,up.Zhd);
var zRs=up.fjQ;
Dh.HM("Ru",up.GjQ,zRs);
Dh.HM("a4u",up.GjQ,up.Ez7);



if(Dh.hB("fF",up.GjQ)){
var CBz=Dh.JQ("fF",up.GjQ);
up.eco(IcH.i2y(up.aC(CBz,IcH.ft)));
}

var X0T=-1;
if(Dh.hB("T6",up.GjQ)){
var TYT=Dh.JQ("T6",up.GjQ);
X0T=up.aC(TYT,-1);
}
var FEG=ConvivaContentInfo.jNU;
var JPe=ConvivaContentInfo._6t;
if(Dh.hB("TpK",up.GjQ)){
var JCH=Dh.JQ("TpK",up.GjQ);
JPe=up.ZE9(JCH,ConvivaContentInfo._6t);
}
up.cQi(new StreamInfo(X0T,FEG,JPe,-1,-1,-1));

}

OZ(up,"Cleanup",NQ);
function NQ(){
if(up.GjQ==null)return;
Dh.HM("SU",up.GjQ,null);
Dh.HM("by",up.GjQ,null);
Dh.HM("IV",up.GjQ,null);
Dh.HM("lYM",up.GjQ,null);
Dh.HM("Ru",up.GjQ,null);
Dh.HM("r9i",up.GjQ,null);
up.PhCleanup();
}









LK(up,"Ez7",lvV);
function lvV(k3,w6){
var KRi=up.M8p();
var ZTN=new StreamInfo(KRi.M9,KRi._fK,w6,-1,-1,-1);
var x_=StreamerError.YKZ(SbG.Zi7(k3),
StreamerError.VuW,ZTN);
up.rpy(x_);
}




LK(up,"_M1",rxZ);
function rxZ(Uy){
up.eco(IcH.i2y(Uy));
}


LK(up,"RS",CU);
function CU(SlC){
up.sgt(SlC);
}


LK(up,"Yg2",jMe);
function jMe(qSY){
up.xQX(qSY);
}


LK(up,"Zhd",NjT);
function NjT(qSY,SlC){
up.cQi(new StreamInfo(SlC,null,qSY,-1,-1,-1));
}


LK(up,"fjQ",aF5);
function aF5(UFr){
up.Pmd(UFr);
}

OZ(up,"GetPlayheadTimeMs",CC);
function CC(){
var Sj=SbG.ost();
if(Dh.xI(Sj,up.GjQ)){
var S5=Dh.YB(Sj,up.GjQ);

return VW.z_(up.g_(S5,0));
}else{
return 0;
}
}

OZ(up,"GetBufferLengthMs",zp);
function zp(){
var Sj=SbG.EvG();
if(Dh.xI(Sj,up.GjQ)){
var S5=Dh.YB(Sj,up.GjQ);
return up.aC(S5,-1);
}else{
return-1;
}
}

OZ(up,"GetRenderedFrameRate",JVG);
function JVG(){
if(Dh.xI("Ef",up.GjQ)){
var S5=Dh.YB("Ef",up.GjQ);
return up.RG(S5,-1.0);
}else{
return-1.0;
}
}

OZ(up,"GetDroppedFrames",jn);
function jn(){
var Sj=SbG.UrV();
if(Dh.xI(Sj,up.GjQ)){
var S5=Dh.YB(Sj,up.GjQ);
return up.aC(S5,-1);
}else{
return-1;
}
}


OZ(up,"GetCapacityKbps",Cav);
function Cav(w6){
var Sj=SbG.wwL();
if(Dh.xI(Sj,up.GjQ)){
var S5=Dh.YB(Sj,up.GjQ);
var sMX=null;
sMX=up.pKb(S5,null);
if(sMX!=null){
if(sMX.Wt(w6)){
return sMX.tc(w6);
}
}
}
return-1;
}

OZ(up,"GetTotalLoadedBytes",Ss1);
function Ss1(){
var Sj=SbG.xTy();
if(Dh.xI(Sj,up.GjQ)){
var S5=Dh.YB(Sj,up.GjQ);
return up.pKb(S5,null);
}else{
return null;
}
}


OZ(up,"GetServerAddress",kLC);
function kLC(){
var Sj=SbG.rHY();
if(Dh.xI(Sj,up.GjQ)){
var Xo8=Dh.YB(Sj,up.GjQ);
return up.ZE9(Xo8,null);
}else{
return null;
}
}

OZ(up,"GetStreamerType",IJz);
function IJz(){
var Sj=SbG.m7M();
if(Dh.xI(Sj,up.GjQ)){
var q1b=Dh.YB(Sj,up.GjQ);
return up.ZE9(q1b,null);
}else{
return null;
}
}

LK(up,"RG",hl);
function hl(Sk,U6){
if(Sk==parseFloat(Sk))return Sk;
return U6;
}

LK(up,"aC",cI);
function cI(Sk,U6){
return up.RG(Sk,U6);
return U6;
}

LK(up,"g_",u7);
function u7(Sk,U6){
return up.RG(Sk,U6);
return U6;
}

LK(up,"ZE9",Jrd);
function Jrd(Sk,U6){
if(typeof(Sk)=='string')return Sk;
return U6;
}

LK(up,"pKb",gq1);
function gq1(Sk,U6){
var lb=oL.PX(Sk);
if(lb==null){
return U6;
}else{
return lb;
}
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(GnC,"GnC");
















function ffH(){
var up=this;
if(up!=fj)up.agG=0;
if(up!=fj)up.sQ3=undefined;

function ju(FBf){
up.agG=FBf;
up.sQ3=new Yw();
}

OZ(up,"wy",NQ);
function NQ(){
up.agG=0;
up.sQ3.m3();
}







OZ(up,"i6Y",vVe);
function vVe(sq){
var HO=null;
if(up.sQ3.Bt>=up.agG){
HO=up.sQ3.tc(0);
up.sQ3.DU(0);
}
up.sQ3.gX(up.sQ3.Bt,sq);
return HO;
}

OZ(up,"VAx",AXw);
function AXw(co){
if(co<0||co>=up.sQ3.Bt){
throw new Error("ElementAt outside bounds");
}
return up.sQ3.tc(co);
}

OZ(up,"QR7",p3k);
function p3k(){
var S5=null;
if(up.sQ3.Bt>0){
S5=up.sQ3.tc(0);
up.sQ3.DU(0);
}
return S5;
}




ED(up,"jQH",GF8);
function GF8(){return up.agG;}

ED(up,"nB2",k7P);
function k7P(){return up.sQ3;}

ED(up,"ug",IPr);
function IPr(){return up.sQ3.Bt;}

if(up!=fj)ju.apply(up,arguments);
}
Bg(ffH,"ffH");








function Tp(){
var up=this;

if(up==fj)Tp.sKi=0;


if(up==fj)Tp.CmH=0;


Va(up,Tp,"Cz",DDP);
function DDP(){
return Tp.sKi;
}
Z0(up,Tp,"Cz",Hno);
function Hno(nQ){
Tp.sKi=nQ;
Tp.CmH=Lt.fp();
}


Va(up,Tp,"oEM",GE2);
function GE2(){
return Tp.CmH;
}

dN(up,Tp,"wy",NQ);
function NQ(){
Tp.sKi=0;
Tp.CmH=0;
}










dN(up,Tp,"Flu",EV0);
function EV0(){
if(Tp.sKi==0)return 0;
return Lt.fp()-Tp.CmH+Tp.sKi;
}











Va(up,Tp,"IM1",nAS);
function nAS(){
return Tp.CmH;
}
Z0(up,Tp,"IM1",tX5);
function tX5(nQ){
Tp.CmH=nQ;
}
}
Bg(Tp,"Tp");













function XO(){
var up=this;

dN(up,XO,"k8",PXz);
function PXz(S5,vw){
var lb=("Stats: "+((vw==null)?"":"Id="+vw.JZ)
+" Seq="+S5.Nm
+" S="+S5.fF
+" Tot="+S5.Ky
+" PHT="+S5.EA
+" CLSec="+vw.cX
+" TPl="+S5.zg
+" TB="+S5.zc
+" Buffer="+S5.vG
+" TPa="+S5.rp
+" TS="+S5.LI
+" AFR="+S5.IC
+" PAFR="+S5.sb
+" EFR="+S5.jD
+" J="+S5.dv
+" SRAv="+S5._f
+" SRMax="+S5.ps
+" BW="+S5.vi
+" ");

var bC=S5.uXxz().YC;
for(var Jo=0;Jo<bC.length;Jo++){
var xk=bC[Jo];

lb+=XO.BQw(xk)+" ";
}
var HH=S5._7xz().YC;
for(var wt=0;wt<HH.length;wt++){
var sL=HH[wt];

lb+="bitrateUse["+sL.M9
+"]={ BitratePlayTime="+sL.WR
+" BitrateBufTime="+sL.B0
+" droppedFrames="+sL.qt+" } ";
}
return lb;
}


dN(up,XO,"BQw",c3Z);
function c3Z(yo){
return("resourceUse["+(yo.w6!=null&&yo.w6.yWkn()?oL.fg(yo.w6.kn):"?")+"]{"
+" Bytes="+oL.fg(yo.Xt)
+" ResPlayTime="+yo.WR
+" ResBufTime="+yo.B0
+" BitrateWtSum="+yo.iO+" } ");
}

dN(up,XO,"lSL",JTv);
function JTv(EhS){
if(EhS.wf){
return EhS.C6.T3();
}else{
return oL.fg(EhS.kn);
}
}

dN(up,XO,"Iru",S3F);
function S3F(y_){
var S5="SR seq="+oL.fg(y_.Nm);
for(var co=0;co<VW.z_(y_.BcXG());co++){
var ScF=y_.Bcbh(n4.z_(co));
S5+=" r"+oL.fg(co)+"="+XO.lSL(ScF.w6);
}
return S5;
}

dN(up,XO,"QKK",qeM);
function qeM(WJ){
if(WJ==null)return null;
return UF.Y_(WJ.UX());
}

dN(up,XO,"RnF",khi);
function khi(fh){
return Vz.Y_(fh.UX());
}
}
Bg(XO,"XO");

















function yqn(){
var up=this;


if(up!=fj)up.aN=undefined;
if(up!=fj)up.NRD=undefined;


if(up!=fj)up.wjY=undefined;
if(up!=fj)up.Rk=false;


function ju(){
up.aN=null;
up.NRD=null;
up.Rk=false;
up.wjY=null;
}

OZ(up,"OqY",wYW);
function wYW(){
var rT=WP.rT;
var amN=new fRx();
if(rT!=null){
amN.rT=
oL.fg(rT.uv)+"."+
oL.fg(rT.wG)+"."+
oL.fg(rT.VY);
}

if(up.Rk){
amN.LZy=VW.z_(X6Z.GZI);
}else{
amN.LZy=VW.z_(X6Z.KFJ);
}

var QxU=iV.Qpq;
if(QxU!=null){
if(QxU.length>ConvivaContentInfo.L1){
QxU=oL.n0(QxU,0,ConvivaContentInfo.L1);
}
amN.QxU=QxU;
}

if(up.aN!=null){
if(up.aN.nj()!=null){
amN.co2=up.aN.nj();
}
}

if(up.NRD!=null){
if(up.NRD.cex){
amN.MNx=VW.z_(X6Z.Jb0);
}else{
amN.MNx=VW.z_(X6Z.D2p);
}
}
if(up.wjY!=null){
up.wjY.UY(amN);
}
}

OZ(up,"ox",gv);
function gv(){
up.NRD=null;
up.aN=null;
up.wjY=null;
}


ED(up,"emK",n_p);
function n_p(){return up.wjY;}
Wf(up,"emK",RpC);
function RpC(nQ){up.wjY=nQ;}

ED(up,"LhD",oNu);
function oNu(){return up.aN;}
Wf(up,"LhD",ZD_);
function ZD_(nQ){up.aN=nQ;}

ED(up,"V7",e9);
function e9(){return up.Rk;}
Wf(up,"V7",U7k);
function U7k(nQ){up.Rk=nQ;}


ED(up,"KC",i5);
function i5(){return up.NRD;}
Wf(up,"KC",tkT);
function tkT(nQ){up.NRD=nQ;}

if(up!=fj)ju.apply(up,arguments);
}
Bg(yqn,"yqn");











function iV(){
var up=this;
























dN(up,iV,"KvK",CyB);
function CyB(_W,FAQ){
var mfV=new RegExp(FAQ);
var c3N=mfV.exec(_W);
if(c3N!=null){
return oL.zF(c3N);
}else{
return null;
}
}





dN(up,iV,"UFn",fC3);
function fC3(_W,FAQ){
return iV.KvK(_W,FAQ)!=null;
}


if(up==fj)iV.iMb=null;
if(up==fj)iV.t7f=null;
if(up==fj)iV.Rng=null;
if(up==fj)iV.RD2=null;
if(up==fj)iV.ubt=null;

if(up==fj)iV.dHj="UNKNOWN";

dN(up,iV,"FSW",Iov);
function Iov(){
if(iV.t7f==null){
var Vc2=iV.ZeS();
var FpE=iV.KVT();
var o2c=iV.US_(Vc2,FpE);
var gRV=iV.Wy5(o2c);
var xl3=iV.RrR(FpE);
iV.iMb=gRV;
iV.t7f=o2c;
iV.Rng=xl3.tc(0);
iV.RD2=xl3.tc(1);
iV.ubt=iV.WiS();
}
}

Va(up,iV,"UV_",uZ9);
function uZ9(){
iV.FSW();
return iV.iMb;
}

Va(up,iV,"pw",lIO);
function lIO(){
iV.FSW();
return iV.t7f;
}

Va(up,iV,"pD",LZe);
function LZe(){
iV.FSW();
return iV.Rng;
}

Va(up,iV,"Tf",qIm);
function qIm(){
iV.FSW();
return iV.RD2;
}



Va(up,iV,"Qpq",lu5);
function lu5(){
iV.FSW();
return iV.ubt;
}

dN(up,iV,"Wy5",Hm7);
function Hm7(o2c){
var L9w=null;
if(o2c=="PLAYSTATION"){
L9w=iV.ZeS();
}
return L9w;
}

dN(up,iV,"ZeS",ZT3);
function ZT3(){
var bM8=null;
{
bM8=navigator&&navigator.platform&&navigator.platform.toString?
navigator.platform.toString()
:null;
}
return bM8;
}

dN(up,iV,"KVT",mbE);
function mbE(){
var JaK=null;
{
JaK=navigator&&navigator.userAgent&&navigator.userAgent.toString?
navigator.userAgent.toString()
:null;
}
return JaK;
}

dN(up,iV,"US_",_Fm);
function _Fm(Vc2,msT){
if(msT!=null&&oL.Pe(msT,"Android")){
return "AND";
}
return iV.G0W(Vc2);
}

dN(up,iV,"G0W",Pxz);
function Pxz(Vc2){
if(Vc2==null){
return iV.dHj;
}
if(oL.Pe(Vc2,"iPad")
||oL.Pe(Vc2,"iPhone")
||oL.Pe(Vc2,"iPod")){
return "IOS";
}else if(oL.Pe(Vc2,"Mac")){
return "MAC";
}else if(oL.Pe(Vc2,"Win")){
return "WIN";
}else if(oL.Pe(Vc2,"Linux")
||oL.Pe(Vc2,"SunOS")
||oL.Pe(Vc2,"HP-UX")
||oL.Pe(Vc2,"BSD")){
return "UNIX";
}else if(oL.Pe(Vc2,"PlayStation")){
return "PLAYSTATION";
}else if(oL.Pe(Vc2,"XBOX")){
return "XBOX";
}else{
return Vc2;
}
}






dN(up,iV,"RrR",EdM);
function EdM(FpE){
var lb=
jh.oIy(iV.dHj,iV.dHj);
if(FpE==null){
return lb;
}

var Y6E=undefined;







var _ac=iV.KvK(FpE,"Trident.*rv[ :]*11\\.");
if(_ac!=null){
lb.a9(0,"MSIE");
Y6E=iV.KvK(FpE,"rv[ :]*"+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else if(oL.Pe(FpE,"Opera")){
lb.a9(0,"Opera");
Y6E=iV.KvK(FpE,"(?:Version/|Opera/|Opera )"+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else if(oL.Pe(FpE,"Chrome")){
lb.a9(0,"Chrome");
Y6E=iV.KvK(FpE,"Chrome/"+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else if((oL.Pe(FpE,"iPad")||oL.Pe(FpE,"iPhone")||oL.Pe(FpE,"iPod"))&&
oL.Pe(FpE,"AppleWebKit")&&oL.Pe(FpE,"Mobile")){
lb.a9(0,"Safari");
Y6E=iV.KvK(FpE," OS ([0-9](_([0-9a-zA-Z])+)*) like");
if(Y6E!=null&&Y6E.ug>1){

var hK=Y6E.tc(1);
hK=oL.ZLT(hK,"_",".");
lb.a9(1,hK);
}
}else if(oL.Pe(FpE,"Safari")){
lb.a9(0,"Safari");
Y6E=iV.KvK(FpE,"(?:Version/|Safari/)"+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else if(oL.Pe(FpE,"Firefox")||oL.Pe(FpE,"Gecko")){
lb.a9(0,"Firefox");
Y6E=iV.KvK(FpE,"(?:Firefox/|Firefox )"+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else if(oL.Pe(FpE,"MSIE")){
lb.a9(0,"MSIE");
Y6E=iV.KvK(FpE,"MSIE "+iV.lf0);
if(Y6E!=null&&Y6E.ug>1){
lb.a9(1,Y6E.tc(1));
}
}else{

}

return lb;
}


if(up==fj)iV.lf0="([a-zA-Z0-9]+(?:\\.[a-zA-Z0-9]*)*)";

dN(up,iV,"WiS",Npw);
function Npw(){
var H1=null;
{
H1=(window&&window.location&&window.location.href)?window.location.href.toString():null;
}
return H1;
}



dN(up,iV,"I7R",y1N);
function y1N(hdY,yqS,kh9){
if(hdY==null||yqS==null){
return hdY==null&&yqS==null;
}else if(hdY.ug!=yqS.ug){
return false;
}
for(var co=0;co<hdY.ug;co++){
if(!kh9(hdY.tc(co),yqS.tc(co))){
return false;
}
}
return true;
}



dN(up,iV,"VvK",jRn);
function jRn(hdY,yqS,kh9){
if(hdY==null||yqS==null){
return hdY==null&&yqS==null;
}else if(hdY.Bt!=yqS.Bt){
return false;
}
for(var co=0;co<hdY.Bt;co++){
if(!kh9(hdY.tc(co),yqS.tc(co))){
return false;
}
}
return true;
}



dN(up,iV,"x8M",M4d);
function M4d(hdY,yqS,kh9){
if(hdY==null||yqS==null){
return hdY==null&&yqS==null;
}else if(hdY.Bt!=yqS.Bt){
return false;
}
var bC=hdY.VO;
for(var Jo=0;Jo<bC.length;Jo++){
var Tj=bC[Jo];

if(!yqS.Wt(Tj)||!kh9(hdY.tc(Tj),yqS.tc(Tj))){
return false;
}
}
return true;
}







dN(up,iV,"OGk",Zln);
function Zln(h01){
var Ium=4;
var BrQ=255;
if(h01==null){
return oR.oH;
}
var tr2="^([0-9]+)\\.([0-9]+)\\.([0-9]+)\\.([0-9]+)$";
var match=iV.KvK(h01,tr2);
if(match!=null&&match.ug==Ium+1){
var _W4=new jh(Ium);
for(var Jr1=1;Jr1<Ium+1;Jr1++){
var octet=iV.Rvc(match.tc(Jr1));
if(octet>=0&&octet<=BrQ){
_W4.a9(Jr1-1,octet);
}else{
return oR.oH;
}
}

return VW.z_((_W4.tc(0)*VW.z_(Math.pow(2,24)))+(_W4.tc(1)*VW.z_(Math.pow(2,16)))+(_W4.tc(2)*VW.z_(Math.pow(2,8)))+(_W4.tc(3)*VW.z_(Math.pow(2,0))));
}else{
return oR.oH;
}

}



dN(up,iV,"Rvc",umR);
function umR(pI2){
var vlA=true;
var lb=0;
lb=parseInt(pI2,10);
if(isNaN(lb)){
vlA=false;
}
if(vlA){
return lb;
}else{
return-1;
}
}

dN(up,iV,"Kb0",fa0);
function fa0(tis){
return iV.G0W(tis);
}

dN(up,iV,"nJV",m5m);
function m5m(){
iV.t7f=null;
}

dN(up,iV,"Fg5",QF1);
function QF1(FpE){
return iV.RrR(FpE);
}

dN(up,iV,"Mn1",OiI);
function OiI(_W,IgG){
return iV.KvK(_W,IgG);
}


}
Bg(iV,"iV");















function SPf(){
var up=this;
function ju(){
up.JWg=SPf.Rxe;
up.XmI=null;
up.HoU=(
function(bEg,ypO,LSr,mHn){
return bEg>=LSr;
}
);
}


OZ(up,"qrn",wXT);
function wXT(Dt4,vN){
if(up.HoU(Dt4,vN,up.JWg,up.XmI)){
up.JWg=Dt4;
up.XmI=vN;
}
return up.XmI;
}





ED(up,"ZIA",AA7);
function AA7(){return up.HoU;}
Wf(up,"ZIA",AVU);
function AVU(nQ){up.HoU=nQ;}


ED(up,"Dt4",OdL);
function OdL(){return up.JWg;}
Wf(up,"Dt4",edv);
function edv(nQ){up.JWg=nQ;}


ED(up,"vN",oIT);
function oIT(){return up.XmI;}
Wf(up,"vN",T9t);
function T9t(nQ){up.XmI=nQ;}









if(up==fj)SPf.b1i=100;
if(up==fj)SPf.oEC=80;
if(up==fj)SPf.px6=60;
if(up==fj)SPf.W7R=40;
if(up==fj)SPf.ned=20;
if(up==fj)SPf.Rxe=-1;


if(up!=fj)up.JWg=undefined;

if(up!=fj)up.XmI=undefined;

if(up!=fj)up.HoU=undefined;
if(up!=fj)ju.apply(up,arguments);
}
Bg(SPf,"SPf");










function zY(){
var up=this;




if(up==fj)zY.pI=10;
if(up==fj)zY.E3=3;

if(up==fj)zY.Iw=2;
if(up==fj)zY.CA=35;





if(up==fj)zY.Cg=16;

if(up==fj)zY.MQ=16;

if(up==fj)zY.Kv=128;

if(up==fj)zY._n=500;

if(up==fj)zY.Vy=10;





if(up==fj)zY.ZP=16;

if(up==fj)zY.c8=128;

if(up==fj)zY.ck=128;

if(up==fj)zY.lI=2000;

if(up==fj)zY.M1=100;





if(up==fj)zY.H3P=20000;

if(up==fj)zY.K1q=40000;

if(up==fj)zY.g4M=20000;

















}
Bg(zY,"zY");







function r9U(){
var up=this;

if(up!=fj)up.udyXG=undefined;
ED(up,"Mf",ja3XG);
function ja3XG(){return up.udyXG;}
Wf(up,"Mf",ZchXG);
function ZchXG(nQ){up.udyXG=nQ;}

if(up!=fj)up.Fzh=undefined;
ED(up,"PS",oaQ);
function oaQ(){return up.Fzh;}
Wf(up,"PS",Xrp);
function Xrp(nQ){up.Fzh=nQ;}

if(up!=fj)up.ScS=undefined;
ED(up,"_j",PCC);
function PCC(){return up.ScS;}
Wf(up,"_j",tqm);
function tqm(nQ){up.ScS=nQ;}

if(up!=fj)up.rHH=undefined;
ED(up,"W_h",EPT);
function EPT(){return up.rHH;}
Wf(up,"W_h",v_Q);
function v_Q(nQ){up.rHH=nQ;}


if(up!=fj)up.lY4=undefined;
ED(up,"So6",Ior);
function Ior(){return up.lY4;}
Wf(up,"So6",ENY);
function ENY(nQ){up.lY4=nQ;}

OZ(up,"b9s",Zdc);
function Zdc(mG7){
return(" Count="+up.Mf+mG7+
" Mean="+up.PS+mG7+
" Min="+up.W_h+mG7+
" Max="+up._j+mG7+
" StdDev="+up.So6);
}
}
Bg(r9U,"r9U");













function FQ(){
var up=this;


if(up!=fj)up._U5=undefined;


if(up!=fj)up.nsn=undefined;


if(up!=fj)up.vcA=undefined;














if(up!=fj)up.CKc=undefined;









function ju(bXK,kNt){
up._U5=bXK;
up.nsn=kNt;

if(up.nsn>up._U5/10.0)
up.nsn=up._U5/10.0;
if(up.nsn<up._U5/1000.0)
up.nsn=up._U5/1000.0;
up.nr();

}


OZ(up,"nr",kP);
function kP(){
up.vcA=new VYO();
up.CKc=new Yw();
}

OZ(up,"wy",NQ);
function NQ(){
up.nr();
}

OZ(up,"mkP",Go2);
function Go2(){
up.CKc=new Yw();
}


OZ(up,"yS",BMl);
function BMl(Sk){
up.Oqi(up.vcA,Sk);

var kz=Lt.VB();
up.BPt(kz);

if(up.CKc.Bt==0||kz>=up.CKc.tc(0).tll+up.nsn){
var ylD=new VYO();
ylD.tll=kz;
ylD._j=Sk;
ylD.W_h=Sk;
up.CKc.gX(0,ylD);
}
up.Oqi(up.CKc.tc(0),Sk);
}

LK(up,"Oqi",jG9);
function jG9(B3,Sk){
B3.Mf++;
B3.gG+=Sk;
B3.sV0+=(Sk*Sk);
B3._j=Math.max(Sk,B3._j);
B3.W_h=Math.min(Sk,B3.W_h);
}








OZ(up,"nG",Qx_);
function Qx_(){
up.BPt(Lt.VB());

var Vp=new VYO();

var bC=up.CKc.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var B3=bC[Jo];


Vp.Mf+=B3.Mf;
Vp.gG+=B3.gG;
Vp.sV0+=B3.sV0;
Vp._j=Math.max(B3._j,Vp._j);
Vp.W_h=Math.min(B3.W_h,Vp.W_h);
}
return up.bdC(Vp);
}

LK(up,"bdC",bdW);
function bdW(B3){
var S5=new r9U();
S5.Mf=B3.Mf;
if(B3.Mf==0){
S5.PS=0;
S5.So6=0;
}else{
S5.PS=B3.gG/B3.Mf;
S5.So6=Math.sqrt((B3.sV0-2*B3.gG*S5.PS-S5.PS*S5.PS)/B3.Mf);
}
S5._j=B3._j;
S5.W_h=B3.W_h;
return S5;
}


OZ(up,"dW",Can);
function Can(){
return up.nG().PS;
}

OZ(up,"pCV",BXq);
function BXq(){
return up.nG().So6;
}

OZ(up,"dCA",jMH);
function jMH(){
return up.nG().Mf;
}

OZ(up,"V9",acs);
function acs(){
var Wp=up.CKc.Bt;
if(Wp==0){
return 0;
}
return up.CKc.tc(0).tll+up.nsn-up.CKc.tc(Wp-1).tll;
}











OZ(up,"HUY",aQ0);
function aQ0(iq5){
iq5=Math.min(iq5,up._U5);
var kz=Lt.VB();
up.BPt(kz);

var Vp=new VYO();

var YSe=kz-iq5;
var bC=up.CKc.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var B3=bC[Jo];


var B1J=B3.tll+up.nsn;
if(B1J<YSe){
break;
}
Vp.Mf+=B3.Mf;
Vp.gG+=B3.gG;
Vp.sV0+=B3.sV0;
Vp._j=Math.max(B3._j,Vp._j);
Vp.W_h=Math.min(B3.W_h,Vp.W_h);
}
return up.bdC(Vp);
}

OZ(up,"RJT",m9r);
function m9r(){
return up.bdC(up.vcA);
}

OZ(up,"oE",a35);
function a35(){
return up.vcA.Mf;
}
OZ(up,"N3p",AyC);
function AyC(){
return up.RJT().PS;
}
OZ(up,"DN",mrD);
function mrD(){
return up.vcA._j;
}
OZ(up,"wAd",J_j);
function J_j(){
return up.vcA.W_h;
}

OZ(up,"_kB",Ar2);
function Ar2(){
return up.RJT().So6;
}

OZ(up,"l36",sph);
function sph(){
var S5="";
for(var co=0;co<up.CKc.Bt;co++){
S5+=VW.z_(up.CKc.tc(co).gG)+" ";
}
return S5;
}


LK(up,"BPt",QKe);
function QKe(kz){

var bLD=up.CKc.Bt-1;
while(bLD>=0){
if(up.CKc.tc(bLD).tll>kz-up._U5){
break;
}
bLD--;
}
if(bLD==up.CKc.Bt-1)
return;


up.CKc.JI(bLD+1,up.CKc.Bt-bLD-1);
}


if(up!=fj)ju.apply(up,arguments);
}
Bg(FQ,"FQ");





function VYO(){
var up=this;

if(up!=fj)up.tll=undefined;

if(up!=fj)up.Mf=0;

if(up!=fj)up.W_h=Number.POSITIVE_INFINITY;

if(up!=fj)up._j=Number.NEGATIVE_INFINITY;

if(up!=fj)up.gG=0;

if(up!=fj)up.sV0=0;
}
Bg(VYO,"VYO");











function hR(){
var up=this;
if(up==fj)hR.UDE=1000;

if(up==fj)hR.HfQ=30000;

if(up==fj)hR.Vo5=100;

if(up==fj)hR.KL=null;


if(up==fj)hR.oJs=-1;

if(up==fj)hR.IX5=null;

function ju(){
O9.FW("TimeKeeper: is a singleton class");
}

dN(up,hR,"nr",kP);
function kP(){
if(hR.KL==null){
hR.IX5=new ffH(hR.Vo5);
hR.KL=new Lt(hR.UDE,hR.Qh2,"TimeKeeper.poll");
}
}

dN(up,hR,"wy",NQ);
function NQ(){
if(hR.KL!=null){
hR.KL.wy();
hR.KL=null;
}
hR.oJs=-1;
if(hR.IX5!=null){
hR.IX5.wy();
hR.IX5=null;
}
}





dN(up,hR,"SI",ugD);
function ugD(h9A,JC0){
if(h9A>JC0)return 0;



hR.Qh2();
var DRs=0;
if(hR.IX5!=null){
var xBP=hR.IX5.nB2;
var bC=xBP.YC;
for(var Jo=0;Jo<bC.length;Jo++){
var zjb=bC[Jo];

DRs+=hR.iIb(h9A,JC0,
zjb.pT,zjb.bAW);
}
}
var S5=VW.z_(JC0-h9A-DRs);
if(S5<0){
return 0;
}else{
return S5;
}
}





dN(up,hR,"Qh2",CBL);
function CBL(){
var kz=Lt.VB();
if(hR.oJs>=0&&kz-hR.oJs>hR.HfQ&&
hR.IX5!=null){
hR.IX5.i6Y(new TVD(hR.oJs,kz));
}



if(hR.oJs>=0&&hR.oJs>kz){
Lt.ZAw(hR.oJs-kz+hR.UDE);
kz=Lt.VB();
}
hR.oJs=kz;
}

dN(up,hR,"iIb",FoC);
function FoC(h9A,JC0,Yjd,IyR){




if(h9A>=IyR||JC0<=Yjd){
return 0.0;
}

var nyL=0;
if(h9A<Yjd){
nyL+=Yjd-h9A;
}
if(JC0>IyR){
nyL+=JC0-IyR;
}
return JC0-h9A-nyL;
}






dN(up,hR,"uB3",pad);
function pad(h9A,JC0){
hR.IX5.i6Y(new TVD(h9A,JC0));
}

dN(up,hR,"d87",xXs);
function xXs(v9){
hR.oJs+=v9;
}


Z0(up,hR,"Qgi",JCh);
function JCh(nQ){hR.HfQ=nQ;}


Z0(up,hR,"ggs",JmG);
function JmG(nQ){hR.UDE=nQ;}

if(up!=fj)ju.apply(up,arguments);
}
Bg(hR,"hR");


function TVD(){
var up=this;
if(up!=fj)up.pT=undefined;
if(up!=fj)up.bAW=undefined;
function ju(FpG,r00){
up.pT=FpG;
up.bAW=r00;
}
if(up!=fj)ju.apply(up,arguments);
}
Bg(TVD,"TVD");











function IE4(){
var up=this;

if(up!=fj)up.pg=undefined;
if(up!=fj)up.Z43=undefined;

function ju(){
up.TsT();
}

OZ(up,"ox",gv);
function gv(){
up.TsT();
}

OZ(up,"TsT",uJo);
function uJo(){
up.pg=null;
up.Z43=-1;
}

OZ(up,"woL",l6p);
function l6p(nQ,kz){
up.pg=nQ;
up.Z43=kz;
}


ED(up,"nQ",dMq);
function dMq(){return up.pg;}


ED(up,"h9A",zah);
function zah(){return up.Z43;}
if(up!=fj)ju.apply(up,arguments);
}
Bg(IE4,"IE4");


})();

